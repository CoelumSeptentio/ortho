--
-- PostgreSQL database dump
--

\restrict 8hoGAc4Q9rThTZVawv1PNCaZAEPp6A2j3D12YugIjgZ6BItBPYB9etgS9RUYmDU

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.admin_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    action_parameters jsonb,
    subject character varying(255),
    properties jsonb,
    conditions jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_permissions OWNER TO ortho;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_permissions_id_seq OWNER TO ortho;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.admin_permissions_id_seq OWNED BY public.admin_permissions.id;


--
-- Name: admin_permissions_role_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.admin_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.admin_permissions_role_lnk OWNER TO ortho;

--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.admin_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_permissions_role_lnk_id_seq OWNER TO ortho;

--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNED BY public.admin_permissions_role_lnk.id;


--
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.admin_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    description character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_roles OWNER TO ortho;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.admin_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_roles_id_seq OWNER TO ortho;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.admin_roles_id_seq OWNED BY public.admin_roles.id;


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    document_id character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    username character varying(255),
    email character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    registration_token character varying(255),
    is_active boolean,
    blocked boolean,
    prefered_language character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_users OWNER TO ortho;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_id_seq OWNER TO ortho;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: admin_users_roles_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.admin_users_roles_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    role_ord double precision,
    user_ord double precision
);


ALTER TABLE public.admin_users_roles_lnk OWNER TO ortho;

--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.admin_users_roles_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_roles_lnk_id_seq OWNER TO ortho;

--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNED BY public.admin_users_roles_lnk.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    document_id character varying(255),
    title character varying(255),
    slug character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.categories OWNER TO ortho;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO ortho;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: categories_parent_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.categories_parent_lnk (
    id integer NOT NULL,
    category_id integer,
    inv_category_id integer,
    category_ord double precision
);


ALTER TABLE public.categories_parent_lnk OWNER TO ortho;

--
-- Name: categories_parent_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.categories_parent_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_parent_lnk_id_seq OWNER TO ortho;

--
-- Name: categories_parent_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.categories_parent_lnk_id_seq OWNED BY public.categories_parent_lnk.id;


--
-- Name: client_documents; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.client_documents (
    id integer NOT NULL,
    document_id character varying(255),
    title character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    description text
);


ALTER TABLE public.client_documents OWNER TO ortho;

--
-- Name: client_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.client_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_documents_id_seq OWNER TO ortho;

--
-- Name: client_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.client_documents_id_seq OWNED BY public.client_documents.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.files (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    alternative_text character varying(255),
    caption character varying(255),
    width integer,
    height integer,
    formats jsonb,
    hash character varying(255),
    ext character varying(255),
    mime character varying(255),
    size numeric(10,2),
    url character varying(255),
    preview_url character varying(255),
    provider character varying(255),
    provider_metadata jsonb,
    folder_path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.files OWNER TO ortho;

--
-- Name: files_folder_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.files_folder_lnk (
    id integer NOT NULL,
    file_id integer,
    folder_id integer,
    file_ord double precision
);


ALTER TABLE public.files_folder_lnk OWNER TO ortho;

--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.files_folder_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_folder_lnk_id_seq OWNER TO ortho;

--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.files_folder_lnk_id_seq OWNED BY public.files_folder_lnk.id;


--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_id_seq OWNER TO ortho;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: files_related_mph; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.files_related_mph (
    id integer NOT NULL,
    file_id integer,
    related_id integer,
    related_type character varying(255),
    field character varying(255),
    "order" double precision
);


ALTER TABLE public.files_related_mph OWNER TO ortho;

--
-- Name: files_related_mph_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.files_related_mph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_related_mph_id_seq OWNER TO ortho;

--
-- Name: files_related_mph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.files_related_mph_id_seq OWNED BY public.files_related_mph.id;


--
-- Name: i18n_locale; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.i18n_locale (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.i18n_locale OWNER TO ortho;

--
-- Name: i18n_locale_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.i18n_locale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.i18n_locale_id_seq OWNER TO ortho;

--
-- Name: i18n_locale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.i18n_locale_id_seq OWNED BY public.i18n_locale.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.products (
    id integer NOT NULL,
    document_id character varying(255),
    title character varying(255),
    slug character varying(255),
    price numeric(10,2),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    description text
);


ALTER TABLE public.products OWNER TO ortho;

--
-- Name: products_category_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.products_category_lnk (
    id integer NOT NULL,
    product_id integer,
    category_id integer,
    product_ord double precision
);


ALTER TABLE public.products_category_lnk OWNER TO ortho;

--
-- Name: products_category_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.products_category_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_category_lnk_id_seq OWNER TO ortho;

--
-- Name: products_category_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.products_category_lnk_id_seq OWNED BY public.products_category_lnk.id;


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO ortho;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: strapi_ai_localization_jobs; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_ai_localization_jobs (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255) NOT NULL,
    source_locale character varying(255) NOT NULL,
    target_locales jsonb NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone
);


ALTER TABLE public.strapi_ai_localization_jobs OWNER TO ortho;

--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_ai_localization_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_ai_localization_jobs_id_seq OWNER TO ortho;

--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNED BY public.strapi_ai_localization_jobs.id;


--
-- Name: strapi_api_token_permissions; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_api_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_token_permissions OWNER TO ortho;

--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_api_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_api_token_permissions_id_seq OWNER TO ortho;

--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNED BY public.strapi_api_token_permissions.id;


--
-- Name: strapi_api_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_api_token_permissions_token_lnk (
    id integer NOT NULL,
    api_token_permission_id integer,
    api_token_id integer,
    api_token_permission_ord double precision
);


ALTER TABLE public.strapi_api_token_permissions_token_lnk OWNER TO ortho;

--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_api_token_permissions_token_lnk_id_seq OWNER TO ortho;

--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNED BY public.strapi_api_token_permissions_token_lnk.id;


--
-- Name: strapi_api_tokens; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_api_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    access_key character varying(255),
    encrypted_key text,
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_tokens OWNER TO ortho;

--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_api_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_api_tokens_id_seq OWNER TO ortho;

--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNED BY public.strapi_api_tokens.id;


--
-- Name: strapi_core_store_settings; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_core_store_settings (
    id integer NOT NULL,
    key character varying(255),
    value text,
    type character varying(255),
    environment character varying(255),
    tag character varying(255)
);


ALTER TABLE public.strapi_core_store_settings OWNER TO ortho;

--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_core_store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_core_store_settings_id_seq OWNER TO ortho;

--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNED BY public.strapi_core_store_settings.id;


--
-- Name: strapi_database_schema; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_database_schema (
    id integer NOT NULL,
    schema json,
    "time" timestamp without time zone,
    hash character varying(255)
);


ALTER TABLE public.strapi_database_schema OWNER TO ortho;

--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_database_schema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_database_schema_id_seq OWNER TO ortho;

--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_database_schema_id_seq OWNED BY public.strapi_database_schema.id;


--
-- Name: strapi_history_versions; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_history_versions (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255),
    locale character varying(255),
    status character varying(255),
    data jsonb,
    schema jsonb,
    created_at timestamp(6) without time zone,
    created_by_id integer
);


ALTER TABLE public.strapi_history_versions OWNER TO ortho;

--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_history_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_history_versions_id_seq OWNER TO ortho;

--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_history_versions_id_seq OWNED BY public.strapi_history_versions.id;


--
-- Name: strapi_migrations; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_migrations (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations OWNER TO ortho;

--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_migrations_id_seq OWNER TO ortho;

--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_migrations_id_seq OWNED BY public.strapi_migrations.id;


--
-- Name: strapi_migrations_internal; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_migrations_internal (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations_internal OWNER TO ortho;

--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_migrations_internal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_migrations_internal_id_seq OWNER TO ortho;

--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNED BY public.strapi_migrations_internal.id;


--
-- Name: strapi_release_actions; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_release_actions (
    id integer NOT NULL,
    document_id character varying(255),
    type character varying(255),
    content_type character varying(255),
    entry_document_id character varying(255),
    locale character varying(255),
    is_entry_valid boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer
);


ALTER TABLE public.strapi_release_actions OWNER TO ortho;

--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_release_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_release_actions_id_seq OWNER TO ortho;

--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_release_actions_id_seq OWNED BY public.strapi_release_actions.id;


--
-- Name: strapi_release_actions_release_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_release_actions_release_lnk (
    id integer NOT NULL,
    release_action_id integer,
    release_id integer,
    release_action_ord double precision
);


ALTER TABLE public.strapi_release_actions_release_lnk OWNER TO ortho;

--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_release_actions_release_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_release_actions_release_lnk_id_seq OWNER TO ortho;

--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNED BY public.strapi_release_actions_release_lnk.id;


--
-- Name: strapi_releases; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_releases (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    released_at timestamp(6) without time zone,
    scheduled_at timestamp(6) without time zone,
    timezone character varying(255),
    status character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_releases OWNER TO ortho;

--
-- Name: strapi_releases_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_releases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_releases_id_seq OWNER TO ortho;

--
-- Name: strapi_releases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_releases_id_seq OWNED BY public.strapi_releases.id;


--
-- Name: strapi_sessions; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_sessions (
    id integer NOT NULL,
    document_id character varying(255),
    user_id character varying(255),
    session_id character varying(255),
    child_id character varying(255),
    device_id character varying(255),
    origin character varying(255),
    expires_at timestamp(6) without time zone,
    absolute_expires_at timestamp(6) without time zone,
    status character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_sessions OWNER TO ortho;

--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_sessions_id_seq OWNER TO ortho;

--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_sessions_id_seq OWNED BY public.strapi_sessions.id;


--
-- Name: strapi_transfer_token_permissions; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_transfer_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_token_permissions OWNER TO ortho;

--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_transfer_token_permissions_id_seq OWNER TO ortho;

--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNED BY public.strapi_transfer_token_permissions.id;


--
-- Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_transfer_token_permissions_token_lnk (
    id integer NOT NULL,
    transfer_token_permission_id integer,
    transfer_token_id integer,
    transfer_token_permission_ord double precision
);


ALTER TABLE public.strapi_transfer_token_permissions_token_lnk OWNER TO ortho;

--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNER TO ortho;

--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNED BY public.strapi_transfer_token_permissions_token_lnk.id;


--
-- Name: strapi_transfer_tokens; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_transfer_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    access_key character varying(255),
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_tokens OWNER TO ortho;

--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_transfer_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_transfer_tokens_id_seq OWNER TO ortho;

--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNED BY public.strapi_transfer_tokens.id;


--
-- Name: strapi_webhooks; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_webhooks (
    id integer NOT NULL,
    name character varying(255),
    url text,
    headers jsonb,
    events jsonb,
    enabled boolean
);


ALTER TABLE public.strapi_webhooks OWNER TO ortho;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_webhooks_id_seq OWNER TO ortho;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_webhooks_id_seq OWNED BY public.strapi_webhooks.id;


--
-- Name: strapi_workflows; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_workflows (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    content_types jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows OWNER TO ortho;

--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_id_seq OWNER TO ortho;

--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_workflows_id_seq OWNED BY public.strapi_workflows.id;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_workflows_stage_required_to_publish_lnk (
    id integer NOT NULL,
    workflow_id integer,
    workflow_stage_id integer
);


ALTER TABLE public.strapi_workflows_stage_required_to_publish_lnk OWNER TO ortho;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNER TO ortho;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNED BY public.strapi_workflows_stage_required_to_publish_lnk.id;


--
-- Name: strapi_workflows_stages; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_workflows_stages (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    color character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows_stages OWNER TO ortho;

--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_workflows_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_stages_id_seq OWNER TO ortho;

--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNED BY public.strapi_workflows_stages.id;


--
-- Name: strapi_workflows_stages_permissions_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_workflows_stages_permissions_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    permission_id integer,
    permission_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_permissions_lnk OWNER TO ortho;

--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_stages_permissions_lnk_id_seq OWNER TO ortho;

--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNED BY public.strapi_workflows_stages_permissions_lnk.id;


--
-- Name: strapi_workflows_stages_workflow_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.strapi_workflows_stages_workflow_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    workflow_id integer,
    workflow_stage_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_workflow_lnk OWNER TO ortho;

--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_stages_workflow_lnk_id_seq OWNER TO ortho;

--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNED BY public.strapi_workflows_stages_workflow_lnk.id;


--
-- Name: up_permissions; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.up_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_permissions OWNER TO ortho;

--
-- Name: up_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.up_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_permissions_id_seq OWNER TO ortho;

--
-- Name: up_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.up_permissions_id_seq OWNED BY public.up_permissions.id;


--
-- Name: up_permissions_role_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.up_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.up_permissions_role_lnk OWNER TO ortho;

--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.up_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_permissions_role_lnk_id_seq OWNER TO ortho;

--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNED BY public.up_permissions_role_lnk.id;


--
-- Name: up_roles; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.up_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_roles OWNER TO ortho;

--
-- Name: up_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.up_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_roles_id_seq OWNER TO ortho;

--
-- Name: up_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.up_roles_id_seq OWNED BY public.up_roles.id;


--
-- Name: up_users; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.up_users (
    id integer NOT NULL,
    document_id character varying(255),
    username character varying(255),
    email character varying(255),
    provider character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    confirmation_token character varying(255),
    confirmed boolean,
    blocked boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_users OWNER TO ortho;

--
-- Name: up_users_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.up_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_users_id_seq OWNER TO ortho;

--
-- Name: up_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.up_users_id_seq OWNED BY public.up_users.id;


--
-- Name: up_users_role_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.up_users_role_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    user_ord double precision
);


ALTER TABLE public.up_users_role_lnk OWNER TO ortho;

--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.up_users_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_users_role_lnk_id_seq OWNER TO ortho;

--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNED BY public.up_users_role_lnk.id;


--
-- Name: upload_folders; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.upload_folders (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    path_id integer,
    path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.upload_folders OWNER TO ortho;

--
-- Name: upload_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.upload_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upload_folders_id_seq OWNER TO ortho;

--
-- Name: upload_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.upload_folders_id_seq OWNED BY public.upload_folders.id;


--
-- Name: upload_folders_parent_lnk; Type: TABLE; Schema: public; Owner: ortho
--

CREATE TABLE public.upload_folders_parent_lnk (
    id integer NOT NULL,
    folder_id integer,
    inv_folder_id integer,
    folder_ord double precision
);


ALTER TABLE public.upload_folders_parent_lnk OWNER TO ortho;

--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: ortho
--

CREATE SEQUENCE public.upload_folders_parent_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upload_folders_parent_lnk_id_seq OWNER TO ortho;

--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ortho
--

ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNED BY public.upload_folders_parent_lnk.id;


--
-- Name: admin_permissions id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_id_seq'::regclass);


--
-- Name: admin_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_role_lnk_id_seq'::regclass);


--
-- Name: admin_roles id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_roles ALTER COLUMN id SET DEFAULT nextval('public.admin_roles_id_seq'::regclass);


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: admin_users_roles_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users_roles_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_users_roles_lnk_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: categories_parent_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories_parent_lnk ALTER COLUMN id SET DEFAULT nextval('public.categories_parent_lnk_id_seq'::regclass);


--
-- Name: client_documents id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.client_documents ALTER COLUMN id SET DEFAULT nextval('public.client_documents_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: files_folder_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files_folder_lnk ALTER COLUMN id SET DEFAULT nextval('public.files_folder_lnk_id_seq'::regclass);


--
-- Name: files_related_mph id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files_related_mph ALTER COLUMN id SET DEFAULT nextval('public.files_related_mph_id_seq'::regclass);


--
-- Name: i18n_locale id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.i18n_locale ALTER COLUMN id SET DEFAULT nextval('public.i18n_locale_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: products_category_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products_category_lnk ALTER COLUMN id SET DEFAULT nextval('public.products_category_lnk_id_seq'::regclass);


--
-- Name: strapi_ai_localization_jobs id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs ALTER COLUMN id SET DEFAULT nextval('public.strapi_ai_localization_jobs_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_api_tokens id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_tokens_id_seq'::regclass);


--
-- Name: strapi_core_store_settings id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_core_store_settings ALTER COLUMN id SET DEFAULT nextval('public.strapi_core_store_settings_id_seq'::regclass);


--
-- Name: strapi_database_schema id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_database_schema ALTER COLUMN id SET DEFAULT nextval('public.strapi_database_schema_id_seq'::regclass);


--
-- Name: strapi_history_versions id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_history_versions ALTER COLUMN id SET DEFAULT nextval('public.strapi_history_versions_id_seq'::regclass);


--
-- Name: strapi_migrations id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_migrations ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_id_seq'::regclass);


--
-- Name: strapi_migrations_internal id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_migrations_internal ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_internal_id_seq'::regclass);


--
-- Name: strapi_release_actions id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_id_seq'::regclass);


--
-- Name: strapi_release_actions_release_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_release_lnk_id_seq'::regclass);


--
-- Name: strapi_releases id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_releases ALTER COLUMN id SET DEFAULT nextval('public.strapi_releases_id_seq'::regclass);


--
-- Name: strapi_sessions id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_sessions ALTER COLUMN id SET DEFAULT nextval('public.strapi_sessions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_transfer_tokens id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_tokens_id_seq'::regclass);


--
-- Name: strapi_webhooks id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_webhooks ALTER COLUMN id SET DEFAULT nextval('public.strapi_webhooks_id_seq'::regclass);


--
-- Name: strapi_workflows id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_id_seq'::regclass);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_permissions_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_permissions_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_workflow_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_workflow_lnk_id_seq'::regclass);


--
-- Name: up_permissions id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_id_seq'::regclass);


--
-- Name: up_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_role_lnk_id_seq'::regclass);


--
-- Name: up_roles id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_roles ALTER COLUMN id SET DEFAULT nextval('public.up_roles_id_seq'::regclass);


--
-- Name: up_users id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users ALTER COLUMN id SET DEFAULT nextval('public.up_users_id_seq'::regclass);


--
-- Name: up_users_role_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_users_role_lnk_id_seq'::regclass);


--
-- Name: upload_folders id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_id_seq'::regclass);


--
-- Name: upload_folders_parent_lnk id; Type: DEFAULT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders_parent_lnk ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_parent_lnk_id_seq'::regclass);


--
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.admin_permissions (id, document_id, action, action_parameters, subject, properties, conditions, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	v7nel2bh0f320ji5qmj1j4mx	plugin::upload.read	{}	\N	{}	[]	2025-08-22 12:50:23.386	2025-08-22 12:50:23.386	2025-08-22 12:50:23.392	\N	\N	\N
2	yorup6psqb0zlqfwz96rvefl	plugin::upload.configure-view	{}	\N	{}	[]	2025-08-22 12:50:23.405	2025-08-22 12:50:23.405	2025-08-22 12:50:23.405	\N	\N	\N
3	bown0pixmppuoyho8e3hy7lc	plugin::upload.assets.create	{}	\N	{}	[]	2025-08-22 12:50:23.414	2025-08-22 12:50:23.414	2025-08-22 12:50:23.414	\N	\N	\N
4	ndogy87nleynix0p2w4ttk9y	plugin::upload.assets.update	{}	\N	{}	[]	2025-08-22 12:50:23.424	2025-08-22 12:50:23.424	2025-08-22 12:50:23.424	\N	\N	\N
5	sy3wr0y355yti7q918linqc6	plugin::upload.assets.download	{}	\N	{}	[]	2025-08-22 12:50:23.435	2025-08-22 12:50:23.435	2025-08-22 12:50:23.435	\N	\N	\N
6	vnila7phag324ev0mzl6sy1y	plugin::upload.assets.copy-link	{}	\N	{}	[]	2025-08-22 12:50:23.445	2025-08-22 12:50:23.445	2025-08-22 12:50:23.445	\N	\N	\N
7	bstogpdzmv40qvvfcs9c3l80	plugin::upload.read	{}	\N	{}	["admin::is-creator"]	2025-08-22 12:50:23.458	2025-08-22 12:50:23.458	2025-08-22 12:50:23.459	\N	\N	\N
8	faxcgjk6w7z1iccrxjavuf79	plugin::upload.configure-view	{}	\N	{}	[]	2025-08-22 12:50:23.468	2025-08-22 12:50:23.468	2025-08-22 12:50:23.468	\N	\N	\N
9	xba40y07r2hw9k4yfo7t1uww	plugin::upload.assets.create	{}	\N	{}	[]	2025-08-22 12:50:23.478	2025-08-22 12:50:23.478	2025-08-22 12:50:23.478	\N	\N	\N
10	h9sw7jtikkpfxmqkfbt4fhaf	plugin::upload.assets.update	{}	\N	{}	["admin::is-creator"]	2025-08-22 12:50:23.486	2025-08-22 12:50:23.486	2025-08-22 12:50:23.486	\N	\N	\N
11	hf3x3mk5qzdoxpwgwopf2gfk	plugin::upload.assets.download	{}	\N	{}	[]	2025-08-22 12:50:23.496	2025-08-22 12:50:23.496	2025-08-22 12:50:23.496	\N	\N	\N
12	hyaij8nxz8onpoxgb1k15yzq	plugin::upload.assets.copy-link	{}	\N	{}	[]	2025-08-22 12:50:23.507	2025-08-22 12:50:23.507	2025-08-22 12:50:23.507	\N	\N	\N
16	jg2z7asdiu7qb7fdvmoskt44	plugin::content-manager.explorer.delete	{}	plugin::users-permissions.user	{}	[]	2025-08-22 12:50:23.648	2025-08-22 12:50:23.648	2025-08-22 12:50:23.648	\N	\N	\N
17	shchs2vcq9ah5xny4zqepb6g	plugin::content-manager.explorer.publish	{}	plugin::users-permissions.user	{}	[]	2025-08-22 12:50:23.663	2025-08-22 12:50:23.663	2025-08-22 12:50:23.663	\N	\N	\N
18	mgnmswzd0bc3eu734moqmw0c	plugin::content-manager.single-types.configure-view	{}	\N	{}	[]	2025-08-22 12:50:23.675	2025-08-22 12:50:23.675	2025-08-22 12:50:23.675	\N	\N	\N
19	rbime4gy5z3a9lc6mmdfs4fg	plugin::content-manager.collection-types.configure-view	{}	\N	{}	[]	2025-08-22 12:50:23.686	2025-08-22 12:50:23.686	2025-08-22 12:50:23.687	\N	\N	\N
20	qz5uh61y4k7u4xd735yb4wtx	plugin::content-manager.components.configure-layout	{}	\N	{}	[]	2025-08-22 12:50:23.698	2025-08-22 12:50:23.698	2025-08-22 12:50:23.698	\N	\N	\N
21	sdkmn2a9era57ixfg4rgbbo5	plugin::content-type-builder.read	{}	\N	{}	[]	2025-08-22 12:50:23.711	2025-08-22 12:50:23.711	2025-08-22 12:50:23.711	\N	\N	\N
22	xdjam6wgrf0mdj4on9se9b8i	plugin::email.settings.read	{}	\N	{}	[]	2025-08-22 12:50:23.721	2025-08-22 12:50:23.721	2025-08-22 12:50:23.721	\N	\N	\N
23	ng82zi6q848zuo2gue7bqw4h	plugin::upload.read	{}	\N	{}	[]	2025-08-22 12:50:23.728	2025-08-22 12:50:23.728	2025-08-22 12:50:23.728	\N	\N	\N
24	zqlylqx9t6ks81kyhmwa9e43	plugin::upload.assets.create	{}	\N	{}	[]	2025-08-22 12:50:23.744	2025-08-22 12:50:23.744	2025-08-22 12:50:23.744	\N	\N	\N
25	v2e34zbtu6hc83a1o09aznco	plugin::upload.assets.update	{}	\N	{}	[]	2025-08-22 12:50:23.757	2025-08-22 12:50:23.757	2025-08-22 12:50:23.757	\N	\N	\N
26	uz1vb0sc46y1kr98tr4u6e6a	plugin::upload.assets.download	{}	\N	{}	[]	2025-08-22 12:50:23.766	2025-08-22 12:50:23.766	2025-08-22 12:50:23.766	\N	\N	\N
27	qf6emyctwvcgw73wpfrqahd9	plugin::upload.assets.copy-link	{}	\N	{}	[]	2025-08-22 12:50:23.774	2025-08-22 12:50:23.774	2025-08-22 12:50:23.775	\N	\N	\N
28	evtkvbjbtb7tu86d7j04uqx9	plugin::upload.configure-view	{}	\N	{}	[]	2025-08-22 12:50:23.782	2025-08-22 12:50:23.782	2025-08-22 12:50:23.782	\N	\N	\N
29	e66v2hq1sef4hrb8rolq1hgp	plugin::upload.settings.read	{}	\N	{}	[]	2025-08-22 12:50:23.798	2025-08-22 12:50:23.798	2025-08-22 12:50:23.799	\N	\N	\N
30	j4bcydumtismsdi6mai276pn	plugin::i18n.locale.create	{}	\N	{}	[]	2025-08-22 12:50:23.808	2025-08-22 12:50:23.808	2025-08-22 12:50:23.808	\N	\N	\N
31	c7l03hhk73paxehcf5bs6ef2	plugin::i18n.locale.read	{}	\N	{}	[]	2025-08-22 12:50:23.814	2025-08-22 12:50:23.814	2025-08-22 12:50:23.814	\N	\N	\N
32	im14yitufbe28o6tul65ukjv	plugin::i18n.locale.update	{}	\N	{}	[]	2025-08-22 12:50:23.82	2025-08-22 12:50:23.82	2025-08-22 12:50:23.82	\N	\N	\N
33	jy050mf7oa89uwgwl38mi3gv	plugin::i18n.locale.delete	{}	\N	{}	[]	2025-08-22 12:50:23.827	2025-08-22 12:50:23.827	2025-08-22 12:50:23.828	\N	\N	\N
34	m115ht761wthmt06z9meu2ov	plugin::users-permissions.roles.create	{}	\N	{}	[]	2025-08-22 12:50:23.838	2025-08-22 12:50:23.838	2025-08-22 12:50:23.838	\N	\N	\N
35	sgvkg4tsrf5fhde53zk6a162	plugin::users-permissions.roles.read	{}	\N	{}	[]	2025-08-22 12:50:23.843	2025-08-22 12:50:23.843	2025-08-22 12:50:23.843	\N	\N	\N
36	jv394kiestdgd2fnolvrjcvz	plugin::users-permissions.roles.update	{}	\N	{}	[]	2025-08-22 12:50:23.853	2025-08-22 12:50:23.853	2025-08-22 12:50:23.853	\N	\N	\N
37	rbdsowcf1mxvasyiy9c4wssc	plugin::users-permissions.roles.delete	{}	\N	{}	[]	2025-08-22 12:50:23.859	2025-08-22 12:50:23.859	2025-08-22 12:50:23.859	\N	\N	\N
38	wuivq6eoj8imiu9d64awpzjd	plugin::users-permissions.providers.read	{}	\N	{}	[]	2025-08-22 12:50:23.867	2025-08-22 12:50:23.867	2025-08-22 12:50:23.867	\N	\N	\N
39	pgv7nak450mth5bq65py8ss7	plugin::users-permissions.providers.update	{}	\N	{}	[]	2025-08-22 12:50:23.873	2025-08-22 12:50:23.873	2025-08-22 12:50:23.873	\N	\N	\N
40	plrqkvjkd552rv5iui90f1rz	plugin::users-permissions.email-templates.read	{}	\N	{}	[]	2025-08-22 12:50:23.881	2025-08-22 12:50:23.881	2025-08-22 12:50:23.881	\N	\N	\N
41	hm2a8d3c1wo3o0pty6k22ho0	plugin::users-permissions.email-templates.update	{}	\N	{}	[]	2025-08-22 12:50:23.889	2025-08-22 12:50:23.889	2025-08-22 12:50:23.889	\N	\N	\N
42	aq7hngim3xelxtoyb2le8he5	plugin::users-permissions.advanced-settings.read	{}	\N	{}	[]	2025-08-22 12:50:23.898	2025-08-22 12:50:23.898	2025-08-22 12:50:23.898	\N	\N	\N
43	hdkzkzknmmcygugzng4353dq	plugin::users-permissions.advanced-settings.update	{}	\N	{}	[]	2025-08-22 12:50:23.906	2025-08-22 12:50:23.906	2025-08-22 12:50:23.906	\N	\N	\N
44	p7yq4vzlsv4fqao2wnrxjfhx	admin::marketplace.read	{}	\N	{}	[]	2025-08-22 12:50:23.912	2025-08-22 12:50:23.912	2025-08-22 12:50:23.912	\N	\N	\N
45	v0tz1n9o1g3q5tyb904jdxkm	admin::webhooks.create	{}	\N	{}	[]	2025-08-22 12:50:23.918	2025-08-22 12:50:23.918	2025-08-22 12:50:23.919	\N	\N	\N
46	iny8d4uwgi56bv3p3jbvj1ib	admin::webhooks.read	{}	\N	{}	[]	2025-08-22 12:50:23.929	2025-08-22 12:50:23.929	2025-08-22 12:50:23.93	\N	\N	\N
47	rsc0of47gvw00ovk03n4nm9g	admin::webhooks.update	{}	\N	{}	[]	2025-08-22 12:50:23.936	2025-08-22 12:50:23.936	2025-08-22 12:50:23.937	\N	\N	\N
48	prcx080azb3fx0n7jgk4807o	admin::webhooks.delete	{}	\N	{}	[]	2025-08-22 12:50:23.944	2025-08-22 12:50:23.944	2025-08-22 12:50:23.944	\N	\N	\N
49	v2n45w431rblxzc7aotxzhuk	admin::users.create	{}	\N	{}	[]	2025-08-22 12:50:23.957	2025-08-22 12:50:23.957	2025-08-22 12:50:23.957	\N	\N	\N
50	o5wjfo23xhcsxbjdpwtw2638	admin::users.read	{}	\N	{}	[]	2025-08-22 12:50:23.968	2025-08-22 12:50:23.968	2025-08-22 12:50:23.968	\N	\N	\N
51	ped9p5u8ry9p03czftib8aud	admin::users.update	{}	\N	{}	[]	2025-08-22 12:50:23.974	2025-08-22 12:50:23.974	2025-08-22 12:50:23.975	\N	\N	\N
52	soj0e6701s9tipa1yyn1a10j	admin::users.delete	{}	\N	{}	[]	2025-08-22 12:50:23.983	2025-08-22 12:50:23.983	2025-08-22 12:50:23.984	\N	\N	\N
53	gnbfql3cthlni2y1iykf4bwa	admin::roles.create	{}	\N	{}	[]	2025-08-22 12:50:23.99	2025-08-22 12:50:23.99	2025-08-22 12:50:23.99	\N	\N	\N
54	inh5txm0qz2nvc69oywo0e2c	admin::roles.read	{}	\N	{}	[]	2025-08-22 12:50:23.999	2025-08-22 12:50:23.999	2025-08-22 12:50:23.999	\N	\N	\N
55	aox802okt0lmj6oxnn977qd2	admin::roles.update	{}	\N	{}	[]	2025-08-22 12:50:24.005	2025-08-22 12:50:24.005	2025-08-22 12:50:24.006	\N	\N	\N
56	kn4a1y006e2gwykyhmbw7cga	admin::roles.delete	{}	\N	{}	[]	2025-08-22 12:50:24.017	2025-08-22 12:50:24.017	2025-08-22 12:50:24.017	\N	\N	\N
57	k31b01d2b6qxctyj3jnxuwdz	admin::api-tokens.access	{}	\N	{}	[]	2025-08-22 12:50:24.026	2025-08-22 12:50:24.026	2025-08-22 12:50:24.026	\N	\N	\N
58	zrty9uaqc2rx8ta08k8s28fd	admin::api-tokens.create	{}	\N	{}	[]	2025-08-22 12:50:24.034	2025-08-22 12:50:24.034	2025-08-22 12:50:24.035	\N	\N	\N
59	wpoq4gm0lpkc1abmtukiyc7e	admin::api-tokens.read	{}	\N	{}	[]	2025-08-22 12:50:24.042	2025-08-22 12:50:24.042	2025-08-22 12:50:24.042	\N	\N	\N
60	evxq9fybroys11xuggmknexb	admin::api-tokens.update	{}	\N	{}	[]	2025-08-22 12:50:24.054	2025-08-22 12:50:24.054	2025-08-22 12:50:24.054	\N	\N	\N
61	rv8a8h30ifxo3j6sskoexor1	admin::api-tokens.regenerate	{}	\N	{}	[]	2025-08-22 12:50:24.061	2025-08-22 12:50:24.061	2025-08-22 12:50:24.061	\N	\N	\N
62	qg4iqx96m301q739bmgcldip	admin::api-tokens.delete	{}	\N	{}	[]	2025-08-22 12:50:24.071	2025-08-22 12:50:24.071	2025-08-22 12:50:24.071	\N	\N	\N
63	v87lle5r3nif6nq23lizqkps	admin::project-settings.update	{}	\N	{}	[]	2025-08-22 12:50:24.077	2025-08-22 12:50:24.077	2025-08-22 12:50:24.077	\N	\N	\N
64	npphmxigx6vf80szkqqzufor	admin::project-settings.read	{}	\N	{}	[]	2025-08-22 12:50:24.084	2025-08-22 12:50:24.084	2025-08-22 12:50:24.084	\N	\N	\N
65	ghy36q4bgha1q90w94mwbnpj	admin::transfer.tokens.access	{}	\N	{}	[]	2025-08-22 12:50:24.095	2025-08-22 12:50:24.095	2025-08-22 12:50:24.095	\N	\N	\N
66	nozw6vj4utouxos87adaglmd	admin::transfer.tokens.create	{}	\N	{}	[]	2025-08-22 12:50:24.102	2025-08-22 12:50:24.102	2025-08-22 12:50:24.102	\N	\N	\N
67	ojur4qmp3kx6ott9tbutfh3l	admin::transfer.tokens.read	{}	\N	{}	[]	2025-08-22 12:50:24.12	2025-08-22 12:50:24.12	2025-08-22 12:50:24.12	\N	\N	\N
68	wr4etzutrf6wfbeqeni5l7cj	admin::transfer.tokens.update	{}	\N	{}	[]	2025-08-22 12:50:24.132	2025-08-22 12:50:24.132	2025-08-22 12:50:24.132	\N	\N	\N
69	q7bxbtp9xlymw2gop0mkcq78	admin::transfer.tokens.regenerate	{}	\N	{}	[]	2025-08-22 12:50:24.143	2025-08-22 12:50:24.143	2025-08-22 12:50:24.143	\N	\N	\N
70	kwdkcy03u23mzmrv50g1azs1	admin::transfer.tokens.delete	{}	\N	{}	[]	2025-08-22 12:50:24.155	2025-08-22 12:50:24.155	2025-08-22 12:50:24.155	\N	\N	\N
77	au3ng502a99h04hqvs2b4hut	plugin::content-manager.explorer.delete	{}	api::product.product	{}	[]	2025-08-27 16:27:49.949	2025-08-27 16:27:49.949	2025-08-27 16:27:49.949	\N	\N	\N
78	l6af3de1xx3trfoijvl5ogt8	plugin::content-manager.explorer.publish	{}	api::product.product	{}	[]	2025-08-27 16:27:49.956	2025-08-27 16:27:49.956	2025-08-27 16:27:49.957	\N	\N	\N
82	srqbv88ltuyry55mfp6tv5wb	plugin::content-manager.explorer.delete	{}	api::category.category	{}	[]	2025-08-27 22:22:06.651	2025-08-27 22:22:06.651	2025-08-27 22:22:06.651	\N	\N	\N
83	gncl0e1id6jkgopl8i8grwc4	plugin::content-manager.explorer.publish	{}	api::category.category	{}	[]	2025-08-27 22:22:06.656	2025-08-27 22:22:06.656	2025-08-27 22:22:06.656	\N	\N	\N
102	yntcubs29844obsyvqoxovt2	plugin::content-manager.explorer.create	{}	api::category.category	{"fields": ["title", "slug", "parent", "children", "products", "imgUrl"]}	[]	2025-08-28 20:08:46.31	2025-08-28 20:08:46.31	2025-08-28 20:08:46.311	\N	\N	\N
103	bz8eyeix0mnl8rhlotxic3w8	plugin::content-manager.explorer.read	{}	api::category.category	{"fields": ["title", "slug", "parent", "children", "products", "imgUrl"]}	[]	2025-08-28 20:08:46.321	2025-08-28 20:08:46.321	2025-08-28 20:08:46.321	\N	\N	\N
104	ubcf6ucskit8chvccv19lbum	plugin::content-manager.explorer.update	{}	api::category.category	{"fields": ["title", "slug", "parent", "children", "products", "imgUrl"]}	[]	2025-08-28 20:08:46.327	2025-08-28 20:08:46.327	2025-08-28 20:08:46.328	\N	\N	\N
108	imgrk4mdd3n0ms948k734vat	plugin::content-manager.explorer.create	{}	api::product.product	{"fields": ["title", "slug", "price", "images", "category", "description"]}	[]	2025-08-28 20:26:19.413	2025-08-28 20:26:19.413	2025-08-28 20:26:19.414	\N	\N	\N
109	tqti0i2q7jjdemaacrvo2xkw	plugin::content-manager.explorer.read	{}	api::product.product	{"fields": ["title", "slug", "price", "images", "category", "description"]}	[]	2025-08-28 20:26:19.424	2025-08-28 20:26:19.424	2025-08-28 20:26:19.425	\N	\N	\N
110	gu8be5fqr9x8y6fbwn0hoxz2	plugin::content-manager.explorer.update	{}	api::product.product	{"fields": ["title", "slug", "price", "images", "category", "description"]}	[]	2025-08-28 20:26:19.43	2025-08-28 20:26:19.43	2025-08-28 20:26:19.43	\N	\N	\N
146	oi4qwskl9lvrtw65ozb7plka	plugin::content-manager.explorer.create	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "client_documents"]}	[]	2025-10-27 23:41:12.348	2025-10-27 23:41:12.348	2025-10-27 23:41:12.348	\N	\N	\N
148	hmptrz0t4nls5phcjn8fptkh	plugin::content-manager.explorer.read	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "client_documents"]}	[]	2025-10-27 23:41:12.364	2025-10-27 23:41:12.364	2025-10-27 23:41:12.365	\N	\N	\N
150	y98dktf0kbm8enoqm4p2he31	plugin::content-manager.explorer.update	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "client_documents"]}	[]	2025-10-27 23:41:12.377	2025-10-27 23:41:12.377	2025-10-27 23:41:12.378	\N	\N	\N
151	slzfbucy4k4hj09t23il7v96	plugin::content-manager.explorer.delete	{}	api::client-document.client-document	{}	[]	2025-10-27 23:41:12.383	2025-10-27 23:41:12.383	2025-10-27 23:41:12.383	\N	\N	\N
152	vlh8k5pngpifa7xf3xhf62x2	plugin::content-manager.explorer.publish	{}	api::client-document.client-document	{}	[]	2025-10-27 23:41:12.388	2025-10-27 23:41:12.388	2025-10-27 23:41:12.389	\N	\N	\N
153	xj5tpk73za7m5yhx19iupjtn	plugin::content-manager.explorer.create	{}	api::client-document.client-document	{"fields": ["title", "client_doc", "description"]}	[]	2025-10-31 18:29:28.433	2025-10-31 18:29:28.433	2025-10-31 18:29:28.434	\N	\N	\N
154	ycyx81xnfw1ex79cafgb0535	plugin::content-manager.explorer.read	{}	api::client-document.client-document	{"fields": ["title", "client_doc", "description"]}	[]	2025-10-31 18:29:28.456	2025-10-31 18:29:28.456	2025-10-31 18:29:28.456	\N	\N	\N
155	beiu7q1x8z7avw9qwhn96548	plugin::content-manager.explorer.update	{}	api::client-document.client-document	{"fields": ["title", "client_doc", "description"]}	[]	2025-10-31 18:29:28.463	2025-10-31 18:29:28.463	2025-10-31 18:29:28.464	\N	\N	\N
\.


--
-- Data for Name: admin_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.admin_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	2	1
2	2	2	2
3	3	2	3
4	4	2	4
5	5	2	5
6	6	2	6
7	7	3	1
8	8	3	2
9	9	3	3
10	10	3	4
11	11	3	5
12	12	3	6
16	16	1	4
17	17	1	5
18	18	1	6
19	19	1	7
20	20	1	8
21	21	1	9
22	22	1	10
23	23	1	11
24	24	1	12
25	25	1	13
26	26	1	14
27	27	1	15
28	28	1	16
29	29	1	17
30	30	1	18
31	31	1	19
32	32	1	20
33	33	1	21
34	34	1	22
35	35	1	23
36	36	1	24
37	37	1	25
38	38	1	26
39	39	1	27
40	40	1	28
41	41	1	29
42	42	1	30
43	43	1	31
44	44	1	32
45	45	1	33
46	46	1	34
47	47	1	35
48	48	1	36
49	49	1	37
50	50	1	38
51	51	1	39
52	52	1	40
53	53	1	41
54	54	1	42
55	55	1	43
56	56	1	44
57	57	1	45
58	58	1	46
59	59	1	47
60	60	1	48
61	61	1	49
62	62	1	50
63	63	1	51
64	64	1	52
65	65	1	53
66	66	1	54
67	67	1	55
68	68	1	56
69	69	1	57
70	70	1	58
77	77	1	65
78	78	1	66
82	82	1	70
83	83	1	71
102	102	1	87
103	103	1	88
104	104	1	89
108	108	1	90
109	109	1	91
110	110	1	92
146	146	1	94
148	148	1	96
150	150	1	98
151	151	1	99
152	152	1	100
153	153	1	101
154	154	1	102
155	155	1	103
\.


--
-- Data for Name: admin_roles; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.admin_roles (id, document_id, name, code, description, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	b4jch4d9vsg17acpurlkhlaw	Super Admin	strapi-super-admin	Super Admins can access and manage all features and settings.	2025-08-22 12:50:23.355	2025-08-22 12:50:23.355	2025-08-22 12:50:23.355	\N	\N	\N
2	ib6vuo8b4hc4fwtoxg5lrzez	Editor	strapi-editor	Editors can manage and publish contents including those of other users.	2025-08-22 12:50:23.375	2025-08-22 12:50:23.375	2025-08-22 12:50:23.375	\N	\N	\N
3	pj78u4z59tev0xb9ppimuuev	Author	strapi-author	Authors can manage the content they have created.	2025-08-22 12:50:23.38	2025-08-22 12:50:23.38	2025-08-22 12:50:23.38	\N	\N	\N
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.admin_users (id, document_id, firstname, lastname, username, email, password, reset_password_token, registration_token, is_active, blocked, prefered_language, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	yijg4lv850wqbqho28hiey5n	Erl	Me	\N	erlendas.me@gmail.com	$2a$10$QnMz8U72zYNga.kvW7UyNeIlVozTYFfWol/t2aaD4Ehy68mN4w9Xy	\N	\N	t	f	\N	2025-08-23 08:00:07.648	2025-08-23 08:00:07.648	2025-08-23 08:00:07.665	\N	\N	\N
2	lr0p6wiwh0diutourt94qhno	Orio	me	Orio	info@purinta.lt	$2a$10$jiGeySjoWeChorDMCgRxruiepLUcDCuMjagM5FGxE4WXTJI33oUuy	\N	c70782e321e7e1cb5965be3770212f057fe19924	t	f	\N	2025-08-24 23:15:37.29	2025-08-24 23:20:43.199	2025-08-24 23:15:37.291	\N	\N	\N
\.


--
-- Data for Name: admin_users_roles_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.admin_users_roles_lnk (id, user_id, role_id, role_ord, user_ord) FROM stdin;
1	1	1	1	1
2	2	3	1	1
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.categories (id, document_id, title, slug, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
24	v70vv1wpwa8d88zx4gkvh41s	Гольфы	golfy	2025-10-21 15:21:08.129	2025-10-25 16:00:08.137	\N	1	1	\N
60	i59k8d2hzr69a2w4slxjeaep	Корсеты на поясничный отдел	korset-pojas	2025-10-21 15:32:23.349	2025-10-25 17:44:59.588	2025-10-25 17:44:59.616	1	1	\N
52	v70vv1wpwa8d88zx4gkvh41s	Гольфы	golfy	2025-10-21 15:21:08.129	2025-10-25 16:00:08.137	2025-10-25 16:00:08.176	1	1	\N
18	hs7uz2h6tyolsdeqc75fwy90	Чулки антиэмболические	culki-antiembolic	2025-10-21 12:54:29.905	2025-10-25 16:01:20.957	\N	1	1	\N
53	hs7uz2h6tyolsdeqc75fwy90	Чулки антиэмболические	culki-antiembolic	2025-10-21 12:54:29.905	2025-10-25 16:01:20.957	2025-10-25 16:01:20.987	1	1	\N
14	iacxmuj4kxeraydw17egnqyf	Бандажи	bandazhi	2025-10-21 12:51:13.43	2025-10-25 14:20:02.547	\N	1	1	\N
46	iacxmuj4kxeraydw17egnqyf	Бандажи	bandazhi	2025-10-21 12:51:13.43	2025-10-25 14:20:02.547	2025-10-25 14:20:02.585	1	1	\N
10	epo79xu9pg2sqy7x9zcet6rv	Компрессионный трикотаж	kompressionnyj-trikotazh	2025-10-21 12:46:41.453	2025-10-25 15:07:20.567	\N	1	1	\N
47	epo79xu9pg2sqy7x9zcet6rv	Компрессионный трикотаж	kompressionnyj-trikotazh	2025-10-21 12:46:41.453	2025-10-25 15:07:20.567	2025-10-25 15:07:20.603	1	1	\N
16	hslk09ehlyp5d1i58stl57ge	Корсеты	korsety	2025-10-21 12:52:14.149	2025-10-25 15:09:35.677	\N	1	1	\N
48	hslk09ehlyp5d1i58stl57ge	Корсеты	korsety	2025-10-21 12:52:14.149	2025-10-25 15:09:35.677	2025-10-25 15:09:35.706	1	1	\N
12	e78h7g23rsc2hdrg39ospnya	Ортопедические стельки	ortopedicheskie-stelki	2025-10-21 12:48:30.092	2025-10-25 15:23:44.682	\N	1	1	\N
49	e78h7g23rsc2hdrg39ospnya	Ортопедические стельки	ortopedicheskie-stelki	2025-10-21 12:48:30.092	2025-10-25 15:23:44.682	2025-10-25 15:23:44.71	1	1	\N
28	qutg4b2uk9grghsxj6r7q0dn	Стельки для детей	polustelki	2025-10-21 15:22:51.25	2025-10-25 15:26:15.372	\N	1	1	\N
50	qutg4b2uk9grghsxj6r7q0dn	Стельки для детей	polustelki	2025-10-21 15:22:51.25	2025-10-25 15:26:15.372	2025-10-25 15:26:15.4	1	1	\N
26	x32zagwkebzmsqpe8umd42hh	Стельки для взрослых	stelki	2025-10-21 15:22:07.318	2025-10-25 15:31:33.991	\N	1	1	\N
51	x32zagwkebzmsqpe8umd42hh	Стельки для взрослых	stelki	2025-10-21 15:22:07.318	2025-10-25 15:31:33.991	2025-10-25 15:31:34.022	1	1	\N
22	rzc6x8b3yz9sefugyity1zps	Чулки компрессионные	culki-kompressionnyje	2025-10-21 12:58:53.373	2025-10-25 16:02:01.849	\N	1	1	\N
54	rzc6x8b3yz9sefugyity1zps	Чулки компрессионные	culki-kompressionnyje	2025-10-21 12:58:53.373	2025-10-25 16:02:01.849	2025-10-25 16:02:01.879	1	1	\N
36	ds15cw8xfrkd9q6tyddcocp3	Бандажи на голеностоп	bandazhi-golenostop	2025-10-21 15:31:26.528	2025-10-25 16:03:57.467	\N	1	1	\N
55	ds15cw8xfrkd9q6tyddcocp3	Бандажи на голеностоп	bandazhi-golenostop	2025-10-21 15:31:26.528	2025-10-25 16:03:57.467	2025-10-25 16:03:57.497	1	1	\N
30	bjlh8mqi7kvnvqerphstdomz	Бандажи на колено	bandazhi-koleno	2025-10-21 15:26:45.579	2025-10-25 16:04:44.069	\N	1	1	\N
56	bjlh8mqi7kvnvqerphstdomz	Бандажи на колено	bandazhi-koleno	2025-10-21 15:26:45.579	2025-10-25 16:04:44.069	2025-10-25 16:04:44.096	1	1	\N
34	q9cci9ql925c9yko0z9qutqk	Бандажи на локоть	bandazhi-lokot	2025-10-21 15:30:22.799	2025-10-25 16:05:35.613	\N	1	1	\N
57	q9cci9ql925c9yko0z9qutqk	Бандажи на локоть	bandazhi-lokot	2025-10-21 15:30:22.799	2025-10-25 16:05:35.613	2025-10-25 16:05:35.64	1	1	\N
32	c8doyzgxky8hnsohi6epmgek	Бандажи на руку	bandazhi-ruka	2025-10-21 15:28:32.963	2025-10-25 16:06:34.516	\N	1	1	\N
58	c8doyzgxky8hnsohi6epmgek	Бандажи на руку	bandazhi-ruka	2025-10-21 15:28:32.963	2025-10-25 16:06:34.516	2025-10-25 16:06:34.541	1	1	\N
41	iv760jxxn8hwlo04ujutj7u1	Корсеты на пояснично-крестцовый отдел	korsety-krest	2025-10-21 15:34:26.407	2025-10-25 17:44:25.246	\N	1	1	\N
59	iv760jxxn8hwlo04ujutj7u1	Корсеты на пояснично-крестцовый отдел	korsety-krest	2025-10-21 15:34:26.407	2025-10-25 17:44:25.246	2025-10-25 17:44:25.277	1	1	\N
38	i59k8d2hzr69a2w4slxjeaep	Корсеты на поясничный отдел	korset-pojas	2025-10-21 15:32:23.349	2025-10-25 17:44:59.588	\N	1	1	\N
\.


--
-- Data for Name: categories_parent_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.categories_parent_lnk (id, category_id, inv_category_id, category_ord) FROM stdin;
4	22	10	1
6	24	10	2
8	26	12	1
10	28	12	2
12	30	14	1
14	32	14	2
16	34	14	3
18	36	14	4
20	38	16	1
23	41	16	2
27	18	10	3
40	50	49	2
41	51	49	3
42	52	47	4
43	53	47	5
44	54	47	6
45	55	46	4
46	56	46	5
47	57	46	6
48	58	46	7
49	59	48	2
50	60	48	3
\.


--
-- Data for Name: client_documents; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.client_documents (id, document_id, title, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, description) FROM stdin;
1	ha5e6cjyndiguoqva7zcvpuj	File	2025-10-27 23:48:57.489	2025-10-27 23:48:57.489	\N	1	1	\N	\N
2	ha5e6cjyndiguoqva7zcvpuj	File	2025-10-27 23:48:57.489	2025-10-27 23:48:57.489	2025-10-27 23:48:57.522	1	1	\N	\N
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.files (id, document_id, name, alternative_text, caption, width, height, formats, hash, ext, mime, size, url, preview_url, provider, provider_metadata, folder_path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
3	r9jxd1rvhtbpn2rhkpkjjuzj	ladylegs_logo.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_ladylegs_logo_2d36740048.jpg", "hash": "large_ladylegs_logo_2d36740048", "mime": "image/jpeg", "name": "large_ladylegs_logo.jpg", "path": null, "size": 27.91, "width": 1000, "height": 1000, "sizeInBytes": 27912}, "small": {"ext": ".jpg", "url": "/uploads/small_ladylegs_logo_2d36740048.jpg", "hash": "small_ladylegs_logo_2d36740048", "mime": "image/jpeg", "name": "small_ladylegs_logo.jpg", "path": null, "size": 9.5, "width": 500, "height": 500, "sizeInBytes": 9499}, "medium": {"ext": ".jpg", "url": "/uploads/medium_ladylegs_logo_2d36740048.jpg", "hash": "medium_ladylegs_logo_2d36740048", "mime": "image/jpeg", "name": "medium_ladylegs_logo.jpg", "path": null, "size": 17.59, "width": 750, "height": 750, "sizeInBytes": 17589}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_ladylegs_logo_2d36740048.jpg", "hash": "thumbnail_ladylegs_logo_2d36740048", "mime": "image/jpeg", "name": "thumbnail_ladylegs_logo.jpg", "path": null, "size": 1.98, "width": 156, "height": 156, "sizeInBytes": 1980}}	ladylegs_logo_2d36740048	.jpg	image/jpeg	98.42	/uploads/ladylegs_logo_2d36740048.jpg	\N	local	\N	/	2025-08-28 17:23:49.603	2025-08-28 21:57:39.045	2025-08-28 17:23:49.606	1	1	\N
1	b72h2j8fqc8w8lpbf9gyucyo	T1.jpg	\N	\N	1152	648	{"large": {"ext": ".jpg", "url": "/uploads/large_T1_7c37090cb9.jpg", "hash": "large_T1_7c37090cb9", "mime": "image/jpeg", "name": "large_T1.jpg", "path": null, "size": 20.68, "width": 1000, "height": 563, "sizeInBytes": 20680}, "small": {"ext": ".jpg", "url": "/uploads/small_T1_7c37090cb9.jpg", "hash": "small_T1_7c37090cb9", "mime": "image/jpeg", "name": "small_T1.jpg", "path": null, "size": 7.73, "width": 500, "height": 281, "sizeInBytes": 7728}, "medium": {"ext": ".jpg", "url": "/uploads/medium_T1_7c37090cb9.jpg", "hash": "medium_T1_7c37090cb9", "mime": "image/jpeg", "name": "medium_T1.jpg", "path": null, "size": 13.7, "width": 750, "height": 422, "sizeInBytes": 13703}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_T1_7c37090cb9.jpg", "hash": "thumbnail_T1_7c37090cb9", "mime": "image/jpeg", "name": "thumbnail_T1.jpg", "path": null, "size": 2.95, "width": 245, "height": 138, "sizeInBytes": 2946}}	T1_7c37090cb9	.jpg	image/jpeg	25.76	/uploads/T1_7c37090cb9.jpg	\N	local	\N	/1	2025-08-28 11:46:08.975	2025-08-28 11:46:08.975	2025-08-28 11:46:08.975	1	1	\N
2	wg56iskgie73gq27sw98siyb	КТ_баннер.jpg	\N	\N	835	826	{"small": {"ext": ".jpg", "url": "/uploads/small_KT_banner_9a89a54c8a.jpg", "hash": "small_KT_banner_9a89a54c8a", "mime": "image/jpeg", "name": "small_КТ_баннер.jpg", "path": null, "size": 33.38, "width": 500, "height": 495, "sizeInBytes": 33381}, "medium": {"ext": ".jpg", "url": "/uploads/medium_KT_banner_9a89a54c8a.jpg", "hash": "medium_KT_banner_9a89a54c8a", "mime": "image/jpeg", "name": "medium_КТ_баннер.jpg", "path": null, "size": 66.28, "width": 750, "height": 742, "sizeInBytes": 66277}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_KT_banner_9a89a54c8a.jpg", "hash": "thumbnail_KT_banner_9a89a54c8a", "mime": "image/jpeg", "name": "thumbnail_КТ_баннер.jpg", "path": null, "size": 5.06, "width": 158, "height": 156, "sizeInBytes": 5061}}	KT_banner_9a89a54c8a	.jpg	image/jpeg	82.16	/uploads/KT_banner_9a89a54c8a.jpg	\N	local	\N	/1	2025-08-28 11:51:56.368	2025-08-28 11:51:56.368	2025-08-28 11:51:56.369	1	1	\N
4	hzqnvs0knlxpeak64hnfhk19	T1AG1_ПЭТ чулок муж.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_T1_AG_1_PET_chulok_muzh_a5e059bb0d.jpg", "hash": "large_T1_AG_1_PET_chulok_muzh_a5e059bb0d", "mime": "image/jpeg", "name": "large_T1AG1_ПЭТ чулок муж.jpg", "path": null, "size": 31.75, "width": 1000, "height": 1000, "sizeInBytes": 31747}, "small": {"ext": ".jpg", "url": "/uploads/small_T1_AG_1_PET_chulok_muzh_a5e059bb0d.jpg", "hash": "small_T1_AG_1_PET_chulok_muzh_a5e059bb0d", "mime": "image/jpeg", "name": "small_T1AG1_ПЭТ чулок муж.jpg", "path": null, "size": 10.13, "width": 500, "height": 500, "sizeInBytes": 10131}, "medium": {"ext": ".jpg", "url": "/uploads/medium_T1_AG_1_PET_chulok_muzh_a5e059bb0d.jpg", "hash": "medium_T1_AG_1_PET_chulok_muzh_a5e059bb0d", "mime": "image/jpeg", "name": "medium_T1AG1_ПЭТ чулок муж.jpg", "path": null, "size": 19.28, "width": 750, "height": 750, "sizeInBytes": 19279}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_T1_AG_1_PET_chulok_muzh_a5e059bb0d.jpg", "hash": "thumbnail_T1_AG_1_PET_chulok_muzh_a5e059bb0d", "mime": "image/jpeg", "name": "thumbnail_T1AG1_ПЭТ чулок муж.jpg", "path": null, "size": 1.9, "width": 156, "height": 156, "sizeInBytes": 1901}}	T1_AG_1_PET_chulok_muzh_a5e059bb0d	.jpg	image/jpeg	120.90	/uploads/T1_AG_1_PET_chulok_muzh_a5e059bb0d.jpg	\N	local	\N	/	2025-10-24 17:58:45.313	2025-10-24 17:58:45.313	2025-10-24 17:58:45.314	1	1	\N
5	lthx0ko2u1ryz80avchjm8rr	T1AG1_ПЭТ чулок силикон.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_T1_AG_1_PET_chulok_silikon_401f6c0fe8.jpg", "hash": "large_T1_AG_1_PET_chulok_silikon_401f6c0fe8", "mime": "image/jpeg", "name": "large_T1AG1_ПЭТ чулок силикон.jpg", "path": null, "size": 125.18, "width": 1000, "height": 1000, "sizeInBytes": 125182}, "small": {"ext": ".jpg", "url": "/uploads/small_T1_AG_1_PET_chulok_silikon_401f6c0fe8.jpg", "hash": "small_T1_AG_1_PET_chulok_silikon_401f6c0fe8", "mime": "image/jpeg", "name": "small_T1AG1_ПЭТ чулок силикон.jpg", "path": null, "size": 28.94, "width": 500, "height": 500, "sizeInBytes": 28937}, "medium": {"ext": ".jpg", "url": "/uploads/medium_T1_AG_1_PET_chulok_silikon_401f6c0fe8.jpg", "hash": "medium_T1_AG_1_PET_chulok_silikon_401f6c0fe8", "mime": "image/jpeg", "name": "medium_T1AG1_ПЭТ чулок силикон.jpg", "path": null, "size": 68.39, "width": 750, "height": 750, "sizeInBytes": 68386}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_T1_AG_1_PET_chulok_silikon_401f6c0fe8.jpg", "hash": "thumbnail_T1_AG_1_PET_chulok_silikon_401f6c0fe8", "mime": "image/jpeg", "name": "thumbnail_T1AG1_ПЭТ чулок силикон.jpg", "path": null, "size": 3.56, "width": 156, "height": 156, "sizeInBytes": 3559}}	T1_AG_1_PET_chulok_silikon_401f6c0fe8	.jpg	image/jpeg	493.01	/uploads/T1_AG_1_PET_chulok_silikon_401f6c0fe8.jpg	\N	local	\N	/	2025-10-24 17:59:41.239	2025-10-24 17:59:41.239	2025-10-24 17:59:41.24	1	1	\N
6	i5f7c07amjeokrchiia8v5v7	T1AG1_ПЭТ чулок стопа.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_T1_AG_1_PET_chulok_stopa_ab581249b2.jpg", "hash": "large_T1_AG_1_PET_chulok_stopa_ab581249b2", "mime": "image/jpeg", "name": "large_T1AG1_ПЭТ чулок стопа.jpg", "path": null, "size": 57.17, "width": 1000, "height": 1000, "sizeInBytes": 57169}, "small": {"ext": ".jpg", "url": "/uploads/small_T1_AG_1_PET_chulok_stopa_ab581249b2.jpg", "hash": "small_T1_AG_1_PET_chulok_stopa_ab581249b2", "mime": "image/jpeg", "name": "small_T1AG1_ПЭТ чулок стопа.jpg", "path": null, "size": 9.54, "width": 500, "height": 500, "sizeInBytes": 9542}, "medium": {"ext": ".jpg", "url": "/uploads/medium_T1_AG_1_PET_chulok_stopa_ab581249b2.jpg", "hash": "medium_T1_AG_1_PET_chulok_stopa_ab581249b2", "mime": "image/jpeg", "name": "medium_T1AG1_ПЭТ чулок стопа.jpg", "path": null, "size": 25.79, "width": 750, "height": 750, "sizeInBytes": 25789}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_T1_AG_1_PET_chulok_stopa_ab581249b2.jpg", "hash": "thumbnail_T1_AG_1_PET_chulok_stopa_ab581249b2", "mime": "image/jpeg", "name": "thumbnail_T1AG1_ПЭТ чулок стопа.jpg", "path": null, "size": 1.72, "width": 156, "height": 156, "sizeInBytes": 1722}}	T1_AG_1_PET_chulok_stopa_ab581249b2	.jpg	image/jpeg	315.96	/uploads/T1_AG_1_PET_chulok_stopa_ab581249b2.jpg	\N	local	\N	/	2025-10-24 18:00:09.521	2025-10-24 18:00:09.521	2025-10-24 18:00:09.521	1	1	\N
7	pfuu2j7buvaaqw4gxnvsbk4n	T1AG1_ПЭТ чулок эласт.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_T1_AG_1_PET_chulok_elast_2e53ea1333.jpg", "hash": "large_T1_AG_1_PET_chulok_elast_2e53ea1333", "mime": "image/jpeg", "name": "large_T1AG1_ПЭТ чулок эласт.jpg", "path": null, "size": 73.95, "width": 1000, "height": 1000, "sizeInBytes": 73950}, "small": {"ext": ".jpg", "url": "/uploads/small_T1_AG_1_PET_chulok_elast_2e53ea1333.jpg", "hash": "small_T1_AG_1_PET_chulok_elast_2e53ea1333", "mime": "image/jpeg", "name": "small_T1AG1_ПЭТ чулок эласт.jpg", "path": null, "size": 17.52, "width": 500, "height": 500, "sizeInBytes": 17519}, "medium": {"ext": ".jpg", "url": "/uploads/medium_T1_AG_1_PET_chulok_elast_2e53ea1333.jpg", "hash": "medium_T1_AG_1_PET_chulok_elast_2e53ea1333", "mime": "image/jpeg", "name": "medium_T1AG1_ПЭТ чулок эласт.jpg", "path": null, "size": 41.83, "width": 750, "height": 750, "sizeInBytes": 41833}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_T1_AG_1_PET_chulok_elast_2e53ea1333.jpg", "hash": "thumbnail_T1_AG_1_PET_chulok_elast_2e53ea1333", "mime": "image/jpeg", "name": "thumbnail_T1AG1_ПЭТ чулок эласт.jpg", "path": null, "size": 2.33, "width": 156, "height": 156, "sizeInBytes": 2326}}	T1_AG_1_PET_chulok_elast_2e53ea1333	.jpg	image/jpeg	267.83	/uploads/T1_AG_1_PET_chulok_elast_2e53ea1333.jpg	\N	local	\N	/	2025-10-24 18:00:24.001	2025-10-24 18:00:24.001	2025-10-24 18:00:24.001	1	1	\N
8	q2ka5fcxbzq88vdbghaanc7t	T1AG1_ПЭТ чулок муж.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_T1_AG_1_PET_chulok_muzh_0e778d99bb.jpg", "hash": "large_T1_AG_1_PET_chulok_muzh_0e778d99bb", "mime": "image/jpeg", "name": "large_T1AG1_ПЭТ чулок муж.jpg", "path": null, "size": 31.75, "width": 1000, "height": 1000, "sizeInBytes": 31747}, "small": {"ext": ".jpg", "url": "/uploads/small_T1_AG_1_PET_chulok_muzh_0e778d99bb.jpg", "hash": "small_T1_AG_1_PET_chulok_muzh_0e778d99bb", "mime": "image/jpeg", "name": "small_T1AG1_ПЭТ чулок муж.jpg", "path": null, "size": 10.13, "width": 500, "height": 500, "sizeInBytes": 10131}, "medium": {"ext": ".jpg", "url": "/uploads/medium_T1_AG_1_PET_chulok_muzh_0e778d99bb.jpg", "hash": "medium_T1_AG_1_PET_chulok_muzh_0e778d99bb", "mime": "image/jpeg", "name": "medium_T1AG1_ПЭТ чулок муж.jpg", "path": null, "size": 19.28, "width": 750, "height": 750, "sizeInBytes": 19279}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_T1_AG_1_PET_chulok_muzh_0e778d99bb.jpg", "hash": "thumbnail_T1_AG_1_PET_chulok_muzh_0e778d99bb", "mime": "image/jpeg", "name": "thumbnail_T1AG1_ПЭТ чулок муж.jpg", "path": null, "size": 1.9, "width": 156, "height": 156, "sizeInBytes": 1901}}	T1_AG_1_PET_chulok_muzh_0e778d99bb	.jpg	image/jpeg	120.90	/uploads/T1_AG_1_PET_chulok_muzh_0e778d99bb.jpg	\N	local	\N	/	2025-10-24 19:29:31.075	2025-10-24 19:29:31.075	2025-10-24 19:29:31.075	1	1	\N
9	pz34cwfrwbqhyjzdxe3l466m	T1AG1_ПЭТ чулок стопа.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_T1_AG_1_PET_chulok_stopa_9c2b8b2d8e.jpg", "hash": "large_T1_AG_1_PET_chulok_stopa_9c2b8b2d8e", "mime": "image/jpeg", "name": "large_T1AG1_ПЭТ чулок стопа.jpg", "path": null, "size": 57.17, "width": 1000, "height": 1000, "sizeInBytes": 57169}, "small": {"ext": ".jpg", "url": "/uploads/small_T1_AG_1_PET_chulok_stopa_9c2b8b2d8e.jpg", "hash": "small_T1_AG_1_PET_chulok_stopa_9c2b8b2d8e", "mime": "image/jpeg", "name": "small_T1AG1_ПЭТ чулок стопа.jpg", "path": null, "size": 9.54, "width": 500, "height": 500, "sizeInBytes": 9542}, "medium": {"ext": ".jpg", "url": "/uploads/medium_T1_AG_1_PET_chulok_stopa_9c2b8b2d8e.jpg", "hash": "medium_T1_AG_1_PET_chulok_stopa_9c2b8b2d8e", "mime": "image/jpeg", "name": "medium_T1AG1_ПЭТ чулок стопа.jpg", "path": null, "size": 25.79, "width": 750, "height": 750, "sizeInBytes": 25789}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_T1_AG_1_PET_chulok_stopa_9c2b8b2d8e.jpg", "hash": "thumbnail_T1_AG_1_PET_chulok_stopa_9c2b8b2d8e", "mime": "image/jpeg", "name": "thumbnail_T1AG1_ПЭТ чулок стопа.jpg", "path": null, "size": 1.72, "width": 156, "height": 156, "sizeInBytes": 1722}}	T1_AG_1_PET_chulok_stopa_9c2b8b2d8e	.jpg	image/jpeg	315.96	/uploads/T1_AG_1_PET_chulok_stopa_9c2b8b2d8e.jpg	\N	local	\N	/	2025-10-24 19:53:52.08	2025-10-24 19:53:52.08	2025-10-24 19:53:52.081	1	1	\N
10	k0x3wcoefjbcm4dv29xfox18	T1AG1_ПЭТ чулок эласт.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_T1_AG_1_PET_chulok_elast_6b269f3885.jpg", "hash": "large_T1_AG_1_PET_chulok_elast_6b269f3885", "mime": "image/jpeg", "name": "large_T1AG1_ПЭТ чулок эласт.jpg", "path": null, "size": 73.95, "width": 1000, "height": 1000, "sizeInBytes": 73950}, "small": {"ext": ".jpg", "url": "/uploads/small_T1_AG_1_PET_chulok_elast_6b269f3885.jpg", "hash": "small_T1_AG_1_PET_chulok_elast_6b269f3885", "mime": "image/jpeg", "name": "small_T1AG1_ПЭТ чулок эласт.jpg", "path": null, "size": 17.52, "width": 500, "height": 500, "sizeInBytes": 17519}, "medium": {"ext": ".jpg", "url": "/uploads/medium_T1_AG_1_PET_chulok_elast_6b269f3885.jpg", "hash": "medium_T1_AG_1_PET_chulok_elast_6b269f3885", "mime": "image/jpeg", "name": "medium_T1AG1_ПЭТ чулок эласт.jpg", "path": null, "size": 41.83, "width": 750, "height": 750, "sizeInBytes": 41833}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_T1_AG_1_PET_chulok_elast_6b269f3885.jpg", "hash": "thumbnail_T1_AG_1_PET_chulok_elast_6b269f3885", "mime": "image/jpeg", "name": "thumbnail_T1AG1_ПЭТ чулок эласт.jpg", "path": null, "size": 2.33, "width": 156, "height": 156, "sizeInBytes": 2326}}	T1_AG_1_PET_chulok_elast_6b269f3885	.jpg	image/jpeg	267.83	/uploads/T1_AG_1_PET_chulok_elast_6b269f3885.jpg	\N	local	\N	/	2025-10-24 19:56:56.932	2025-10-24 19:56:56.932	2025-10-24 19:56:56.932	1	1	\N
11	equ0uuxwo6ys8pxn1zo6g1r0	T1AG1 ПЭТ упаковка.jpeg	\N	\N	1024	1536	{"large": {"ext": ".jpeg", "url": "/uploads/large_T1_AG_1_PET_upakovka_3491ce6c1a.jpeg", "hash": "large_T1_AG_1_PET_upakovka_3491ce6c1a", "mime": "image/jpeg", "name": "large_T1AG1 ПЭТ упаковка.jpeg", "path": null, "size": 65.72, "width": 667, "height": 1000, "sizeInBytes": 65723}, "small": {"ext": ".jpeg", "url": "/uploads/small_T1_AG_1_PET_upakovka_3491ce6c1a.jpeg", "hash": "small_T1_AG_1_PET_upakovka_3491ce6c1a", "mime": "image/jpeg", "name": "small_T1AG1 ПЭТ упаковка.jpeg", "path": null, "size": 19.25, "width": 333, "height": 500, "sizeInBytes": 19249}, "medium": {"ext": ".jpeg", "url": "/uploads/medium_T1_AG_1_PET_upakovka_3491ce6c1a.jpeg", "hash": "medium_T1_AG_1_PET_upakovka_3491ce6c1a", "mime": "image/jpeg", "name": "medium_T1AG1 ПЭТ упаковка.jpeg", "path": null, "size": 40.2, "width": 500, "height": 750, "sizeInBytes": 40198}, "thumbnail": {"ext": ".jpeg", "url": "/uploads/thumbnail_T1_AG_1_PET_upakovka_3491ce6c1a.jpeg", "hash": "thumbnail_T1_AG_1_PET_upakovka_3491ce6c1a", "mime": "image/jpeg", "name": "thumbnail_T1AG1 ПЭТ упаковка.jpeg", "path": null, "size": 2.92, "width": 104, "height": 156, "sizeInBytes": 2917}}	T1_AG_1_PET_upakovka_3491ce6c1a	.jpeg	image/jpeg	138.24	/uploads/T1_AG_1_PET_upakovka_3491ce6c1a.jpeg	\N	local	\N	/	2025-10-24 19:59:40.882	2025-10-24 19:59:40.882	2025-10-24 19:59:40.883	1	1	\N
12	mxtg46wfruqwq0jtv25oskxg	L1.AG.1 Чулки классика 1КК, беж-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992.jpg", "hash": "large_L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992", "mime": "image/jpeg", "name": "large_L1.AG.1 Чулки классика 1КК, беж-1.jpg", "path": null, "size": 43.97, "width": 1000, "height": 1000, "sizeInBytes": 43973}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992.jpg", "hash": "small_L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992", "mime": "image/jpeg", "name": "small_L1.AG.1 Чулки классика 1КК, беж-1.jpg", "path": null, "size": 14.08, "width": 500, "height": 500, "sizeInBytes": 14083}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992.jpg", "hash": "medium_L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992", "mime": "image/jpeg", "name": "medium_L1.AG.1 Чулки классика 1КК, беж-1.jpg", "path": null, "size": 26.75, "width": 750, "height": 750, "sizeInBytes": 26754}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992.jpg", "hash": "thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992", "mime": "image/jpeg", "name": "thumbnail_L1.AG.1 Чулки классика 1КК, беж-1.jpg", "path": null, "size": 2.76, "width": 156, "height": 156, "sizeInBytes": 2757}}	L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992	.jpg	image/jpeg	165.03	/uploads/L1_AG_1_Chulki_klassika_1_KK_bezh_1_b8df4dc992.jpg	\N	local	\N	/	2025-10-24 20:13:03.527	2025-10-24 20:13:03.527	2025-10-24 20:13:03.527	1	1	\N
13	nfwbgmdpqv33zfe4qzwlvxah	L1.AG.1 Чулки классика 1КК, беж-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10.jpg", "hash": "large_L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10", "mime": "image/jpeg", "name": "large_L1.AG.1 Чулки классика 1КК, беж-2.jpg", "path": null, "size": 36.64, "width": 1000, "height": 1000, "sizeInBytes": 36644}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10.jpg", "hash": "small_L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10", "mime": "image/jpeg", "name": "small_L1.AG.1 Чулки классика 1КК, беж-2.jpg", "path": null, "size": 12.03, "width": 500, "height": 500, "sizeInBytes": 12029}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10.jpg", "hash": "medium_L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10", "mime": "image/jpeg", "name": "medium_L1.AG.1 Чулки классика 1КК, беж-2.jpg", "path": null, "size": 22.89, "width": 750, "height": 750, "sizeInBytes": 22887}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10.jpg", "hash": "thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10", "mime": "image/jpeg", "name": "thumbnail_L1.AG.1 Чулки классика 1КК, беж-2.jpg", "path": null, "size": 2.29, "width": 156, "height": 156, "sizeInBytes": 2291}}	L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10	.jpg	image/jpeg	129.54	/uploads/L1_AG_1_Chulki_klassika_1_KK_bezh_2_688bbc3b10.jpg	\N	local	\N	/	2025-10-24 20:14:37.292	2025-10-24 20:14:37.292	2025-10-24 20:14:37.292	1	1	\N
14	dt09o2yxne64wwq2b3mnx8e7	L1.AG.1 Чулки классика 1КК, беж-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3.jpg", "hash": "large_L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3", "mime": "image/jpeg", "name": "large_L1.AG.1 Чулки классика 1КК, беж-3.jpg", "path": null, "size": 105.16, "width": 1000, "height": 1000, "sizeInBytes": 105164}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3.jpg", "hash": "small_L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3", "mime": "image/jpeg", "name": "small_L1.AG.1 Чулки классика 1КК, беж-3.jpg", "path": null, "size": 24.24, "width": 500, "height": 500, "sizeInBytes": 24235}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3.jpg", "hash": "medium_L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3", "mime": "image/jpeg", "name": "medium_L1.AG.1 Чулки классика 1КК, беж-3.jpg", "path": null, "size": 54.85, "width": 750, "height": 750, "sizeInBytes": 54845}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3.jpg", "hash": "thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3", "mime": "image/jpeg", "name": "thumbnail_L1.AG.1 Чулки классика 1КК, беж-3.jpg", "path": null, "size": 3.81, "width": 156, "height": 156, "sizeInBytes": 3807}}	L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3	.jpg	image/jpeg	502.04	/uploads/L1_AG_1_Chulki_klassika_1_KK_bezh_3_76e7f2f3a3.jpg	\N	local	\N	/	2025-10-24 20:15:56.7	2025-10-24 20:15:56.7	2025-10-24 20:15:56.701	1	1	\N
15	bcwa8w93emilj9rs9v6x4yeo	L1.AG.1 Чулки классика 1КК, беж-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d.jpg", "hash": "large_L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d", "mime": "image/jpeg", "name": "large_L1.AG.1 Чулки классика 1КК, беж-4.jpg", "path": null, "size": 33.69, "width": 1000, "height": 1000, "sizeInBytes": 33693}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d.jpg", "hash": "small_L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d", "mime": "image/jpeg", "name": "small_L1.AG.1 Чулки классика 1КК, беж-4.jpg", "path": null, "size": 11.33, "width": 500, "height": 500, "sizeInBytes": 11331}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d.jpg", "hash": "medium_L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d", "mime": "image/jpeg", "name": "medium_L1.AG.1 Чулки классика 1КК, беж-4.jpg", "path": null, "size": 21.37, "width": 750, "height": 750, "sizeInBytes": 21373}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d.jpg", "hash": "thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d", "mime": "image/jpeg", "name": "thumbnail_L1.AG.1 Чулки классика 1КК, беж-4.jpg", "path": null, "size": 2.22, "width": 156, "height": 156, "sizeInBytes": 2224}}	L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d	.jpg	image/jpeg	114.96	/uploads/L1_AG_1_Chulki_klassika_1_KK_bezh_4_6af6554f6d.jpg	\N	local	\N	/	2025-10-24 20:18:08.139	2025-10-24 20:18:08.139	2025-10-24 20:18:08.139	1	1	\N
16	yib19ih8r64v3yd0vmucpbw3	L1.AG.1 Чулки классика 1КК, беж-упаковка.png	\N	\N	3800	2800	{"large": {"ext": ".png", "url": "/uploads/large_L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e.png", "hash": "large_L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e", "mime": "image/png", "name": "large_L1.AG.1 Чулки классика 1КК, беж-упаковка.png", "path": null, "size": 206.43, "width": 1000, "height": 737, "sizeInBytes": 206433}, "small": {"ext": ".png", "url": "/uploads/small_L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e.png", "hash": "small_L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e", "mime": "image/png", "name": "small_L1.AG.1 Чулки классика 1КК, беж-упаковка.png", "path": null, "size": 61.32, "width": 500, "height": 368, "sizeInBytes": 61322}, "medium": {"ext": ".png", "url": "/uploads/medium_L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e.png", "hash": "medium_L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e", "mime": "image/png", "name": "medium_L1.AG.1 Чулки классика 1КК, беж-упаковка.png", "path": null, "size": 124.37, "width": 750, "height": 553, "sizeInBytes": 124365}, "thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e.png", "hash": "thumbnail_L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e", "mime": "image/png", "name": "thumbnail_L1.AG.1 Чулки классика 1КК, беж-упаковка.png", "path": null, "size": 14.84, "width": 212, "height": 156, "sizeInBytes": 14844}}	L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e	.png	image/png	636.98	/uploads/L1_AG_1_Chulki_klassika_1_KK_bezh_upakovka_dd0781b36e.png	\N	local	\N	/	2025-10-24 20:20:48.153	2025-10-24 20:20:48.153	2025-10-24 20:20:48.153	1	1	\N
17	ilk6qawpd2ill6z35h76f29x	L1.AG.2 Чулки классика 1КК, черн-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d.jpg", "hash": "large_L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d", "mime": "image/jpeg", "name": "large_L1.AG.2 Чулки классика 1КК, черн-1.jpg", "path": null, "size": 41.07, "width": 1000, "height": 1000, "sizeInBytes": 41065}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d.jpg", "hash": "small_L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d", "mime": "image/jpeg", "name": "small_L1.AG.2 Чулки классика 1КК, черн-1.jpg", "path": null, "size": 14.12, "width": 500, "height": 500, "sizeInBytes": 14116}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d.jpg", "hash": "medium_L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d", "mime": "image/jpeg", "name": "medium_L1.AG.2 Чулки классика 1КК, черн-1.jpg", "path": null, "size": 25.92, "width": 750, "height": 750, "sizeInBytes": 25922}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d.jpg", "hash": "thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d", "mime": "image/jpeg", "name": "thumbnail_L1.AG.2 Чулки классика 1КК, черн-1.jpg", "path": null, "size": 3.03, "width": 156, "height": 156, "sizeInBytes": 3026}}	L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d	.jpg	image/jpeg	137.20	/uploads/L1_AG_2_Chulki_klassika_1_KK_chern_1_99c17def6d.jpg	\N	local	\N	/	2025-10-24 20:22:25.392	2025-10-24 20:22:25.392	2025-10-24 20:22:25.393	1	1	\N
18	sxv06cgmrfzq9nkdl5rs94mu	L1.AG.2 Чулки классика 1КК, черн-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf.jpg", "hash": "large_L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf", "mime": "image/jpeg", "name": "large_L1.AG.2 Чулки классика 1КК, черн-2.jpg", "path": null, "size": 36.15, "width": 1000, "height": 1000, "sizeInBytes": 36151}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf.jpg", "hash": "small_L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf", "mime": "image/jpeg", "name": "small_L1.AG.2 Чулки классика 1КК, черн-2.jpg", "path": null, "size": 12.36, "width": 500, "height": 500, "sizeInBytes": 12356}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf.jpg", "hash": "medium_L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf", "mime": "image/jpeg", "name": "medium_L1.AG.2 Чулки классика 1КК, черн-2.jpg", "path": null, "size": 22.92, "width": 750, "height": 750, "sizeInBytes": 22918}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf.jpg", "hash": "thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf", "mime": "image/jpeg", "name": "thumbnail_L1.AG.2 Чулки классика 1КК, черн-2.jpg", "path": null, "size": 2.52, "width": 156, "height": 156, "sizeInBytes": 2523}}	L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf	.jpg	image/jpeg	123.74	/uploads/L1_AG_2_Chulki_klassika_1_KK_chern_2_05503fdedf.jpg	\N	local	\N	/	2025-10-24 20:26:18.929	2025-10-24 20:26:18.929	2025-10-24 20:26:18.93	1	1	\N
21	cv531wwig7dlu4591mkkotz7	L1.AG.2 Чулки классика 1КК, черн-5.png	\N	\N	3800	2800	{"large": {"ext": ".png", "url": "/uploads/large_L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315.png", "hash": "large_L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315", "mime": "image/png", "name": "large_L1.AG.2 Чулки классика 1КК, черн-5.png", "path": null, "size": 206.43, "width": 1000, "height": 737, "sizeInBytes": 206433}, "small": {"ext": ".png", "url": "/uploads/small_L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315.png", "hash": "small_L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315", "mime": "image/png", "name": "small_L1.AG.2 Чулки классика 1КК, черн-5.png", "path": null, "size": 61.32, "width": 500, "height": 368, "sizeInBytes": 61322}, "medium": {"ext": ".png", "url": "/uploads/medium_L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315.png", "hash": "medium_L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315", "mime": "image/png", "name": "medium_L1.AG.2 Чулки классика 1КК, черн-5.png", "path": null, "size": 124.37, "width": 750, "height": 553, "sizeInBytes": 124365}, "thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315.png", "hash": "thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315", "mime": "image/png", "name": "thumbnail_L1.AG.2 Чулки классика 1КК, черн-5.png", "path": null, "size": 14.84, "width": 212, "height": 156, "sizeInBytes": 14844}}	L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315	.png	image/png	636.98	/uploads/L1_AG_2_Chulki_klassika_1_KK_chern_5_8283754315.png	\N	local	\N	/	2025-10-24 20:32:17.832	2025-10-24 20:32:17.832	2025-10-24 20:32:17.832	1	1	\N
22	fbra8c0wn08fpy5fi4pk6egt	L1.AD.1 Гольфы микрофибра 1 КК, бежевые_упаковка.png	\N	\N	3800	2800	{"large": {"ext": ".png", "url": "/uploads/large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e.png", "hash": "large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e", "mime": "image/png", "name": "large_L1.AD.1 Гольфы микрофибра 1 КК, бежевые_упаковка.png", "path": null, "size": 212.22, "width": 1000, "height": 737, "sizeInBytes": 212216}, "small": {"ext": ".png", "url": "/uploads/small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e.png", "hash": "small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e", "mime": "image/png", "name": "small_L1.AD.1 Гольфы микрофибра 1 КК, бежевые_упаковка.png", "path": null, "size": 63.64, "width": 500, "height": 368, "sizeInBytes": 63639}, "medium": {"ext": ".png", "url": "/uploads/medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e.png", "hash": "medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e", "mime": "image/png", "name": "medium_L1.AD.1 Гольфы микрофибра 1 КК, бежевые_упаковка.png", "path": null, "size": 128.2, "width": 750, "height": 553, "sizeInBytes": 128202}, "thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e.png", "hash": "thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e", "mime": "image/png", "name": "thumbnail_L1.AD.1 Гольфы микрофибра 1 КК, бежевые_упаковка.png", "path": null, "size": 15.44, "width": 212, "height": 156, "sizeInBytes": 15440}}	L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e	.png	image/png	612.62	/uploads/L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_upakovka_6c4aba3e2e.png	\N	local	\N	/	2025-10-24 20:38:27.254	2025-10-24 20:38:27.254	2025-10-24 20:38:27.254	1	1	\N
19	t2hu1lm59w78dzlgsu2pcup3	L1.AG.2 Чулки классика 1КК, черн-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e.jpg", "hash": "large_L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e", "mime": "image/jpeg", "name": "large_L1.AG.2 Чулки классика 1КК, черн-3.jpg", "path": null, "size": 79.24, "width": 1000, "height": 1000, "sizeInBytes": 79239}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e.jpg", "hash": "small_L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e", "mime": "image/jpeg", "name": "small_L1.AG.2 Чулки классика 1КК, черн-3.jpg", "path": null, "size": 21.96, "width": 500, "height": 500, "sizeInBytes": 21955}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e.jpg", "hash": "medium_L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e", "mime": "image/jpeg", "name": "medium_L1.AG.2 Чулки классика 1КК, черн-3.jpg", "path": null, "size": 45.51, "width": 750, "height": 750, "sizeInBytes": 45513}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e.jpg", "hash": "thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e", "mime": "image/jpeg", "name": "thumbnail_L1.AG.2 Чулки классика 1КК, черн-3.jpg", "path": null, "size": 3.56, "width": 156, "height": 156, "sizeInBytes": 3559}}	L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e	.jpg	image/jpeg	315.61	/uploads/L1_AG_2_Chulki_klassika_1_KK_chern_3_6e4f0a960e.jpg	\N	local	\N	/	2025-10-24 20:27:55.194	2025-10-24 20:27:55.194	2025-10-24 20:27:55.194	1	1	\N
20	mtl4xkem8hly4cxjh686f3nv	L1.AG.2 Чулки классика 1КК, черн-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1.jpg", "hash": "large_L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1", "mime": "image/jpeg", "name": "large_L1.AG.2 Чулки классика 1КК, черн-4.jpg", "path": null, "size": 124.24, "width": 1000, "height": 1000, "sizeInBytes": 124242}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1.jpg", "hash": "small_L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1", "mime": "image/jpeg", "name": "small_L1.AG.2 Чулки классика 1КК, черн-4.jpg", "path": null, "size": 30.4, "width": 500, "height": 500, "sizeInBytes": 30397}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1.jpg", "hash": "medium_L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1", "mime": "image/jpeg", "name": "medium_L1.AG.2 Чулки классика 1КК, черн-4.jpg", "path": null, "size": 69.37, "width": 750, "height": 750, "sizeInBytes": 69370}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1.jpg", "hash": "thumbnail_L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1", "mime": "image/jpeg", "name": "thumbnail_L1.AG.2 Чулки классика 1КК, черн-4.jpg", "path": null, "size": 4.71, "width": 156, "height": 156, "sizeInBytes": 4707}}	L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1	.jpg	image/jpeg	452.59	/uploads/L1_AG_2_Chulki_klassika_1_KK_chern_4_b076a3c3c1.jpg	\N	local	\N	/	2025-10-24 20:29:33.48	2025-10-24 20:29:33.48	2025-10-24 20:29:33.48	1	1	\N
24	iaj1mjvvkga5ms88fpq6340c	L1.AD.1 Гольфы микрофибра 1 КК, бежевые-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13.jpg", "hash": "large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13", "mime": "image/jpeg", "name": "large_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-2.jpg", "path": null, "size": 36.72, "width": 1000, "height": 1000, "sizeInBytes": 36723}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13.jpg", "hash": "small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13", "mime": "image/jpeg", "name": "small_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-2.jpg", "path": null, "size": 12.47, "width": 500, "height": 500, "sizeInBytes": 12466}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13.jpg", "hash": "medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13", "mime": "image/jpeg", "name": "medium_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-2.jpg", "path": null, "size": 23.28, "width": 750, "height": 750, "sizeInBytes": 23275}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13.jpg", "hash": "thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13", "mime": "image/jpeg", "name": "thumbnail_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-2.jpg", "path": null, "size": 2.43, "width": 156, "height": 156, "sizeInBytes": 2433}}	L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13	.jpg	image/jpeg	129.55	/uploads/L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_2_6423ee7d13.jpg	\N	local	\N	/	2025-10-24 20:42:16.735	2025-10-24 20:42:16.735	2025-10-24 20:42:16.735	1	1	\N
25	x4dy4n4zi7fw04fqq2jv4lz0	L1.AD.1 Гольфы микрофибра 1 КК, бежевые-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a.jpg", "hash": "large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a", "mime": "image/jpeg", "name": "large_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-3.jpg", "path": null, "size": 43.61, "width": 1000, "height": 1000, "sizeInBytes": 43608}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a.jpg", "hash": "small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a", "mime": "image/jpeg", "name": "small_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-3.jpg", "path": null, "size": 13.5, "width": 500, "height": 500, "sizeInBytes": 13504}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a.jpg", "hash": "medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a", "mime": "image/jpeg", "name": "medium_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-3.jpg", "path": null, "size": 26.57, "width": 750, "height": 750, "sizeInBytes": 26567}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a.jpg", "hash": "thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a", "mime": "image/jpeg", "name": "thumbnail_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-3.jpg", "path": null, "size": 2.6, "width": 156, "height": 156, "sizeInBytes": 2596}}	L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a	.jpg	image/jpeg	173.24	/uploads/L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_3_6dd21ecb7a.jpg	\N	local	\N	/	2025-10-24 20:44:50.123	2025-10-24 20:44:50.123	2025-10-24 20:44:50.124	1	1	\N
26	cv5ja4stchdi5itpnwb2fbgr	L1.AD.1 Гольфы микрофибра 1 КК, бежевые-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341.jpg", "hash": "large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341", "mime": "image/jpeg", "name": "large_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-4.jpg", "path": null, "size": 36.03, "width": 1000, "height": 1000, "sizeInBytes": 36027}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341.jpg", "hash": "small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341", "mime": "image/jpeg", "name": "small_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-4.jpg", "path": null, "size": 12.22, "width": 500, "height": 500, "sizeInBytes": 12216}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341.jpg", "hash": "medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341", "mime": "image/jpeg", "name": "medium_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-4.jpg", "path": null, "size": 22.71, "width": 750, "height": 750, "sizeInBytes": 22705}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341.jpg", "hash": "thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341", "mime": "image/jpeg", "name": "thumbnail_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-4.jpg", "path": null, "size": 2.52, "width": 156, "height": 156, "sizeInBytes": 2524}}	L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341	.jpg	image/jpeg	137.50	/uploads/L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_4_5b3ace0341.jpg	\N	local	\N	/	2025-10-24 20:47:40.075	2025-10-24 20:47:40.075	2025-10-24 20:47:40.076	1	1	\N
27	fi0ewi2wxjh12yf6ownxkqd3	L1.AD.2 Гольфы микрофибра 1 КК, черные-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0.jpg", "hash": "large_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0", "mime": "image/jpeg", "name": "large_L1.AD.2 Гольфы микрофибра 1 КК, черные-1.jpg", "path": null, "size": 38.68, "width": 1000, "height": 1000, "sizeInBytes": 38681}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0.jpg", "hash": "small_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0", "mime": "image/jpeg", "name": "small_L1.AD.2 Гольфы микрофибра 1 КК, черные-1.jpg", "path": null, "size": 13.31, "width": 500, "height": 500, "sizeInBytes": 13306}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0.jpg", "hash": "medium_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0", "mime": "image/jpeg", "name": "medium_L1.AD.2 Гольфы микрофибра 1 КК, черные-1.jpg", "path": null, "size": 24.31, "width": 750, "height": 750, "sizeInBytes": 24305}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0.jpg", "hash": "thumbnail_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0", "mime": "image/jpeg", "name": "thumbnail_L1.AD.2 Гольфы микрофибра 1 КК, черные-1.jpg", "path": null, "size": 2.87, "width": 156, "height": 156, "sizeInBytes": 2865}}	L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0	.jpg	image/jpeg	118.18	/uploads/L1_AD_2_Golfy_mikrofibra_1_KK_chernye_1_f54af2bea0.jpg	\N	local	\N	/	2025-10-24 20:50:31.507	2025-10-24 20:50:31.507	2025-10-24 20:50:31.507	1	1	\N
28	q0xvm2zxlz5er665ooohgp0t	L1.AD.2 Гольфы микрофибра 1 КК, черные-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb.jpg", "hash": "large_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb", "mime": "image/jpeg", "name": "large_L1.AD.2 Гольфы микрофибра 1 КК, черные-2.jpg", "path": null, "size": 51.39, "width": 1000, "height": 1000, "sizeInBytes": 51385}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb.jpg", "hash": "small_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb", "mime": "image/jpeg", "name": "small_L1.AD.2 Гольфы микрофибра 1 КК, черные-2.jpg", "path": null, "size": 18.01, "width": 500, "height": 500, "sizeInBytes": 18010}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb.jpg", "hash": "medium_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb", "mime": "image/jpeg", "name": "medium_L1.AD.2 Гольфы микрофибра 1 КК, черные-2.jpg", "path": null, "size": 32.77, "width": 750, "height": 750, "sizeInBytes": 32772}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb.jpg", "hash": "thumbnail_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb", "mime": "image/jpeg", "name": "thumbnail_L1.AD.2 Гольфы микрофибра 1 КК, черные-2.jpg", "path": null, "size": 3.67, "width": 156, "height": 156, "sizeInBytes": 3672}}	L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb	.jpg	image/jpeg	146.27	/uploads/L1_AD_2_Golfy_mikrofibra_1_KK_chernye_2_9be43dd1eb.jpg	\N	local	\N	/	2025-10-24 20:52:56.818	2025-10-24 20:52:56.818	2025-10-24 20:52:56.818	1	1	\N
29	m03g6mrl8h37frx7yfsb8bui	L1.AD.2 Гольфы микрофибра 1 КК, черные-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f.jpg", "hash": "large_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f", "mime": "image/jpeg", "name": "large_L1.AD.2 Гольфы микрофибра 1 КК, черные-3.jpg", "path": null, "size": 35.37, "width": 1000, "height": 1000, "sizeInBytes": 35374}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f.jpg", "hash": "small_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f", "mime": "image/jpeg", "name": "small_L1.AD.2 Гольфы микрофибра 1 КК, черные-3.jpg", "path": null, "size": 12.68, "width": 500, "height": 500, "sizeInBytes": 12675}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f.jpg", "hash": "medium_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f", "mime": "image/jpeg", "name": "medium_L1.AD.2 Гольфы микрофибра 1 КК, черные-3.jpg", "path": null, "size": 22.77, "width": 750, "height": 750, "sizeInBytes": 22769}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f.jpg", "hash": "thumbnail_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f", "mime": "image/jpeg", "name": "thumbnail_L1.AD.2 Гольфы микрофибра 1 КК, черные-3.jpg", "path": null, "size": 2.76, "width": 156, "height": 156, "sizeInBytes": 2761}}	L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f	.jpg	image/jpeg	106.55	/uploads/L1_AD_2_Golfy_mikrofibra_1_KK_chernye_3_749d480b8f.jpg	\N	local	\N	/	2025-10-24 20:54:08.732	2025-10-24 20:54:08.732	2025-10-24 20:54:08.732	1	1	\N
30	ivmiurs4d1055556vax04bva	L1.AD.2 Гольфы микрофибра 1 КК, черные-упакова.png	\N	\N	3800	2800	{"large": {"ext": ".png", "url": "/uploads/large_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63.png", "hash": "large_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63", "mime": "image/png", "name": "large_L1.AD.2 Гольфы микрофибра 1 КК, черные-упакова.png", "path": null, "size": 212.22, "width": 1000, "height": 737, "sizeInBytes": 212216}, "small": {"ext": ".png", "url": "/uploads/small_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63.png", "hash": "small_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63", "mime": "image/png", "name": "small_L1.AD.2 Гольфы микрофибра 1 КК, черные-упакова.png", "path": null, "size": 63.64, "width": 500, "height": 368, "sizeInBytes": 63639}, "medium": {"ext": ".png", "url": "/uploads/medium_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63.png", "hash": "medium_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63", "mime": "image/png", "name": "medium_L1.AD.2 Гольфы микрофибра 1 КК, черные-упакова.png", "path": null, "size": 128.2, "width": 750, "height": 553, "sizeInBytes": 128202}, "thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63.png", "hash": "thumbnail_L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63", "mime": "image/png", "name": "thumbnail_L1.AD.2 Гольфы микрофибра 1 КК, черные-упакова.png", "path": null, "size": 15.44, "width": 212, "height": 156, "sizeInBytes": 15440}}	L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63	.png	image/png	612.62	/uploads/L1_AD_2_Golfy_mikrofibra_1_KK_chernye_upakova_a324eb6c63.png	\N	local	\N	/	2025-10-24 20:55:58.583	2025-10-24 20:55:58.583	2025-10-24 20:55:58.584	1	1	\N
31	udynwzkmoziy597sjolbywv0	BL.06.1 Голеностоп черный сбоку.jpg	\N	\N	4950	4569	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_06_1_Golenostop_chernyj_sboku_4f54820ac6.jpg", "hash": "large_BL_06_1_Golenostop_chernyj_sboku_4f54820ac6", "mime": "image/jpeg", "name": "large_BL.06.1 Голеностоп черный сбоку.jpg", "path": null, "size": 62.94, "width": 1000, "height": 923, "sizeInBytes": 62941}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_06_1_Golenostop_chernyj_sboku_4f54820ac6.jpg", "hash": "small_BL_06_1_Golenostop_chernyj_sboku_4f54820ac6", "mime": "image/jpeg", "name": "small_BL.06.1 Голеностоп черный сбоку.jpg", "path": null, "size": 18.03, "width": 500, "height": 462, "sizeInBytes": 18031}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_06_1_Golenostop_chernyj_sboku_4f54820ac6.jpg", "hash": "medium_BL_06_1_Golenostop_chernyj_sboku_4f54820ac6", "mime": "image/jpeg", "name": "medium_BL.06.1 Голеностоп черный сбоку.jpg", "path": null, "size": 36.09, "width": 750, "height": 692, "sizeInBytes": 36091}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_06_1_Golenostop_chernyj_sboku_4f54820ac6.jpg", "hash": "thumbnail_BL_06_1_Golenostop_chernyj_sboku_4f54820ac6", "mime": "image/jpeg", "name": "thumbnail_BL.06.1 Голеностоп черный сбоку.jpg", "path": null, "size": 3.83, "width": 169, "height": 156, "sizeInBytes": 3825}}	BL_06_1_Golenostop_chernyj_sboku_4f54820ac6	.jpg	image/jpeg	2268.03	/uploads/BL_06_1_Golenostop_chernyj_sboku_4f54820ac6.jpg	\N	local	\N	/	2025-10-24 21:04:13.816	2025-10-24 21:04:13.816	2025-10-24 21:04:13.816	1	1	\N
32	pfgdjaaztp8unn3olavc48ee	BL.06.1 Голеностоп черный сзади.jpg	\N	\N	3112	3133	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f.jpg", "hash": "large_BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f", "mime": "image/jpeg", "name": "large_BL.06.1 Голеностоп черный сзади.jpg", "path": null, "size": 59.89, "width": 994, "height": 1000, "sizeInBytes": 59887}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f.jpg", "hash": "small_BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f", "mime": "image/jpeg", "name": "small_BL.06.1 Голеностоп черный сзади.jpg", "path": null, "size": 16.84, "width": 497, "height": 500, "sizeInBytes": 16835}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f.jpg", "hash": "medium_BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f", "mime": "image/jpeg", "name": "medium_BL.06.1 Голеностоп черный сзади.jpg", "path": null, "size": 34.56, "width": 745, "height": 750, "sizeInBytes": 34555}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f.jpg", "hash": "thumbnail_BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f", "mime": "image/jpeg", "name": "thumbnail_BL.06.1 Голеностоп черный сзади.jpg", "path": null, "size": 3.01, "width": 155, "height": 156, "sizeInBytes": 3006}}	BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f	.jpg	image/jpeg	987.43	/uploads/BL_06_1_Golenostop_chernyj_szadi_d7f31f7a2f.jpg	\N	local	\N	/	2025-10-24 21:06:45.473	2025-10-24 21:06:45.473	2025-10-24 21:06:45.474	1	1	\N
54	jpz89xo4g7kt8lshcms4quux	BV.06.1 корсет черный_2.jpg	\N	\N	4470	3772	{"large": {"ext": ".jpg", "url": "/uploads/large_BV_06_1_korset_chernyj_2_e2f408ff86.jpg", "hash": "large_BV_06_1_korset_chernyj_2_e2f408ff86", "mime": "image/jpeg", "name": "large_BV.06.1 корсет черный_2.jpg", "path": null, "size": 67.69, "width": 1000, "height": 844, "sizeInBytes": 67691}, "small": {"ext": ".jpg", "url": "/uploads/small_BV_06_1_korset_chernyj_2_e2f408ff86.jpg", "hash": "small_BV_06_1_korset_chernyj_2_e2f408ff86", "mime": "image/jpeg", "name": "small_BV.06.1 корсет черный_2.jpg", "path": null, "size": 17.73, "width": 500, "height": 422, "sizeInBytes": 17731}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BV_06_1_korset_chernyj_2_e2f408ff86.jpg", "hash": "medium_BV_06_1_korset_chernyj_2_e2f408ff86", "mime": "image/jpeg", "name": "medium_BV.06.1 корсет черный_2.jpg", "path": null, "size": 37.66, "width": 750, "height": 633, "sizeInBytes": 37655}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BV_06_1_korset_chernyj_2_e2f408ff86.jpg", "hash": "thumbnail_BV_06_1_korset_chernyj_2_e2f408ff86", "mime": "image/jpeg", "name": "thumbnail_BV.06.1 корсет черный_2.jpg", "path": null, "size": 3.78, "width": 185, "height": 156, "sizeInBytes": 3780}}	BV_06_1_korset_chernyj_2_e2f408ff86	.jpg	image/jpeg	1696.31	/uploads/BV_06_1_korset_chernyj_2_e2f408ff86.jpg	\N	local	\N	/	2025-10-25 09:48:45.919	2025-10-25 09:48:45.919	2025-10-25 09:48:45.919	1	1	\N
33	ezesr9mevsy593f68dh3sutn	BL.06.2 голеностоп эластичный_1.jpg	\N	\N	3765	5214	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_06_2_golenostop_elastichnyj_1_fb3be5d237.jpg", "hash": "large_BL_06_2_golenostop_elastichnyj_1_fb3be5d237", "mime": "image/jpeg", "name": "large_BL.06.2 голеностоп эластичный_1.jpg", "path": null, "size": 42.97, "width": 722, "height": 1000, "sizeInBytes": 42971}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_06_2_golenostop_elastichnyj_1_fb3be5d237.jpg", "hash": "small_BL_06_2_golenostop_elastichnyj_1_fb3be5d237", "mime": "image/jpeg", "name": "small_BL.06.2 голеностоп эластичный_1.jpg", "path": null, "size": 13.45, "width": 361, "height": 500, "sizeInBytes": 13448}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_06_2_golenostop_elastichnyj_1_fb3be5d237.jpg", "hash": "medium_BL_06_2_golenostop_elastichnyj_1_fb3be5d237", "mime": "image/jpeg", "name": "medium_BL.06.2 голеностоп эластичный_1.jpg", "path": null, "size": 26.55, "width": 542, "height": 750, "sizeInBytes": 26549}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_06_2_golenostop_elastichnyj_1_fb3be5d237.jpg", "hash": "thumbnail_BL_06_2_golenostop_elastichnyj_1_fb3be5d237", "mime": "image/jpeg", "name": "thumbnail_BL.06.2 голеностоп эластичный_1.jpg", "path": null, "size": 2.45, "width": 113, "height": 156, "sizeInBytes": 2449}}	BL_06_2_golenostop_elastichnyj_1_fb3be5d237	.jpg	image/jpeg	1254.75	/uploads/BL_06_2_golenostop_elastichnyj_1_fb3be5d237.jpg	\N	local	\N	/	2025-10-24 21:08:34.156	2025-10-24 21:08:34.156	2025-10-24 21:08:34.156	1	1	\N
34	t47u4ohfek7l5cqy4si3d5u7	BL.06.2 голеностоп эластичный_2.jpg	\N	\N	3596	3765	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_06_2_golenostop_elastichnyj_2_041199867c.jpg", "hash": "large_BL_06_2_golenostop_elastichnyj_2_041199867c", "mime": "image/jpeg", "name": "large_BL.06.2 голеностоп эластичный_2.jpg", "path": null, "size": 53.48, "width": 955, "height": 1000, "sizeInBytes": 53482}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_06_2_golenostop_elastichnyj_2_041199867c.jpg", "hash": "small_BL_06_2_golenostop_elastichnyj_2_041199867c", "mime": "image/jpeg", "name": "small_BL.06.2 голеностоп эластичный_2.jpg", "path": null, "size": 15.77, "width": 478, "height": 500, "sizeInBytes": 15765}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_06_2_golenostop_elastichnyj_2_041199867c.jpg", "hash": "medium_BL_06_2_golenostop_elastichnyj_2_041199867c", "mime": "image/jpeg", "name": "medium_BL.06.2 голеностоп эластичный_2.jpg", "path": null, "size": 31.54, "width": 717, "height": 750, "sizeInBytes": 31535}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_06_2_golenostop_elastichnyj_2_041199867c.jpg", "hash": "thumbnail_BL_06_2_golenostop_elastichnyj_2_041199867c", "mime": "image/jpeg", "name": "thumbnail_BL.06.2 голеностоп эластичный_2.jpg", "path": null, "size": 2.74, "width": 149, "height": 156, "sizeInBytes": 2741}}	BL_06_2_golenostop_elastichnyj_2_041199867c	.jpg	image/jpeg	904.45	/uploads/BL_06_2_golenostop_elastichnyj_2_041199867c.jpg	\N	local	\N	/	2025-10-24 21:11:12.898	2025-10-24 21:11:12.898	2025-10-24 21:11:12.898	1	1	\N
35	s5xv3hzq3qomthsaerzxjslz	BL.06.2 голеностоп эластичный_3.jpg	\N	\N	3826	5466	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_06_2_golenostop_elastichnyj_3_7675ae34b9.jpg", "hash": "large_BL_06_2_golenostop_elastichnyj_3_7675ae34b9", "mime": "image/jpeg", "name": "large_BL.06.2 голеностоп эластичный_3.jpg", "path": null, "size": 56.91, "width": 700, "height": 1000, "sizeInBytes": 56909}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_06_2_golenostop_elastichnyj_3_7675ae34b9.jpg", "hash": "small_BL_06_2_golenostop_elastichnyj_3_7675ae34b9", "mime": "image/jpeg", "name": "small_BL.06.2 голеностоп эластичный_3.jpg", "path": null, "size": 17.84, "width": 350, "height": 500, "sizeInBytes": 17844}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_06_2_golenostop_elastichnyj_3_7675ae34b9.jpg", "hash": "medium_BL_06_2_golenostop_elastichnyj_3_7675ae34b9", "mime": "image/jpeg", "name": "medium_BL.06.2 голеностоп эластичный_3.jpg", "path": null, "size": 35.2, "width": 525, "height": 750, "sizeInBytes": 35199}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_06_2_golenostop_elastichnyj_3_7675ae34b9.jpg", "hash": "thumbnail_BL_06_2_golenostop_elastichnyj_3_7675ae34b9", "mime": "image/jpeg", "name": "thumbnail_BL.06.2 голеностоп эластичный_3.jpg", "path": null, "size": 3.1, "width": 109, "height": 156, "sizeInBytes": 3097}}	BL_06_2_golenostop_elastichnyj_3_7675ae34b9	.jpg	image/jpeg	1686.97	/uploads/BL_06_2_golenostop_elastichnyj_3_7675ae34b9.jpg	\N	local	\N	/	2025-10-24 21:13:01.705	2025-10-24 21:13:01.705	2025-10-24 21:13:01.705	1	1	\N
36	zy92wvqsmi8ezqav00no140r	BL.06.2 голеностоп эластичный_4.jpg	\N	\N	4807	5633	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_06_2_golenostop_elastichnyj_4_b021bcbfa0.jpg", "hash": "large_BL_06_2_golenostop_elastichnyj_4_b021bcbfa0", "mime": "image/jpeg", "name": "large_BL.06.2 голеностоп эластичный_4.jpg", "path": null, "size": 63.06, "width": 853, "height": 1000, "sizeInBytes": 63059}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_06_2_golenostop_elastichnyj_4_b021bcbfa0.jpg", "hash": "small_BL_06_2_golenostop_elastichnyj_4_b021bcbfa0", "mime": "image/jpeg", "name": "small_BL.06.2 голеностоп эластичный_4.jpg", "path": null, "size": 18.61, "width": 426, "height": 500, "sizeInBytes": 18605}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_06_2_golenostop_elastichnyj_4_b021bcbfa0.jpg", "hash": "medium_BL_06_2_golenostop_elastichnyj_4_b021bcbfa0", "mime": "image/jpeg", "name": "medium_BL.06.2 голеностоп эластичный_4.jpg", "path": null, "size": 37.8, "width": 640, "height": 750, "sizeInBytes": 37803}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_06_2_golenostop_elastichnyj_4_b021bcbfa0.jpg", "hash": "thumbnail_BL_06_2_golenostop_elastichnyj_4_b021bcbfa0", "mime": "image/jpeg", "name": "thumbnail_BL.06.2 голеностоп эластичный_4.jpg", "path": null, "size": 2.9, "width": 133, "height": 156, "sizeInBytes": 2895}}	BL_06_2_golenostop_elastichnyj_4_b021bcbfa0	.jpg	image/jpeg	1976.03	/uploads/BL_06_2_golenostop_elastichnyj_4_b021bcbfa0.jpg	\N	local	\N	/	2025-10-24 21:14:42.752	2025-10-24 21:14:42.752	2025-10-24 21:14:42.753	1	1	\N
37	f0qtz1mqex5k8q9aqkikiaki	BL.06.2 голеностоп эластичный_5.jpg	\N	\N	3283	4111	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_06_2_golenostop_elastichnyj_5_9dc15cc52f.jpg", "hash": "large_BL_06_2_golenostop_elastichnyj_5_9dc15cc52f", "mime": "image/jpeg", "name": "large_BL.06.2 голеностоп эластичный_5.jpg", "path": null, "size": 48.88, "width": 799, "height": 1000, "sizeInBytes": 48876}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_06_2_golenostop_elastichnyj_5_9dc15cc52f.jpg", "hash": "small_BL_06_2_golenostop_elastichnyj_5_9dc15cc52f", "mime": "image/jpeg", "name": "small_BL.06.2 голеностоп эластичный_5.jpg", "path": null, "size": 16.37, "width": 399, "height": 500, "sizeInBytes": 16371}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_06_2_golenostop_elastichnyj_5_9dc15cc52f.jpg", "hash": "medium_BL_06_2_golenostop_elastichnyj_5_9dc15cc52f", "mime": "image/jpeg", "name": "medium_BL.06.2 голеностоп эластичный_5.jpg", "path": null, "size": 30.26, "width": 599, "height": 750, "sizeInBytes": 30261}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_06_2_golenostop_elastichnyj_5_9dc15cc52f.jpg", "hash": "thumbnail_BL_06_2_golenostop_elastichnyj_5_9dc15cc52f", "mime": "image/jpeg", "name": "thumbnail_BL.06.2 голеностоп эластичный_5.jpg", "path": null, "size": 3.18, "width": 125, "height": 156, "sizeInBytes": 3177}}	BL_06_2_golenostop_elastichnyj_5_9dc15cc52f	.jpg	image/jpeg	880.88	/uploads/BL_06_2_golenostop_elastichnyj_5_9dc15cc52f.jpg	\N	local	\N	/	2025-10-24 21:16:08.259	2025-10-24 21:16:08.259	2025-10-24 21:16:08.259	1	1	\N
38	mevsomkv9n2arpu1rxzxadrw	BU.12.4 кисть эластичный_1.jpg	\N	\N	1588	3219	{"large": {"ext": ".jpg", "url": "/uploads/large_BU_12_4_kist_elastichnyj_1_b4ee109c93.jpg", "hash": "large_BU_12_4_kist_elastichnyj_1_b4ee109c93", "mime": "image/jpeg", "name": "large_BU.12.4 кисть эластичный_1.jpg", "path": null, "size": 45.44, "width": 493, "height": 1000, "sizeInBytes": 45442}, "small": {"ext": ".jpg", "url": "/uploads/small_BU_12_4_kist_elastichnyj_1_b4ee109c93.jpg", "hash": "small_BU_12_4_kist_elastichnyj_1_b4ee109c93", "mime": "image/jpeg", "name": "small_BU.12.4 кисть эластичный_1.jpg", "path": null, "size": 13.03, "width": 247, "height": 500, "sizeInBytes": 13032}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BU_12_4_kist_elastichnyj_1_b4ee109c93.jpg", "hash": "medium_BU_12_4_kist_elastichnyj_1_b4ee109c93", "mime": "image/jpeg", "name": "medium_BU.12.4 кисть эластичный_1.jpg", "path": null, "size": 26.69, "width": 370, "height": 750, "sizeInBytes": 26694}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BU_12_4_kist_elastichnyj_1_b4ee109c93.jpg", "hash": "thumbnail_BU_12_4_kist_elastichnyj_1_b4ee109c93", "mime": "image/jpeg", "name": "thumbnail_BU.12.4 кисть эластичный_1.jpg", "path": null, "size": 2.53, "width": 77, "height": 156, "sizeInBytes": 2525}}	BU_12_4_kist_elastichnyj_1_b4ee109c93	.jpg	image/jpeg	541.31	/uploads/BU_12_4_kist_elastichnyj_1_b4ee109c93.jpg	\N	local	\N	/	2025-10-24 21:29:09.669	2025-10-24 21:29:09.669	2025-10-24 21:29:09.669	1	1	\N
39	ti0bpaahdipmrr8her3xa7xi	BU.12.4 кисть эластичный_2.jpg	\N	\N	4912	6095	{"large": {"ext": ".jpg", "url": "/uploads/large_BU_12_4_kist_elastichnyj_2_0b1f60a116.jpg", "hash": "large_BU_12_4_kist_elastichnyj_2_0b1f60a116", "mime": "image/jpeg", "name": "large_BU.12.4 кисть эластичный_2.jpg", "path": null, "size": 83.21, "width": 806, "height": 1000, "sizeInBytes": 83211}, "small": {"ext": ".jpg", "url": "/uploads/small_BU_12_4_kist_elastichnyj_2_0b1f60a116.jpg", "hash": "small_BU_12_4_kist_elastichnyj_2_0b1f60a116", "mime": "image/jpeg", "name": "small_BU.12.4 кисть эластичный_2.jpg", "path": null, "size": 24.35, "width": 403, "height": 500, "sizeInBytes": 24353}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BU_12_4_kist_elastichnyj_2_0b1f60a116.jpg", "hash": "medium_BU_12_4_kist_elastichnyj_2_0b1f60a116", "mime": "image/jpeg", "name": "medium_BU.12.4 кисть эластичный_2.jpg", "path": null, "size": 50.22, "width": 605, "height": 750, "sizeInBytes": 50222}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BU_12_4_kist_elastichnyj_2_0b1f60a116.jpg", "hash": "thumbnail_BU_12_4_kist_elastichnyj_2_0b1f60a116", "mime": "image/jpeg", "name": "thumbnail_BU.12.4 кисть эластичный_2.jpg", "path": null, "size": 3.94, "width": 126, "height": 156, "sizeInBytes": 3939}}	BU_12_4_kist_elastichnyj_2_0b1f60a116	.jpg	image/jpeg	4276.92	/uploads/BU_12_4_kist_elastichnyj_2_0b1f60a116.jpg	\N	local	\N	/	2025-10-24 21:31:50.661	2025-10-24 21:31:50.661	2025-10-24 21:31:50.662	1	1	\N
40	zxva18xyth5b1o8fv7ez3xds	BU.12.4 кисть эластичный_3.jpg	\N	\N	3360	4776	{"large": {"ext": ".jpg", "url": "/uploads/large_BU_12_4_kist_elastichnyj_3_fb97b53457.jpg", "hash": "large_BU_12_4_kist_elastichnyj_3_fb97b53457", "mime": "image/jpeg", "name": "large_BU.12.4 кисть эластичный_3.jpg", "path": null, "size": 55.89, "width": 704, "height": 1000, "sizeInBytes": 55886}, "small": {"ext": ".jpg", "url": "/uploads/small_BU_12_4_kist_elastichnyj_3_fb97b53457.jpg", "hash": "small_BU_12_4_kist_elastichnyj_3_fb97b53457", "mime": "image/jpeg", "name": "small_BU.12.4 кисть эластичный_3.jpg", "path": null, "size": 15.79, "width": 352, "height": 500, "sizeInBytes": 15788}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BU_12_4_kist_elastichnyj_3_fb97b53457.jpg", "hash": "medium_BU_12_4_kist_elastichnyj_3_fb97b53457", "mime": "image/jpeg", "name": "medium_BU.12.4 кисть эластичный_3.jpg", "path": null, "size": 32.39, "width": 528, "height": 750, "sizeInBytes": 32385}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BU_12_4_kist_elastichnyj_3_fb97b53457.jpg", "hash": "thumbnail_BU_12_4_kist_elastichnyj_3_fb97b53457", "mime": "image/jpeg", "name": "thumbnail_BU.12.4 кисть эластичный_3.jpg", "path": null, "size": 2.54, "width": 110, "height": 156, "sizeInBytes": 2544}}	BU_12_4_kist_elastichnyj_3_fb97b53457	.jpg	image/jpeg	1774.82	/uploads/BU_12_4_kist_elastichnyj_3_fb97b53457.jpg	\N	local	\N	/	2025-10-24 21:32:57.864	2025-10-24 21:32:57.864	2025-10-24 21:32:57.864	1	1	\N
41	ombcfo54t7kxwyq464znnvia	BU.12.4 кисть эластичный_4.jpg	\N	\N	4186	4576	{"large": {"ext": ".jpg", "url": "/uploads/large_BU_12_4_kist_elastichnyj_4_6388fb9be4.jpg", "hash": "large_BU_12_4_kist_elastichnyj_4_6388fb9be4", "mime": "image/jpeg", "name": "large_BU.12.4 кисть эластичный_4.jpg", "path": null, "size": 80.96, "width": 915, "height": 1000, "sizeInBytes": 80963}, "small": {"ext": ".jpg", "url": "/uploads/small_BU_12_4_kist_elastichnyj_4_6388fb9be4.jpg", "hash": "small_BU_12_4_kist_elastichnyj_4_6388fb9be4", "mime": "image/jpeg", "name": "small_BU.12.4 кисть эластичный_4.jpg", "path": null, "size": 22, "width": 457, "height": 500, "sizeInBytes": 21999}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BU_12_4_kist_elastichnyj_4_6388fb9be4.jpg", "hash": "medium_BU_12_4_kist_elastichnyj_4_6388fb9be4", "mime": "image/jpeg", "name": "medium_BU.12.4 кисть эластичный_4.jpg", "path": null, "size": 46.14, "width": 686, "height": 750, "sizeInBytes": 46142}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BU_12_4_kist_elastichnyj_4_6388fb9be4.jpg", "hash": "thumbnail_BU_12_4_kist_elastichnyj_4_6388fb9be4", "mime": "image/jpeg", "name": "thumbnail_BU.12.4 кисть эластичный_4.jpg", "path": null, "size": 3.65, "width": 143, "height": 156, "sizeInBytes": 3648}}	BU_12_4_kist_elastichnyj_4_6388fb9be4	.jpg	image/jpeg	2500.38	/uploads/BU_12_4_kist_elastichnyj_4_6388fb9be4.jpg	\N	local	\N	/	2025-10-24 21:35:03.703	2025-10-24 21:35:03.703	2025-10-24 21:35:03.703	1	1	\N
42	uj679isqumnsuyg89fe05y29	BL.09.1 колено_1.jpg	\N	\N	4610	5921	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_09_1_koleno_1_5068e7a8d6.jpg", "hash": "large_BL_09_1_koleno_1_5068e7a8d6", "mime": "image/jpeg", "name": "large_BL.09.1 колено_1.jpg", "path": null, "size": 76.49, "width": 778, "height": 1000, "sizeInBytes": 76485}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_09_1_koleno_1_5068e7a8d6.jpg", "hash": "small_BL_09_1_koleno_1_5068e7a8d6", "mime": "image/jpeg", "name": "small_BL.09.1 колено_1.jpg", "path": null, "size": 20.24, "width": 389, "height": 500, "sizeInBytes": 20240}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_09_1_koleno_1_5068e7a8d6.jpg", "hash": "medium_BL_09_1_koleno_1_5068e7a8d6", "mime": "image/jpeg", "name": "medium_BL.09.1 колено_1.jpg", "path": null, "size": 43.71, "width": 584, "height": 750, "sizeInBytes": 43713}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_09_1_koleno_1_5068e7a8d6.jpg", "hash": "thumbnail_BL_09_1_koleno_1_5068e7a8d6", "mime": "image/jpeg", "name": "thumbnail_BL.09.1 колено_1.jpg", "path": null, "size": 3.1, "width": 121, "height": 156, "sizeInBytes": 3097}}	BL_09_1_koleno_1_5068e7a8d6	.jpg	image/jpeg	4099.61	/uploads/BL_09_1_koleno_1_5068e7a8d6.jpg	\N	local	\N	/	2025-10-24 21:38:13.949	2025-10-24 21:38:13.949	2025-10-24 21:38:13.949	1	1	\N
43	uqpd5njlqw763g4ir1d05iqq	BL.09.1 колено_2.jpg	\N	\N	3846	5645	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_09_1_koleno_2_f15830d139.jpg", "hash": "large_BL_09_1_koleno_2_f15830d139", "mime": "image/jpeg", "name": "large_BL.09.1 колено_2.jpg", "path": null, "size": 69.12, "width": 681, "height": 1000, "sizeInBytes": 69116}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_09_1_koleno_2_f15830d139.jpg", "hash": "small_BL_09_1_koleno_2_f15830d139", "mime": "image/jpeg", "name": "small_BL.09.1 колено_2.jpg", "path": null, "size": 17.3, "width": 340, "height": 500, "sizeInBytes": 17302}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_09_1_koleno_2_f15830d139.jpg", "hash": "medium_BL_09_1_koleno_2_f15830d139", "mime": "image/jpeg", "name": "medium_BL.09.1 колено_2.jpg", "path": null, "size": 38.56, "width": 511, "height": 750, "sizeInBytes": 38558}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_09_1_koleno_2_f15830d139.jpg", "hash": "thumbnail_BL_09_1_koleno_2_f15830d139", "mime": "image/jpeg", "name": "thumbnail_BL.09.1 колено_2.jpg", "path": null, "size": 2.51, "width": 106, "height": 156, "sizeInBytes": 2514}}	BL_09_1_koleno_2_f15830d139	.jpg	image/jpeg	3225.18	/uploads/BL_09_1_koleno_2_f15830d139.jpg	\N	local	\N	/	2025-10-24 21:39:32.825	2025-10-24 21:39:32.825	2025-10-24 21:39:32.826	1	1	\N
44	cqzv4s2h5s7f0gnivwwh4q7k	BL.09.1 колено_3.jpg	\N	\N	4730	6989	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_09_1_koleno_3_fd143cb78d.jpg", "hash": "large_BL_09_1_koleno_3_fd143cb78d", "mime": "image/jpeg", "name": "large_BL.09.1 колено_3.jpg", "path": null, "size": 58.51, "width": 677, "height": 1000, "sizeInBytes": 58509}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_09_1_koleno_3_fd143cb78d.jpg", "hash": "small_BL_09_1_koleno_3_fd143cb78d", "mime": "image/jpeg", "name": "small_BL.09.1 колено_3.jpg", "path": null, "size": 17.52, "width": 338, "height": 500, "sizeInBytes": 17525}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_09_1_koleno_3_fd143cb78d.jpg", "hash": "medium_BL_09_1_koleno_3_fd143cb78d", "mime": "image/jpeg", "name": "medium_BL.09.1 колено_3.jpg", "path": null, "size": 34.28, "width": 508, "height": 750, "sizeInBytes": 34275}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_09_1_koleno_3_fd143cb78d.jpg", "hash": "thumbnail_BL_09_1_koleno_3_fd143cb78d", "mime": "image/jpeg", "name": "thumbnail_BL.09.1 колено_3.jpg", "path": null, "size": 3.18, "width": 106, "height": 156, "sizeInBytes": 3181}}	BL_09_1_koleno_3_fd143cb78d	.jpg	image/jpeg	3768.51	/uploads/BL_09_1_koleno_3_fd143cb78d.jpg	\N	local	\N	/	2025-10-24 21:41:08.689	2025-10-24 21:41:08.689	2025-10-24 21:41:08.69	1	1	\N
45	r78lgkcsivr6pf6moobygmsp	BL.09.3 колено с силиконом и ребрами_1.jpg	\N	\N	3635	5595	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc.jpg", "hash": "large_BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc", "mime": "image/jpeg", "name": "large_BL.09.3 колено с силиконом и ребрами_1.jpg", "path": null, "size": 83.81, "width": 649, "height": 1000, "sizeInBytes": 83811}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc.jpg", "hash": "small_BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc", "mime": "image/jpeg", "name": "small_BL.09.3 колено с силиконом и ребрами_1.jpg", "path": null, "size": 22.27, "width": 325, "height": 500, "sizeInBytes": 22274}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc.jpg", "hash": "medium_BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc", "mime": "image/jpeg", "name": "medium_BL.09.3 колено с силиконом и ребрами_1.jpg", "path": null, "size": 49.07, "width": 487, "height": 750, "sizeInBytes": 49067}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc.jpg", "hash": "thumbnail_BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc", "mime": "image/jpeg", "name": "thumbnail_BL.09.3 колено с силиконом и ребрами_1.jpg", "path": null, "size": 2.65, "width": 101, "height": 156, "sizeInBytes": 2653}}	BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc	.jpg	image/jpeg	2544.67	/uploads/BL_09_3_koleno_s_silikonom_i_rebrami_1_a32a5cf9bc.jpg	\N	local	\N	/	2025-10-24 21:42:40.663	2025-10-24 21:42:40.663	2025-10-24 21:42:40.663	1	1	\N
46	nw7gqsg8e3ewmrib43q8btba	BL.09.3 колено с силиконом и ребрами_2.jpg	\N	\N	3846	5645	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135.jpg", "hash": "large_BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135", "mime": "image/jpeg", "name": "large_BL.09.3 колено с силиконом и ребрами_2.jpg", "path": null, "size": 69.12, "width": 681, "height": 1000, "sizeInBytes": 69116}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135.jpg", "hash": "small_BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135", "mime": "image/jpeg", "name": "small_BL.09.3 колено с силиконом и ребрами_2.jpg", "path": null, "size": 17.3, "width": 340, "height": 500, "sizeInBytes": 17302}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135.jpg", "hash": "medium_BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135", "mime": "image/jpeg", "name": "medium_BL.09.3 колено с силиконом и ребрами_2.jpg", "path": null, "size": 38.56, "width": 511, "height": 750, "sizeInBytes": 38558}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135.jpg", "hash": "thumbnail_BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135", "mime": "image/jpeg", "name": "thumbnail_BL.09.3 колено с силиконом и ребрами_2.jpg", "path": null, "size": 2.51, "width": 106, "height": 156, "sizeInBytes": 2514}}	BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135	.jpg	image/jpeg	3225.18	/uploads/BL_09_3_koleno_s_silikonom_i_rebrami_2_f72b53b135.jpg	\N	local	\N	/	2025-10-24 21:44:24.185	2025-10-24 21:44:24.185	2025-10-24 21:44:24.185	1	1	\N
47	a5hoiytko262mnz6sr7nq3nn	BL.09.3 колено с силиконом и ребрами_3.jpg	\N	\N	4654	3997	{"large": {"ext": ".jpg", "url": "/uploads/large_BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111.jpg", "hash": "large_BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111", "mime": "image/jpeg", "name": "large_BL.09.3 колено с силиконом и ребрами_3.jpg", "path": null, "size": 110.86, "width": 1000, "height": 859, "sizeInBytes": 110861}, "small": {"ext": ".jpg", "url": "/uploads/small_BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111.jpg", "hash": "small_BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111", "mime": "image/jpeg", "name": "small_BL.09.3 колено с силиконом и ребрами_3.jpg", "path": null, "size": 31.19, "width": 500, "height": 429, "sizeInBytes": 31193}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111.jpg", "hash": "medium_BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111", "mime": "image/jpeg", "name": "medium_BL.09.3 колено с силиконом и ребрами_3.jpg", "path": null, "size": 65.72, "width": 750, "height": 644, "sizeInBytes": 65724}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111.jpg", "hash": "thumbnail_BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111", "mime": "image/jpeg", "name": "thumbnail_BL.09.3 колено с силиконом и ребрами_3.jpg", "path": null, "size": 5.08, "width": 182, "height": 156, "sizeInBytes": 5079}}	BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111	.jpg	image/jpeg	1873.33	/uploads/BL_09_3_koleno_s_silikonom_i_rebrami_3_1e5821c111.jpg	\N	local	\N	/	2025-10-24 21:45:38.713	2025-10-24 21:45:38.713	2025-10-24 21:45:38.713	1	1	\N
48	t2e7mc9comhd0qw8sgyc1171	BU.15.1 локоть эластичный_1.jpg	\N	\N	4876	5254	{"large": {"ext": ".jpg", "url": "/uploads/large_BU_15_1_lokot_elastichnyj_1_bd146bf47d.jpg", "hash": "large_BU_15_1_lokot_elastichnyj_1_bd146bf47d", "mime": "image/jpeg", "name": "large_BU.15.1 локоть эластичный_1.jpg", "path": null, "size": 114.98, "width": 928, "height": 1000, "sizeInBytes": 114977}, "small": {"ext": ".jpg", "url": "/uploads/small_BU_15_1_lokot_elastichnyj_1_bd146bf47d.jpg", "hash": "small_BU_15_1_lokot_elastichnyj_1_bd146bf47d", "mime": "image/jpeg", "name": "small_BU.15.1 локоть эластичный_1.jpg", "path": null, "size": 29.26, "width": 464, "height": 500, "sizeInBytes": 29259}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BU_15_1_lokot_elastichnyj_1_bd146bf47d.jpg", "hash": "medium_BU_15_1_lokot_elastichnyj_1_bd146bf47d", "mime": "image/jpeg", "name": "medium_BU.15.1 локоть эластичный_1.jpg", "path": null, "size": 65.71, "width": 696, "height": 750, "sizeInBytes": 65706}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BU_15_1_lokot_elastichnyj_1_bd146bf47d.jpg", "hash": "thumbnail_BU_15_1_lokot_elastichnyj_1_bd146bf47d", "mime": "image/jpeg", "name": "thumbnail_BU.15.1 локоть эластичный_1.jpg", "path": null, "size": 3.96, "width": 145, "height": 156, "sizeInBytes": 3959}}	BU_15_1_lokot_elastichnyj_1_bd146bf47d	.jpg	image/jpeg	3895.55	/uploads/BU_15_1_lokot_elastichnyj_1_bd146bf47d.jpg	\N	local	\N	/	2025-10-25 09:39:01.071	2025-10-25 09:39:01.071	2025-10-25 09:39:01.071	1	1	\N
49	kwhrupa98esmbe4oob4lxmwl	BU.15.1 локоть эластичный_2.jpg	\N	\N	4660	6433	{"large": {"ext": ".jpg", "url": "/uploads/large_BU_15_1_lokot_elastichnyj_2_4e7a907c23.jpg", "hash": "large_BU_15_1_lokot_elastichnyj_2_4e7a907c23", "mime": "image/jpeg", "name": "large_BU.15.1 локоть эластичный_2.jpg", "path": null, "size": 95.51, "width": 725, "height": 1000, "sizeInBytes": 95509}, "small": {"ext": ".jpg", "url": "/uploads/small_BU_15_1_lokot_elastichnyj_2_4e7a907c23.jpg", "hash": "small_BU_15_1_lokot_elastichnyj_2_4e7a907c23", "mime": "image/jpeg", "name": "small_BU.15.1 локоть эластичный_2.jpg", "path": null, "size": 24.14, "width": 362, "height": 500, "sizeInBytes": 24137}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BU_15_1_lokot_elastichnyj_2_4e7a907c23.jpg", "hash": "medium_BU_15_1_lokot_elastichnyj_2_4e7a907c23", "mime": "image/jpeg", "name": "medium_BU.15.1 локоть эластичный_2.jpg", "path": null, "size": 53.85, "width": 543, "height": 750, "sizeInBytes": 53852}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BU_15_1_lokot_elastichnyj_2_4e7a907c23.jpg", "hash": "thumbnail_BU_15_1_lokot_elastichnyj_2_4e7a907c23", "mime": "image/jpeg", "name": "thumbnail_BU.15.1 локоть эластичный_2.jpg", "path": null, "size": 3.35, "width": 113, "height": 156, "sizeInBytes": 3351}}	BU_15_1_lokot_elastichnyj_2_4e7a907c23	.jpg	image/jpeg	5059.95	/uploads/BU_15_1_lokot_elastichnyj_2_4e7a907c23.jpg	\N	local	\N	/	2025-10-25 09:41:03.01	2025-10-25 09:41:03.01	2025-10-25 09:41:03.01	1	1	\N
50	lw1aorizbu5zq0yc8fs31u4g	BU.15.1 локоть эластичный_3.jpg	\N	\N	4912	6405	{"large": {"ext": ".jpg", "url": "/uploads/large_BU_15_1_lokot_elastichnyj_3_2825b6984b.jpg", "hash": "large_BU_15_1_lokot_elastichnyj_3_2825b6984b", "mime": "image/jpeg", "name": "large_BU.15.1 локоть эластичный_3.jpg", "path": null, "size": 139.39, "width": 767, "height": 1000, "sizeInBytes": 139394}, "small": {"ext": ".jpg", "url": "/uploads/small_BU_15_1_lokot_elastichnyj_3_2825b6984b.jpg", "hash": "small_BU_15_1_lokot_elastichnyj_3_2825b6984b", "mime": "image/jpeg", "name": "small_BU.15.1 локоть эластичный_3.jpg", "path": null, "size": 33.33, "width": 384, "height": 500, "sizeInBytes": 33331}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BU_15_1_lokot_elastichnyj_3_2825b6984b.jpg", "hash": "medium_BU_15_1_lokot_elastichnyj_3_2825b6984b", "mime": "image/jpeg", "name": "medium_BU.15.1 локоть эластичный_3.jpg", "path": null, "size": 76.94, "width": 575, "height": 750, "sizeInBytes": 76936}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BU_15_1_lokot_elastichnyj_3_2825b6984b.jpg", "hash": "thumbnail_BU_15_1_lokot_elastichnyj_3_2825b6984b", "mime": "image/jpeg", "name": "thumbnail_BU.15.1 локоть эластичный_3.jpg", "path": null, "size": 3.6, "width": 120, "height": 156, "sizeInBytes": 3595}}	BU_15_1_lokot_elastichnyj_3_2825b6984b	.jpg	image/jpeg	6635.13	/uploads/BU_15_1_lokot_elastichnyj_3_2825b6984b.jpg	\N	local	\N	/	2025-10-25 09:42:24.154	2025-10-25 09:42:24.154	2025-10-25 09:42:24.154	1	1	\N
51	rdvjhaqcr0kpgtj4bq57sriy	BU.15.1 локоть эластичный_4.jpg	\N	\N	4626	5596	{"large": {"ext": ".jpg", "url": "/uploads/large_BU_15_1_lokot_elastichnyj_4_cf4909207e.jpg", "hash": "large_BU_15_1_lokot_elastichnyj_4_cf4909207e", "mime": "image/jpeg", "name": "large_BU.15.1 локоть эластичный_4.jpg", "path": null, "size": 68.16, "width": 826, "height": 1000, "sizeInBytes": 68160}, "small": {"ext": ".jpg", "url": "/uploads/small_BU_15_1_lokot_elastichnyj_4_cf4909207e.jpg", "hash": "small_BU_15_1_lokot_elastichnyj_4_cf4909207e", "mime": "image/jpeg", "name": "small_BU.15.1 локоть эластичный_4.jpg", "path": null, "size": 17.63, "width": 413, "height": 500, "sizeInBytes": 17629}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BU_15_1_lokot_elastichnyj_4_cf4909207e.jpg", "hash": "medium_BU_15_1_lokot_elastichnyj_4_cf4909207e", "mime": "image/jpeg", "name": "medium_BU.15.1 локоть эластичный_4.jpg", "path": null, "size": 38.48, "width": 620, "height": 750, "sizeInBytes": 38478}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BU_15_1_lokot_elastichnyj_4_cf4909207e.jpg", "hash": "thumbnail_BU_15_1_lokot_elastichnyj_4_cf4909207e", "mime": "image/jpeg", "name": "thumbnail_BU.15.1 локоть эластичный_4.jpg", "path": null, "size": 2.76, "width": 129, "height": 156, "sizeInBytes": 2762}}	BU_15_1_lokot_elastichnyj_4_cf4909207e	.jpg	image/jpeg	3441.49	/uploads/BU_15_1_lokot_elastichnyj_4_cf4909207e.jpg	\N	local	\N	/	2025-10-25 09:43:49.478	2025-10-25 09:43:49.478	2025-10-25 09:43:49.478	1	1	\N
52	l5vpa2dj2t967xqx44kn4k51	BV.06.1 корсет черный_1.jpg	\N	\N	4085	3881	{"large": {"ext": ".jpg", "url": "/uploads/large_BV_06_1_korset_chernyj_1_b6202d2353.jpg", "hash": "large_BV_06_1_korset_chernyj_1_b6202d2353", "mime": "image/jpeg", "name": "large_BV.06.1 корсет черный_1.jpg", "path": null, "size": 80.97, "width": 1000, "height": 950, "sizeInBytes": 80974}, "small": {"ext": ".jpg", "url": "/uploads/small_BV_06_1_korset_chernyj_1_b6202d2353.jpg", "hash": "small_BV_06_1_korset_chernyj_1_b6202d2353", "mime": "image/jpeg", "name": "small_BV.06.1 корсет черный_1.jpg", "path": null, "size": 22.79, "width": 500, "height": 475, "sizeInBytes": 22785}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BV_06_1_korset_chernyj_1_b6202d2353.jpg", "hash": "medium_BV_06_1_korset_chernyj_1_b6202d2353", "mime": "image/jpeg", "name": "medium_BV.06.1 корсет черный_1.jpg", "path": null, "size": 46.72, "width": 750, "height": 713, "sizeInBytes": 46717}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BV_06_1_korset_chernyj_1_b6202d2353.jpg", "hash": "thumbnail_BV_06_1_korset_chernyj_1_b6202d2353", "mime": "image/jpeg", "name": "thumbnail_BV.06.1 корсет черный_1.jpg", "path": null, "size": 4.07, "width": 164, "height": 156, "sizeInBytes": 4073}}	BV_06_1_korset_chernyj_1_b6202d2353	.jpg	image/jpeg	1386.53	/uploads/BV_06_1_korset_chernyj_1_b6202d2353.jpg	\N	local	\N	/	2025-10-25 09:46:15.619	2025-10-25 09:46:15.619	2025-10-25 09:46:15.619	1	1	\N
53	o1abriofnwzc1gbz8tbo18nq	BV.06.1 корсет черный_2.jpg	\N	\N	4470	3772	{"large": {"ext": ".jpg", "url": "/uploads/large_BV_06_1_korset_chernyj_2_b986767dfc.jpg", "hash": "large_BV_06_1_korset_chernyj_2_b986767dfc", "mime": "image/jpeg", "name": "large_BV.06.1 корсет черный_2.jpg", "path": null, "size": 67.69, "width": 1000, "height": 844, "sizeInBytes": 67691}, "small": {"ext": ".jpg", "url": "/uploads/small_BV_06_1_korset_chernyj_2_b986767dfc.jpg", "hash": "small_BV_06_1_korset_chernyj_2_b986767dfc", "mime": "image/jpeg", "name": "small_BV.06.1 корсет черный_2.jpg", "path": null, "size": 17.73, "width": 500, "height": 422, "sizeInBytes": 17731}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BV_06_1_korset_chernyj_2_b986767dfc.jpg", "hash": "medium_BV_06_1_korset_chernyj_2_b986767dfc", "mime": "image/jpeg", "name": "medium_BV.06.1 корсет черный_2.jpg", "path": null, "size": 37.66, "width": 750, "height": 633, "sizeInBytes": 37655}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BV_06_1_korset_chernyj_2_b986767dfc.jpg", "hash": "thumbnail_BV_06_1_korset_chernyj_2_b986767dfc", "mime": "image/jpeg", "name": "thumbnail_BV.06.1 корсет черный_2.jpg", "path": null, "size": 3.78, "width": 185, "height": 156, "sizeInBytes": 3780}}	BV_06_1_korset_chernyj_2_b986767dfc	.jpg	image/jpeg	1696.31	/uploads/BV_06_1_korset_chernyj_2_b986767dfc.jpg	\N	local	\N	/	2025-10-25 09:48:16.912	2025-10-25 09:48:16.912	2025-10-25 09:48:16.913	1	1	\N
55	ud9pbehbgygmha3wrdmyatbw	BV.06.1 корсет черный_3.jpg	\N	\N	3915	4128	{"large": {"ext": ".jpg", "url": "/uploads/large_BV_06_1_korset_chernyj_3_136a35b5f3.jpg", "hash": "large_BV_06_1_korset_chernyj_3_136a35b5f3", "mime": "image/jpeg", "name": "large_BV.06.1 корсет черный_3.jpg", "path": null, "size": 72.76, "width": 948, "height": 1000, "sizeInBytes": 72758}, "small": {"ext": ".jpg", "url": "/uploads/small_BV_06_1_korset_chernyj_3_136a35b5f3.jpg", "hash": "small_BV_06_1_korset_chernyj_3_136a35b5f3", "mime": "image/jpeg", "name": "small_BV.06.1 корсет черный_3.jpg", "path": null, "size": 19.95, "width": 474, "height": 500, "sizeInBytes": 19949}, "medium": {"ext": ".jpg", "url": "/uploads/medium_BV_06_1_korset_chernyj_3_136a35b5f3.jpg", "hash": "medium_BV_06_1_korset_chernyj_3_136a35b5f3", "mime": "image/jpeg", "name": "medium_BV.06.1 корсет черный_3.jpg", "path": null, "size": 41.28, "width": 711, "height": 750, "sizeInBytes": 41282}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_BV_06_1_korset_chernyj_3_136a35b5f3.jpg", "hash": "thumbnail_BV_06_1_korset_chernyj_3_136a35b5f3", "mime": "image/jpeg", "name": "thumbnail_BV.06.1 корсет черный_3.jpg", "path": null, "size": 3.39, "width": 148, "height": 156, "sizeInBytes": 3390}}	BV_06_1_korset_chernyj_3_136a35b5f3	.jpg	image/jpeg	1459.70	/uploads/BV_06_1_korset_chernyj_3_136a35b5f3.jpg	\N	local	\N	/	2025-10-25 09:50:07.886	2025-10-25 09:50:07.886	2025-10-25 09:50:07.887	1	1	\N
23	cggyz0vxhn2sbo58fkm38kh5	L1.AD.1 Гольфы микрофибра 1 КК, бежевые-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21.jpg", "hash": "large_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21", "mime": "image/jpeg", "name": "large_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-1.jpg", "path": null, "size": 35.46, "width": 1000, "height": 1000, "sizeInBytes": 35459}, "small": {"ext": ".jpg", "url": "/uploads/small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21.jpg", "hash": "small_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21", "mime": "image/jpeg", "name": "small_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-1.jpg", "path": null, "size": 12.21, "width": 500, "height": 500, "sizeInBytes": 12213}, "medium": {"ext": ".jpg", "url": "/uploads/medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21.jpg", "hash": "medium_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21", "mime": "image/jpeg", "name": "medium_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-1.jpg", "path": null, "size": 22.36, "width": 750, "height": 750, "sizeInBytes": 22359}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21.jpg", "hash": "thumbnail_L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21", "mime": "image/jpeg", "name": "thumbnail_L1.AD.1 Гольфы микрофибра 1 КК, бежевые-1.jpg", "path": null, "size": 2.66, "width": 156, "height": 156, "sizeInBytes": 2663}}	L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21	.jpg	image/jpeg	115.35	/uploads/L1_AD_1_Golfy_mikrofibra_1_KK_bezhevye_1_b8d002ff21.jpg	\N	local	\N	/	2025-10-24 20:40:41.688	2025-10-25 11:39:23.588	2025-10-24 20:40:41.688	1	1	\N
56	hp98s59ul8e4jkqgi6f99fuv	QL.S1.1 полустельки МАЛЫШ-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f.jpg", "hash": "large_QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f", "mime": "image/jpeg", "name": "large_QL.S1.1 полустельки МАЛЫШ-1.jpg", "path": null, "size": 35.21, "width": 1000, "height": 1000, "sizeInBytes": 35214}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f.jpg", "hash": "small_QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f", "mime": "image/jpeg", "name": "small_QL.S1.1 полустельки МАЛЫШ-1.jpg", "path": null, "size": 11.72, "width": 500, "height": 500, "sizeInBytes": 11715}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f.jpg", "hash": "medium_QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f", "mime": "image/jpeg", "name": "medium_QL.S1.1 полустельки МАЛЫШ-1.jpg", "path": null, "size": 22.6, "width": 750, "height": 750, "sizeInBytes": 22600}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f.jpg", "hash": "thumbnail_QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f", "mime": "image/jpeg", "name": "thumbnail_QL.S1.1 полустельки МАЛЫШ-1.jpg", "path": null, "size": 2.14, "width": 156, "height": 156, "sizeInBytes": 2140}}	QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f	.jpg	image/jpeg	98.06	/uploads/QL_S1_1_polustelki_MALY_Sh_1_6dfe86a92f.jpg	\N	local	\N	/	2025-10-25 15:12:53.903	2025-10-25 15:12:53.903	2025-10-25 15:12:53.904	1	1	\N
58	qslx7vnxpuyez9dlhfsao4rs	QL.S1.1 полустельки МАЛЫШ-6.jpg	\N	\N	853	1280	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S1_1_polustelki_MALY_Sh_6_01344e1549.jpg", "hash": "large_QL_S1_1_polustelki_MALY_Sh_6_01344e1549", "mime": "image/jpeg", "name": "large_QL.S1.1 полустельки МАЛЫШ-6.jpg", "path": null, "size": 61.66, "width": 666, "height": 1000, "sizeInBytes": 61656}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S1_1_polustelki_MALY_Sh_6_01344e1549.jpg", "hash": "small_QL_S1_1_polustelki_MALY_Sh_6_01344e1549", "mime": "image/jpeg", "name": "small_QL.S1.1 полустельки МАЛЫШ-6.jpg", "path": null, "size": 19.95, "width": 333, "height": 500, "sizeInBytes": 19954}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S1_1_polustelki_MALY_Sh_6_01344e1549.jpg", "hash": "medium_QL_S1_1_polustelki_MALY_Sh_6_01344e1549", "mime": "image/jpeg", "name": "medium_QL.S1.1 полустельки МАЛЫШ-6.jpg", "path": null, "size": 39.03, "width": 500, "height": 750, "sizeInBytes": 39025}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S1_1_polustelki_MALY_Sh_6_01344e1549.jpg", "hash": "thumbnail_QL_S1_1_polustelki_MALY_Sh_6_01344e1549", "mime": "image/jpeg", "name": "thumbnail_QL.S1.1 полустельки МАЛЫШ-6.jpg", "path": null, "size": 3.08, "width": 104, "height": 156, "sizeInBytes": 3080}}	QL_S1_1_polustelki_MALY_Sh_6_01344e1549	.jpg	image/jpeg	97.56	/uploads/QL_S1_1_polustelki_MALY_Sh_6_01344e1549.jpg	\N	local	\N	/	2025-10-25 15:14:49.089	2025-10-25 15:14:49.089	2025-10-25 15:14:49.089	1	1	\N
59	k8ukuypaduoqea5atwn0hlk8	QL.S1.1 полустельки МАЛЫШ-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40.jpg", "hash": "large_QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40", "mime": "image/jpeg", "name": "large_QL.S1.1 полустельки МАЛЫШ-1.jpg", "path": null, "size": 35.21, "width": 1000, "height": 1000, "sizeInBytes": 35214}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40.jpg", "hash": "small_QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40", "mime": "image/jpeg", "name": "small_QL.S1.1 полустельки МАЛЫШ-1.jpg", "path": null, "size": 11.72, "width": 500, "height": 500, "sizeInBytes": 11715}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40.jpg", "hash": "medium_QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40", "mime": "image/jpeg", "name": "medium_QL.S1.1 полустельки МАЛЫШ-1.jpg", "path": null, "size": 22.6, "width": 750, "height": 750, "sizeInBytes": 22600}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40.jpg", "hash": "thumbnail_QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40", "mime": "image/jpeg", "name": "thumbnail_QL.S1.1 полустельки МАЛЫШ-1.jpg", "path": null, "size": 2.14, "width": 156, "height": 156, "sizeInBytes": 2140}}	QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40	.jpg	image/jpeg	98.06	/uploads/QL_S1_1_polustelki_MALY_Sh_1_2b9457dd40.jpg	\N	local	\N	/	2025-10-25 15:14:49.69	2025-10-25 15:14:49.69	2025-10-25 15:14:49.69	1	1	\N
61	aqeqk5s8c8aj8yt9afz69kog	QL.S1.1 полустельки МАЛЫШ-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313.jpg", "hash": "large_QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313", "mime": "image/jpeg", "name": "large_QL.S1.1 полустельки МАЛЫШ-3.jpg", "path": null, "size": 40.52, "width": 1000, "height": 1000, "sizeInBytes": 40517}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313.jpg", "hash": "small_QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313", "mime": "image/jpeg", "name": "small_QL.S1.1 полустельки МАЛЫШ-3.jpg", "path": null, "size": 13.33, "width": 500, "height": 500, "sizeInBytes": 13332}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313.jpg", "hash": "medium_QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313", "mime": "image/jpeg", "name": "medium_QL.S1.1 полустельки МАЛЫШ-3.jpg", "path": null, "size": 25.69, "width": 750, "height": 750, "sizeInBytes": 25689}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313.jpg", "hash": "thumbnail_QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313", "mime": "image/jpeg", "name": "thumbnail_QL.S1.1 полустельки МАЛЫШ-3.jpg", "path": null, "size": 2.22, "width": 156, "height": 156, "sizeInBytes": 2223}}	QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313	.jpg	image/jpeg	124.50	/uploads/QL_S1_1_polustelki_MALY_Sh_3_3f9f98e313.jpg	\N	local	\N	/	2025-10-25 15:14:50.253	2025-10-25 15:14:50.253	2025-10-25 15:14:50.253	1	1	\N
62	m9imliuvoafpiv407n7eqp1d	QL.S1.1 полустельки МАЛЫШ-5.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S1_1_polustelki_MALY_Sh_5_342012b9c4.jpg", "hash": "large_QL_S1_1_polustelki_MALY_Sh_5_342012b9c4", "mime": "image/jpeg", "name": "large_QL.S1.1 полустельки МАЛЫШ-5.jpg", "path": null, "size": 31.59, "width": 1000, "height": 1000, "sizeInBytes": 31593}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S1_1_polustelki_MALY_Sh_5_342012b9c4.jpg", "hash": "small_QL_S1_1_polustelki_MALY_Sh_5_342012b9c4", "mime": "image/jpeg", "name": "small_QL.S1.1 полустельки МАЛЫШ-5.jpg", "path": null, "size": 10.06, "width": 500, "height": 500, "sizeInBytes": 10058}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S1_1_polustelki_MALY_Sh_5_342012b9c4.jpg", "hash": "medium_QL_S1_1_polustelki_MALY_Sh_5_342012b9c4", "mime": "image/jpeg", "name": "medium_QL.S1.1 полустельки МАЛЫШ-5.jpg", "path": null, "size": 19.7, "width": 750, "height": 750, "sizeInBytes": 19702}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S1_1_polustelki_MALY_Sh_5_342012b9c4.jpg", "hash": "thumbnail_QL_S1_1_polustelki_MALY_Sh_5_342012b9c4", "mime": "image/jpeg", "name": "thumbnail_QL.S1.1 полустельки МАЛЫШ-5.jpg", "path": null, "size": 1.82, "width": 156, "height": 156, "sizeInBytes": 1819}}	QL_S1_1_polustelki_MALY_Sh_5_342012b9c4	.jpg	image/jpeg	92.93	/uploads/QL_S1_1_polustelki_MALY_Sh_5_342012b9c4.jpg	\N	local	\N	/	2025-10-25 15:14:50.552	2025-10-25 15:14:50.552	2025-10-25 15:14:50.553	1	1	\N
57	br9h9whcdp14s8a1s7s9dtwx	QL.S1.1 полустельки МАЛЫШ-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4.jpg", "hash": "large_QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4", "mime": "image/jpeg", "name": "large_QL.S1.1 полустельки МАЛЫШ-4.jpg", "path": null, "size": 35.57, "width": 1000, "height": 1000, "sizeInBytes": 35567}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4.jpg", "hash": "small_QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4", "mime": "image/jpeg", "name": "small_QL.S1.1 полустельки МАЛЫШ-4.jpg", "path": null, "size": 11.01, "width": 500, "height": 500, "sizeInBytes": 11011}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4.jpg", "hash": "medium_QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4", "mime": "image/jpeg", "name": "medium_QL.S1.1 полустельки МАЛЫШ-4.jpg", "path": null, "size": 22.17, "width": 750, "height": 750, "sizeInBytes": 22173}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4.jpg", "hash": "thumbnail_QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4", "mime": "image/jpeg", "name": "thumbnail_QL.S1.1 полустельки МАЛЫШ-4.jpg", "path": null, "size": 2.06, "width": 156, "height": 156, "sizeInBytes": 2056}}	QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4	.jpg	image/jpeg	103.30	/uploads/QL_S1_1_polustelki_MALY_Sh_4_fed214f9e4.jpg	\N	local	\N	/	2025-10-25 15:14:48.346	2025-10-25 15:16:54.985	2025-10-25 15:14:48.346	1	1	\N
63	c88gpdh3sifk6kqbks3wmf55	PT.S2.2_стельки АРКТИКА-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_2_stelki_ARKTIKA_1_9c11c477c5.jpg", "hash": "large_PT_S2_2_stelki_ARKTIKA_1_9c11c477c5", "mime": "image/jpeg", "name": "large_PT.S2.2_стельки АРКТИКА-1.jpg", "path": null, "size": 78.24, "width": 1000, "height": 1000, "sizeInBytes": 78237}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_2_stelki_ARKTIKA_1_9c11c477c5.jpg", "hash": "small_PT_S2_2_stelki_ARKTIKA_1_9c11c477c5", "mime": "image/jpeg", "name": "small_PT.S2.2_стельки АРКТИКА-1.jpg", "path": null, "size": 23.22, "width": 500, "height": 500, "sizeInBytes": 23217}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_2_stelki_ARKTIKA_1_9c11c477c5.jpg", "hash": "medium_PT_S2_2_stelki_ARKTIKA_1_9c11c477c5", "mime": "image/jpeg", "name": "medium_PT.S2.2_стельки АРКТИКА-1.jpg", "path": null, "size": 48.47, "width": 750, "height": 750, "sizeInBytes": 48470}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_2_stelki_ARKTIKA_1_9c11c477c5.jpg", "hash": "thumbnail_PT_S2_2_stelki_ARKTIKA_1_9c11c477c5", "mime": "image/jpeg", "name": "thumbnail_PT.S2.2_стельки АРКТИКА-1.jpg", "path": null, "size": 3.18, "width": 156, "height": 156, "sizeInBytes": 3182}}	PT_S2_2_stelki_ARKTIKA_1_9c11c477c5	.jpg	image/jpeg	217.37	/uploads/PT_S2_2_stelki_ARKTIKA_1_9c11c477c5.jpg	\N	local	\N	/	2025-10-25 15:20:54.76	2025-10-25 15:20:54.76	2025-10-25 15:20:54.76	1	1	\N
64	cnkzcyehph2bmjt0czwto617	PT.S2.2_стельки АРКТИКА-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_2_stelki_ARKTIKA_3_f08a65cd09.jpg", "hash": "large_PT_S2_2_stelki_ARKTIKA_3_f08a65cd09", "mime": "image/jpeg", "name": "large_PT.S2.2_стельки АРКТИКА-3.jpg", "path": null, "size": 78.26, "width": 1000, "height": 1000, "sizeInBytes": 78259}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_2_stelki_ARKTIKA_3_f08a65cd09.jpg", "hash": "small_PT_S2_2_stelki_ARKTIKA_3_f08a65cd09", "mime": "image/jpeg", "name": "small_PT.S2.2_стельки АРКТИКА-3.jpg", "path": null, "size": 21.11, "width": 500, "height": 500, "sizeInBytes": 21106}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_2_stelki_ARKTIKA_3_f08a65cd09.jpg", "hash": "medium_PT_S2_2_stelki_ARKTIKA_3_f08a65cd09", "mime": "image/jpeg", "name": "medium_PT.S2.2_стельки АРКТИКА-3.jpg", "path": null, "size": 46.63, "width": 750, "height": 750, "sizeInBytes": 46634}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_2_stelki_ARKTIKA_3_f08a65cd09.jpg", "hash": "thumbnail_PT_S2_2_stelki_ARKTIKA_3_f08a65cd09", "mime": "image/jpeg", "name": "thumbnail_PT.S2.2_стельки АРКТИКА-3.jpg", "path": null, "size": 2.13, "width": 156, "height": 156, "sizeInBytes": 2134}}	PT_S2_2_stelki_ARKTIKA_3_f08a65cd09	.jpg	image/jpeg	229.60	/uploads/PT_S2_2_stelki_ARKTIKA_3_f08a65cd09.jpg	\N	local	\N	/	2025-10-25 15:22:10.24	2025-10-25 15:22:10.24	2025-10-25 15:22:10.241	1	1	\N
65	j6nsbbapkgtiix6gbc8dzd8b	PT.S2.2_стельки АРКТИКА-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4.jpg", "hash": "large_PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4", "mime": "image/jpeg", "name": "large_PT.S2.2_стельки АРКТИКА-2.jpg", "path": null, "size": 32.39, "width": 1000, "height": 1000, "sizeInBytes": 32389}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4.jpg", "hash": "small_PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4", "mime": "image/jpeg", "name": "small_PT.S2.2_стельки АРКТИКА-2.jpg", "path": null, "size": 10.58, "width": 500, "height": 500, "sizeInBytes": 10576}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4.jpg", "hash": "medium_PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4", "mime": "image/jpeg", "name": "medium_PT.S2.2_стельки АРКТИКА-2.jpg", "path": null, "size": 20.23, "width": 750, "height": 750, "sizeInBytes": 20229}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4.jpg", "hash": "thumbnail_PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4", "mime": "image/jpeg", "name": "thumbnail_PT.S2.2_стельки АРКТИКА-2.jpg", "path": null, "size": 1.98, "width": 156, "height": 156, "sizeInBytes": 1984}}	PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4	.jpg	image/jpeg	96.15	/uploads/PT_S2_2_stelki_ARKTIKA_2_2405bbf5d4.jpg	\N	local	\N	/	2025-10-25 15:22:10.841	2025-10-25 15:22:10.841	2025-10-25 15:22:10.841	1	1	\N
66	iwu9w807nncbdqv4vkz3hsyc	PT.S2.2_стельки АРКТИКА-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_2_stelki_ARKTIKA_4_df81ea3d39.jpg", "hash": "large_PT_S2_2_stelki_ARKTIKA_4_df81ea3d39", "mime": "image/jpeg", "name": "large_PT.S2.2_стельки АРКТИКА-4.jpg", "path": null, "size": 81.57, "width": 1000, "height": 1000, "sizeInBytes": 81571}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_2_stelki_ARKTIKA_4_df81ea3d39.jpg", "hash": "small_PT_S2_2_stelki_ARKTIKA_4_df81ea3d39", "mime": "image/jpeg", "name": "small_PT.S2.2_стельки АРКТИКА-4.jpg", "path": null, "size": 25.18, "width": 500, "height": 500, "sizeInBytes": 25183}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_2_stelki_ARKTIKA_4_df81ea3d39.jpg", "hash": "medium_PT_S2_2_stelki_ARKTIKA_4_df81ea3d39", "mime": "image/jpeg", "name": "medium_PT.S2.2_стельки АРКТИКА-4.jpg", "path": null, "size": 51.06, "width": 750, "height": 750, "sizeInBytes": 51055}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_2_stelki_ARKTIKA_4_df81ea3d39.jpg", "hash": "thumbnail_PT_S2_2_stelki_ARKTIKA_4_df81ea3d39", "mime": "image/jpeg", "name": "thumbnail_PT.S2.2_стельки АРКТИКА-4.jpg", "path": null, "size": 3.64, "width": 156, "height": 156, "sizeInBytes": 3643}}	PT_S2_2_stelki_ARKTIKA_4_df81ea3d39	.jpg	image/jpeg	227.24	/uploads/PT_S2_2_stelki_ARKTIKA_4_df81ea3d39.jpg	\N	local	\N	/	2025-10-25 15:22:11.564	2025-10-25 15:22:11.564	2025-10-25 15:22:11.564	1	1	\N
67	ihqs4lknw03iyfwx75etoyrq	PT.S2.2_стельки АРКТИКА-5.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_2_stelki_ARKTIKA_5_6474beedf9.jpg", "hash": "large_PT_S2_2_stelki_ARKTIKA_5_6474beedf9", "mime": "image/jpeg", "name": "large_PT.S2.2_стельки АРКТИКА-5.jpg", "path": null, "size": 31.95, "width": 1000, "height": 1000, "sizeInBytes": 31948}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_2_stelki_ARKTIKA_5_6474beedf9.jpg", "hash": "small_PT_S2_2_stelki_ARKTIKA_5_6474beedf9", "mime": "image/jpeg", "name": "small_PT.S2.2_стельки АРКТИКА-5.jpg", "path": null, "size": 10.37, "width": 500, "height": 500, "sizeInBytes": 10365}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_2_stelki_ARKTIKA_5_6474beedf9.jpg", "hash": "medium_PT_S2_2_stelki_ARKTIKA_5_6474beedf9", "mime": "image/jpeg", "name": "medium_PT.S2.2_стельки АРКТИКА-5.jpg", "path": null, "size": 19.87, "width": 750, "height": 750, "sizeInBytes": 19870}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_2_stelki_ARKTIKA_5_6474beedf9.jpg", "hash": "thumbnail_PT_S2_2_stelki_ARKTIKA_5_6474beedf9", "mime": "image/jpeg", "name": "thumbnail_PT.S2.2_стельки АРКТИКА-5.jpg", "path": null, "size": 1.85, "width": 156, "height": 156, "sizeInBytes": 1851}}	PT_S2_2_stelki_ARKTIKA_5_6474beedf9	.jpg	image/jpeg	100.05	/uploads/PT_S2_2_stelki_ARKTIKA_5_6474beedf9.jpg	\N	local	\N	/	2025-10-25 15:22:11.978	2025-10-25 15:22:11.978	2025-10-25 15:22:11.978	1	1	\N
68	cz6hwoelgzqozqy91in86uv1	PT.S2.2_стельки АРКТИКА-7.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_2_stelki_ARKTIKA_7_6d52a54d92.jpg", "hash": "large_PT_S2_2_stelki_ARKTIKA_7_6d52a54d92", "mime": "image/jpeg", "name": "large_PT.S2.2_стельки АРКТИКА-7.jpg", "path": null, "size": 57.55, "width": 1000, "height": 1000, "sizeInBytes": 57545}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_2_stelki_ARKTIKA_7_6d52a54d92.jpg", "hash": "small_PT_S2_2_stelki_ARKTIKA_7_6d52a54d92", "mime": "image/jpeg", "name": "small_PT.S2.2_стельки АРКТИКА-7.jpg", "path": null, "size": 19.88, "width": 500, "height": 500, "sizeInBytes": 19877}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_2_stelki_ARKTIKA_7_6d52a54d92.jpg", "hash": "medium_PT_S2_2_stelki_ARKTIKA_7_6d52a54d92", "mime": "image/jpeg", "name": "medium_PT.S2.2_стельки АРКТИКА-7.jpg", "path": null, "size": 37.37, "width": 750, "height": 750, "sizeInBytes": 37371}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_2_stelki_ARKTIKA_7_6d52a54d92.jpg", "hash": "thumbnail_PT_S2_2_stelki_ARKTIKA_7_6d52a54d92", "mime": "image/jpeg", "name": "thumbnail_PT.S2.2_стельки АРКТИКА-7.jpg", "path": null, "size": 3.18, "width": 156, "height": 156, "sizeInBytes": 3177}}	PT_S2_2_stelki_ARKTIKA_7_6d52a54d92	.jpg	image/jpeg	151.87	/uploads/PT_S2_2_stelki_ARKTIKA_7_6d52a54d92.jpg	\N	local	\N	/	2025-10-25 15:22:12.193	2025-10-25 15:22:12.193	2025-10-25 15:22:12.193	1	1	\N
60	xnevhpianxum5h3cep0mn3zd	QL.S1.1 полустельки МАЛЫШ-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2.jpg", "hash": "large_QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2", "mime": "image/jpeg", "name": "large_QL.S1.1 полустельки МАЛЫШ-2.jpg", "path": null, "size": 37.51, "width": 1000, "height": 1000, "sizeInBytes": 37508}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2.jpg", "hash": "small_QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2", "mime": "image/jpeg", "name": "small_QL.S1.1 полустельки МАЛЫШ-2.jpg", "path": null, "size": 12.13, "width": 500, "height": 500, "sizeInBytes": 12128}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2.jpg", "hash": "medium_QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2", "mime": "image/jpeg", "name": "medium_QL.S1.1 полустельки МАЛЫШ-2.jpg", "path": null, "size": 23.45, "width": 750, "height": 750, "sizeInBytes": 23448}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2.jpg", "hash": "thumbnail_QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2", "mime": "image/jpeg", "name": "thumbnail_QL.S1.1 полустельки МАЛЫШ-2.jpg", "path": null, "size": 2.04, "width": 156, "height": 156, "sizeInBytes": 2043}}	QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2	.jpg	image/jpeg	112.36	/uploads/QL_S1_1_polustelki_MALY_Sh_2_3668f72ec2.jpg	\N	local	\N	/	2025-10-25 15:14:49.928	2025-10-25 15:25:47.702	2025-10-25 15:14:49.928	1	1	\N
69	rc16zh9hcov553dq2vovw5gq	PL.S2.1 стельки БАЛАНС-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PL_S2_1_stelki_BALANS_4_c260f52110.jpg", "hash": "large_PL_S2_1_stelki_BALANS_4_c260f52110", "mime": "image/jpeg", "name": "large_PL.S2.1 стельки БАЛАНС-4.jpg", "path": null, "size": 53.98, "width": 1000, "height": 1000, "sizeInBytes": 53979}, "small": {"ext": ".jpg", "url": "/uploads/small_PL_S2_1_stelki_BALANS_4_c260f52110.jpg", "hash": "small_PL_S2_1_stelki_BALANS_4_c260f52110", "mime": "image/jpeg", "name": "small_PL.S2.1 стельки БАЛАНС-4.jpg", "path": null, "size": 16.6, "width": 500, "height": 500, "sizeInBytes": 16596}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PL_S2_1_stelki_BALANS_4_c260f52110.jpg", "hash": "medium_PL_S2_1_stelki_BALANS_4_c260f52110", "mime": "image/jpeg", "name": "medium_PL.S2.1 стельки БАЛАНС-4.jpg", "path": null, "size": 32.45, "width": 750, "height": 750, "sizeInBytes": 32447}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PL_S2_1_stelki_BALANS_4_c260f52110.jpg", "hash": "thumbnail_PL_S2_1_stelki_BALANS_4_c260f52110", "mime": "image/jpeg", "name": "thumbnail_PL.S2.1 стельки БАЛАНС-4.jpg", "path": null, "size": 3.27, "width": 156, "height": 156, "sizeInBytes": 3267}}	PL_S2_1_stelki_BALANS_4_c260f52110	.jpg	image/jpeg	191.64	/uploads/PL_S2_1_stelki_BALANS_4_c260f52110.jpg	\N	local	\N	/	2025-10-25 15:28:44.681	2025-10-25 15:28:44.681	2025-10-25 15:28:44.681	1	1	\N
70	ftci3tiyg6zwm4loshx06444	PL.S2.1 стельки БАЛАНС-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PL_S2_1_stelki_BALANS_2_06dfd13cb0.jpg", "hash": "large_PL_S2_1_stelki_BALANS_2_06dfd13cb0", "mime": "image/jpeg", "name": "large_PL.S2.1 стельки БАЛАНС-2.jpg", "path": null, "size": 35.81, "width": 1000, "height": 1000, "sizeInBytes": 35814}, "small": {"ext": ".jpg", "url": "/uploads/small_PL_S2_1_stelki_BALANS_2_06dfd13cb0.jpg", "hash": "small_PL_S2_1_stelki_BALANS_2_06dfd13cb0", "mime": "image/jpeg", "name": "small_PL.S2.1 стельки БАЛАНС-2.jpg", "path": null, "size": 10.76, "width": 500, "height": 500, "sizeInBytes": 10764}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PL_S2_1_stelki_BALANS_2_06dfd13cb0.jpg", "hash": "medium_PL_S2_1_stelki_BALANS_2_06dfd13cb0", "mime": "image/jpeg", "name": "medium_PL.S2.1 стельки БАЛАНС-2.jpg", "path": null, "size": 22.26, "width": 750, "height": 750, "sizeInBytes": 22264}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PL_S2_1_stelki_BALANS_2_06dfd13cb0.jpg", "hash": "thumbnail_PL_S2_1_stelki_BALANS_2_06dfd13cb0", "mime": "image/jpeg", "name": "thumbnail_PL.S2.1 стельки БАЛАНС-2.jpg", "path": null, "size": 2.09, "width": 156, "height": 156, "sizeInBytes": 2086}}	PL_S2_1_stelki_BALANS_2_06dfd13cb0	.jpg	image/jpeg	114.83	/uploads/PL_S2_1_stelki_BALANS_2_06dfd13cb0.jpg	\N	local	\N	/	2025-10-25 15:28:46.399	2025-10-25 15:28:46.399	2025-10-25 15:28:46.399	1	1	\N
71	m3x1bfba3kp59ejr3gtebk2l	PL.S2.1 стельки БАЛАНС-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PL_S2_1_stelki_BALANS_1_588f29a355.jpg", "hash": "large_PL_S2_1_stelki_BALANS_1_588f29a355", "mime": "image/jpeg", "name": "large_PL.S2.1 стельки БАЛАНС-1.jpg", "path": null, "size": 64.83, "width": 1000, "height": 1000, "sizeInBytes": 64829}, "small": {"ext": ".jpg", "url": "/uploads/small_PL_S2_1_stelki_BALANS_1_588f29a355.jpg", "hash": "small_PL_S2_1_stelki_BALANS_1_588f29a355", "mime": "image/jpeg", "name": "small_PL.S2.1 стельки БАЛАНС-1.jpg", "path": null, "size": 19.69, "width": 500, "height": 500, "sizeInBytes": 19689}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PL_S2_1_stelki_BALANS_1_588f29a355.jpg", "hash": "medium_PL_S2_1_stelki_BALANS_1_588f29a355", "mime": "image/jpeg", "name": "medium_PL.S2.1 стельки БАЛАНС-1.jpg", "path": null, "size": 39.92, "width": 750, "height": 750, "sizeInBytes": 39919}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PL_S2_1_stelki_BALANS_1_588f29a355.jpg", "hash": "thumbnail_PL_S2_1_stelki_BALANS_1_588f29a355", "mime": "image/jpeg", "name": "thumbnail_PL.S2.1 стельки БАЛАНС-1.jpg", "path": null, "size": 3.15, "width": 156, "height": 156, "sizeInBytes": 3151}}	PL_S2_1_stelki_BALANS_1_588f29a355	.jpg	image/jpeg	210.55	/uploads/PL_S2_1_stelki_BALANS_1_588f29a355.jpg	\N	local	\N	/	2025-10-25 15:28:47.628	2025-10-25 15:28:47.628	2025-10-25 15:28:47.629	1	1	\N
72	cg6rdgkcha7ooo8pkdla8fwr	PL.S2.1 стельки БАЛАНС-5.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PL_S2_1_stelki_BALANS_5_ea3b21cf59.jpg", "hash": "large_PL_S2_1_stelki_BALANS_5_ea3b21cf59", "mime": "image/jpeg", "name": "large_PL.S2.1 стельки БАЛАНС-5.jpg", "path": null, "size": 24.74, "width": 1000, "height": 1000, "sizeInBytes": 24739}, "small": {"ext": ".jpg", "url": "/uploads/small_PL_S2_1_stelki_BALANS_5_ea3b21cf59.jpg", "hash": "small_PL_S2_1_stelki_BALANS_5_ea3b21cf59", "mime": "image/jpeg", "name": "small_PL.S2.1 стельки БАЛАНС-5.jpg", "path": null, "size": 7.88, "width": 500, "height": 500, "sizeInBytes": 7881}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PL_S2_1_stelki_BALANS_5_ea3b21cf59.jpg", "hash": "medium_PL_S2_1_stelki_BALANS_5_ea3b21cf59", "mime": "image/jpeg", "name": "medium_PL.S2.1 стельки БАЛАНС-5.jpg", "path": null, "size": 15.58, "width": 750, "height": 750, "sizeInBytes": 15582}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PL_S2_1_stelki_BALANS_5_ea3b21cf59.jpg", "hash": "thumbnail_PL_S2_1_stelki_BALANS_5_ea3b21cf59", "mime": "image/jpeg", "name": "thumbnail_PL.S2.1 стельки БАЛАНС-5.jpg", "path": null, "size": 1.54, "width": 156, "height": 156, "sizeInBytes": 1537}}	PL_S2_1_stelki_BALANS_5_ea3b21cf59	.jpg	image/jpeg	76.73	/uploads/PL_S2_1_stelki_BALANS_5_ea3b21cf59.jpg	\N	local	\N	/	2025-10-25 15:28:47.663	2025-10-25 15:28:47.663	2025-10-25 15:28:47.664	1	1	\N
73	njkmpo106wwt6srt7pjpuuwl	PL.S2.1 стельки БАЛАНС-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PL_S2_1_stelki_BALANS_3_9257effb37.jpg", "hash": "large_PL_S2_1_stelki_BALANS_3_9257effb37", "mime": "image/jpeg", "name": "large_PL.S2.1 стельки БАЛАНС-3.jpg", "path": null, "size": 75.12, "width": 1000, "height": 1000, "sizeInBytes": 75124}, "small": {"ext": ".jpg", "url": "/uploads/small_PL_S2_1_stelki_BALANS_3_9257effb37.jpg", "hash": "small_PL_S2_1_stelki_BALANS_3_9257effb37", "mime": "image/jpeg", "name": "small_PL.S2.1 стельки БАЛАНС-3.jpg", "path": null, "size": 21.56, "width": 500, "height": 500, "sizeInBytes": 21556}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PL_S2_1_stelki_BALANS_3_9257effb37.jpg", "hash": "medium_PL_S2_1_stelki_BALANS_3_9257effb37", "mime": "image/jpeg", "name": "medium_PL.S2.1 стельки БАЛАНС-3.jpg", "path": null, "size": 45.36, "width": 750, "height": 750, "sizeInBytes": 45357}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PL_S2_1_stelki_BALANS_3_9257effb37.jpg", "hash": "thumbnail_PL_S2_1_stelki_BALANS_3_9257effb37", "mime": "image/jpeg", "name": "thumbnail_PL.S2.1 стельки БАЛАНС-3.jpg", "path": null, "size": 2.81, "width": 156, "height": 156, "sizeInBytes": 2808}}	PL_S2_1_stelki_BALANS_3_9257effb37	.jpg	image/jpeg	251.04	/uploads/PL_S2_1_stelki_BALANS_3_9257effb37.jpg	\N	local	\N	/	2025-10-25 15:28:47.859	2025-10-25 15:28:47.859	2025-10-25 15:28:47.86	1	1	\N
74	t9cpqdgxtz1stlx06sfmvkhi	PT.S2.1 стельки БРИЗ-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_1_stelki_BRIZ_3_1c012b92c2.jpg", "hash": "large_PT_S2_1_stelki_BRIZ_3_1c012b92c2", "mime": "image/jpeg", "name": "large_PT.S2.1 стельки БРИЗ-3.jpg", "path": null, "size": 87.12, "width": 1000, "height": 1000, "sizeInBytes": 87120}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_1_stelki_BRIZ_3_1c012b92c2.jpg", "hash": "small_PT_S2_1_stelki_BRIZ_3_1c012b92c2", "mime": "image/jpeg", "name": "small_PT.S2.1 стельки БРИЗ-3.jpg", "path": null, "size": 18.57, "width": 500, "height": 500, "sizeInBytes": 18569}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_1_stelki_BRIZ_3_1c012b92c2.jpg", "hash": "medium_PT_S2_1_stelki_BRIZ_3_1c012b92c2", "mime": "image/jpeg", "name": "medium_PT.S2.1 стельки БРИЗ-3.jpg", "path": null, "size": 46.66, "width": 750, "height": 750, "sizeInBytes": 46655}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_1_stelki_BRIZ_3_1c012b92c2.jpg", "hash": "thumbnail_PT_S2_1_stelki_BRIZ_3_1c012b92c2", "mime": "image/jpeg", "name": "thumbnail_PT.S2.1 стельки БРИЗ-3.jpg", "path": null, "size": 2.65, "width": 156, "height": 156, "sizeInBytes": 2646}}	PT_S2_1_stelki_BRIZ_3_1c012b92c2	.jpg	image/jpeg	314.88	/uploads/PT_S2_1_stelki_BRIZ_3_1c012b92c2.jpg	\N	local	\N	/	2025-10-25 15:30:41.025	2025-10-25 15:30:41.025	2025-10-25 15:30:41.025	1	1	\N
75	now21vcn6m1rsa8zktatw6w1	PT.S2.1 стельки БРИЗ-5.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_1_stelki_BRIZ_5_d2f8280376.jpg", "hash": "large_PT_S2_1_stelki_BRIZ_5_d2f8280376", "mime": "image/jpeg", "name": "large_PT.S2.1 стельки БРИЗ-5.jpg", "path": null, "size": 34.21, "width": 1000, "height": 1000, "sizeInBytes": 34213}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_1_stelki_BRIZ_5_d2f8280376.jpg", "hash": "small_PT_S2_1_stelki_BRIZ_5_d2f8280376", "mime": "image/jpeg", "name": "small_PT.S2.1 стельки БРИЗ-5.jpg", "path": null, "size": 10, "width": 500, "height": 500, "sizeInBytes": 9997}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_1_stelki_BRIZ_5_d2f8280376.jpg", "hash": "medium_PT_S2_1_stelki_BRIZ_5_d2f8280376", "mime": "image/jpeg", "name": "medium_PT.S2.1 стельки БРИЗ-5.jpg", "path": null, "size": 20.22, "width": 750, "height": 750, "sizeInBytes": 20219}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_1_stelki_BRIZ_5_d2f8280376.jpg", "hash": "thumbnail_PT_S2_1_stelki_BRIZ_5_d2f8280376", "mime": "image/jpeg", "name": "thumbnail_PT.S2.1 стельки БРИЗ-5.jpg", "path": null, "size": 1.82, "width": 156, "height": 156, "sizeInBytes": 1821}}	PT_S2_1_stelki_BRIZ_5_d2f8280376	.jpg	image/jpeg	125.21	/uploads/PT_S2_1_stelki_BRIZ_5_d2f8280376.jpg	\N	local	\N	/	2025-10-25 15:30:41.996	2025-10-25 15:30:41.996	2025-10-25 15:30:41.996	1	1	\N
76	f7yadaqfbo4sa43acpvh4gyx	PT.S2.1 стельки БРИЗ-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_1_stelki_BRIZ_2_afba25591d.jpg", "hash": "large_PT_S2_1_stelki_BRIZ_2_afba25591d", "mime": "image/jpeg", "name": "large_PT.S2.1 стельки БРИЗ-2.jpg", "path": null, "size": 35.85, "width": 1000, "height": 1000, "sizeInBytes": 35850}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_1_stelki_BRIZ_2_afba25591d.jpg", "hash": "small_PT_S2_1_stelki_BRIZ_2_afba25591d", "mime": "image/jpeg", "name": "small_PT.S2.1 стельки БРИЗ-2.jpg", "path": null, "size": 10.68, "width": 500, "height": 500, "sizeInBytes": 10676}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_1_stelki_BRIZ_2_afba25591d.jpg", "hash": "medium_PT_S2_1_stelki_BRIZ_2_afba25591d", "mime": "image/jpeg", "name": "medium_PT.S2.1 стельки БРИЗ-2.jpg", "path": null, "size": 21.69, "width": 750, "height": 750, "sizeInBytes": 21689}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_1_stelki_BRIZ_2_afba25591d.jpg", "hash": "thumbnail_PT_S2_1_stelki_BRIZ_2_afba25591d", "mime": "image/jpeg", "name": "thumbnail_PT.S2.1 стельки БРИЗ-2.jpg", "path": null, "size": 1.93, "width": 156, "height": 156, "sizeInBytes": 1933}}	PT_S2_1_stelki_BRIZ_2_afba25591d	.jpg	image/jpeg	113.66	/uploads/PT_S2_1_stelki_BRIZ_2_afba25591d.jpg	\N	local	\N	/	2025-10-25 15:30:43.006	2025-10-25 15:30:43.006	2025-10-25 15:30:43.007	1	1	\N
89	f808okw7adjtdo57z2odh855	PA.S1.1 стельки СПОРТ-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PA_S1_1_stelki_SPORT_2_ae61d4719b.jpg", "hash": "large_PA_S1_1_stelki_SPORT_2_ae61d4719b", "mime": "image/jpeg", "name": "large_PA.S1.1 стельки СПОРТ-2.jpg", "path": null, "size": 51.22, "width": 1000, "height": 1000, "sizeInBytes": 51218}, "small": {"ext": ".jpg", "url": "/uploads/small_PA_S1_1_stelki_SPORT_2_ae61d4719b.jpg", "hash": "small_PA_S1_1_stelki_SPORT_2_ae61d4719b", "mime": "image/jpeg", "name": "small_PA.S1.1 стельки СПОРТ-2.jpg", "path": null, "size": 16.23, "width": 500, "height": 500, "sizeInBytes": 16231}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PA_S1_1_stelki_SPORT_2_ae61d4719b.jpg", "hash": "medium_PA_S1_1_stelki_SPORT_2_ae61d4719b", "mime": "image/jpeg", "name": "medium_PA.S1.1 стельки СПОРТ-2.jpg", "path": null, "size": 31.73, "width": 750, "height": 750, "sizeInBytes": 31727}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PA_S1_1_stelki_SPORT_2_ae61d4719b.jpg", "hash": "thumbnail_PA_S1_1_stelki_SPORT_2_ae61d4719b", "mime": "image/jpeg", "name": "thumbnail_PA.S1.1 стельки СПОРТ-2.jpg", "path": null, "size": 2.81, "width": 156, "height": 156, "sizeInBytes": 2809}}	PA_S1_1_stelki_SPORT_2_ae61d4719b	.jpg	image/jpeg	172.23	/uploads/PA_S1_1_stelki_SPORT_2_ae61d4719b.jpg	\N	local	\N	/	2025-10-25 15:37:18.007	2025-10-25 15:37:18.007	2025-10-25 15:37:18.008	1	1	\N
77	zgyuhuik54o04rq8zitarcuf	PT.S2.1 стельки БРИЗ-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_1_stelki_BRIZ_1_89933ae558.jpg", "hash": "large_PT_S2_1_stelki_BRIZ_1_89933ae558", "mime": "image/jpeg", "name": "large_PT.S2.1 стельки БРИЗ-1.jpg", "path": null, "size": 82.47, "width": 1000, "height": 1000, "sizeInBytes": 82474}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_1_stelki_BRIZ_1_89933ae558.jpg", "hash": "small_PT_S2_1_stelki_BRIZ_1_89933ae558", "mime": "image/jpeg", "name": "small_PT.S2.1 стельки БРИЗ-1.jpg", "path": null, "size": 19.99, "width": 500, "height": 500, "sizeInBytes": 19993}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_1_stelki_BRIZ_1_89933ae558.jpg", "hash": "medium_PT_S2_1_stelki_BRIZ_1_89933ae558", "mime": "image/jpeg", "name": "medium_PT.S2.1 стельки БРИЗ-1.jpg", "path": null, "size": 46.38, "width": 750, "height": 750, "sizeInBytes": 46380}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_1_stelki_BRIZ_1_89933ae558.jpg", "hash": "thumbnail_PT_S2_1_stelki_BRIZ_1_89933ae558", "mime": "image/jpeg", "name": "thumbnail_PT.S2.1 стельки БРИЗ-1.jpg", "path": null, "size": 2.98, "width": 156, "height": 156, "sizeInBytes": 2978}}	PT_S2_1_stelki_BRIZ_1_89933ae558	.jpg	image/jpeg	274.63	/uploads/PT_S2_1_stelki_BRIZ_1_89933ae558.jpg	\N	local	\N	/	2025-10-25 15:30:44.194	2025-10-25 15:30:44.194	2025-10-25 15:30:44.194	1	1	\N
78	yxfpjg9ne9m4jwqjc2b1utj9	PT.S2.1 стельки БРИЗ-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_1_stelki_BRIZ_4_aecec91d1c.jpg", "hash": "large_PT_S2_1_stelki_BRIZ_4_aecec91d1c", "mime": "image/jpeg", "name": "large_PT.S2.1 стельки БРИЗ-4.jpg", "path": null, "size": 89.2, "width": 1000, "height": 1000, "sizeInBytes": 89202}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_1_stelki_BRIZ_4_aecec91d1c.jpg", "hash": "small_PT_S2_1_stelki_BRIZ_4_aecec91d1c", "mime": "image/jpeg", "name": "small_PT.S2.1 стельки БРИЗ-4.jpg", "path": null, "size": 23.04, "width": 500, "height": 500, "sizeInBytes": 23040}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_1_stelki_BRIZ_4_aecec91d1c.jpg", "hash": "medium_PT_S2_1_stelki_BRIZ_4_aecec91d1c", "mime": "image/jpeg", "name": "medium_PT.S2.1 стельки БРИЗ-4.jpg", "path": null, "size": 51.36, "width": 750, "height": 750, "sizeInBytes": 51364}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_1_stelki_BRIZ_4_aecec91d1c.jpg", "hash": "thumbnail_PT_S2_1_stelki_BRIZ_4_aecec91d1c", "mime": "image/jpeg", "name": "thumbnail_PT.S2.1 стельки БРИЗ-4.jpg", "path": null, "size": 3.15, "width": 156, "height": 156, "sizeInBytes": 3147}}	PT_S2_1_stelki_BRIZ_4_aecec91d1c	.jpg	image/jpeg	295.23	/uploads/PT_S2_1_stelki_BRIZ_4_aecec91d1c.jpg	\N	local	\N	/	2025-10-25 15:30:44.273	2025-10-25 15:30:44.273	2025-10-25 15:30:44.273	1	1	\N
79	za2kqwtikbl1gsizoj8rvbvm	PT.S2.1 стельки БРИЗ-7.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PT_S2_1_stelki_BRIZ_7_8c09a4f7af.jpg", "hash": "large_PT_S2_1_stelki_BRIZ_7_8c09a4f7af", "mime": "image/jpeg", "name": "large_PT.S2.1 стельки БРИЗ-7.jpg", "path": null, "size": 60.3, "width": 1000, "height": 1000, "sizeInBytes": 60299}, "small": {"ext": ".jpg", "url": "/uploads/small_PT_S2_1_stelki_BRIZ_7_8c09a4f7af.jpg", "hash": "small_PT_S2_1_stelki_BRIZ_7_8c09a4f7af", "mime": "image/jpeg", "name": "small_PT.S2.1 стельки БРИЗ-7.jpg", "path": null, "size": 20.08, "width": 500, "height": 500, "sizeInBytes": 20075}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PT_S2_1_stelki_BRIZ_7_8c09a4f7af.jpg", "hash": "medium_PT_S2_1_stelki_BRIZ_7_8c09a4f7af", "mime": "image/jpeg", "name": "medium_PT.S2.1 стельки БРИЗ-7.jpg", "path": null, "size": 38.34, "width": 750, "height": 750, "sizeInBytes": 38335}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PT_S2_1_stelki_BRIZ_7_8c09a4f7af.jpg", "hash": "thumbnail_PT_S2_1_stelki_BRIZ_7_8c09a4f7af", "mime": "image/jpeg", "name": "thumbnail_PT.S2.1 стельки БРИЗ-7.jpg", "path": null, "size": 3.18, "width": 156, "height": 156, "sizeInBytes": 3178}}	PT_S2_1_stelki_BRIZ_7_8c09a4f7af	.jpg	image/jpeg	162.04	/uploads/PT_S2_1_stelki_BRIZ_7_8c09a4f7af.jpg	\N	local	\N	/	2025-10-25 15:30:44.584	2025-10-25 15:30:44.584	2025-10-25 15:30:44.584	1	1	\N
80	x1gz6g16sdyufish9tigxdkw	QL.S2.1 полустельки ЭФФЕКТ-5.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S2_1_polustelki_EFFEKT_5_7c0389509e.jpg", "hash": "large_QL_S2_1_polustelki_EFFEKT_5_7c0389509e", "mime": "image/jpeg", "name": "large_QL.S2.1 полустельки ЭФФЕКТ-5.jpg", "path": null, "size": 18.43, "width": 1000, "height": 1000, "sizeInBytes": 18430}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S2_1_polustelki_EFFEKT_5_7c0389509e.jpg", "hash": "small_QL_S2_1_polustelki_EFFEKT_5_7c0389509e", "mime": "image/jpeg", "name": "small_QL.S2.1 полустельки ЭФФЕКТ-5.jpg", "path": null, "size": 6.36, "width": 500, "height": 500, "sizeInBytes": 6360}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S2_1_polustelki_EFFEKT_5_7c0389509e.jpg", "hash": "medium_QL_S2_1_polustelki_EFFEKT_5_7c0389509e", "mime": "image/jpeg", "name": "medium_QL.S2.1 полустельки ЭФФЕКТ-5.jpg", "path": null, "size": 12.06, "width": 750, "height": 750, "sizeInBytes": 12062}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S2_1_polustelki_EFFEKT_5_7c0389509e.jpg", "hash": "thumbnail_QL_S2_1_polustelki_EFFEKT_5_7c0389509e", "mime": "image/jpeg", "name": "thumbnail_QL.S2.1 полустельки ЭФФЕКТ-5.jpg", "path": null, "size": 1.28, "width": 156, "height": 156, "sizeInBytes": 1278}}	QL_S2_1_polustelki_EFFEKT_5_7c0389509e	.jpg	image/jpeg	54.31	/uploads/QL_S2_1_polustelki_EFFEKT_5_7c0389509e.jpg	\N	local	\N	/	2025-10-25 15:35:30.484	2025-10-25 15:35:30.484	2025-10-25 15:35:30.485	1	1	\N
81	kkgkaffer8a3rsvsh607evw1	QL.S2.1 полустельки ЭФФЕКТ-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S2_1_polustelki_EFFEKT_4_cadec429dd.jpg", "hash": "large_QL_S2_1_polustelki_EFFEKT_4_cadec429dd", "mime": "image/jpeg", "name": "large_QL.S2.1 полустельки ЭФФЕКТ-4.jpg", "path": null, "size": 29.53, "width": 1000, "height": 1000, "sizeInBytes": 29525}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S2_1_polustelki_EFFEKT_4_cadec429dd.jpg", "hash": "small_QL_S2_1_polustelki_EFFEKT_4_cadec429dd", "mime": "image/jpeg", "name": "small_QL.S2.1 полустельки ЭФФЕКТ-4.jpg", "path": null, "size": 9.61, "width": 500, "height": 500, "sizeInBytes": 9610}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S2_1_polustelki_EFFEKT_4_cadec429dd.jpg", "hash": "medium_QL_S2_1_polustelki_EFFEKT_4_cadec429dd", "mime": "image/jpeg", "name": "medium_QL.S2.1 полустельки ЭФФЕКТ-4.jpg", "path": null, "size": 18.7, "width": 750, "height": 750, "sizeInBytes": 18703}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S2_1_polustelki_EFFEKT_4_cadec429dd.jpg", "hash": "thumbnail_QL_S2_1_polustelki_EFFEKT_4_cadec429dd", "mime": "image/jpeg", "name": "thumbnail_QL.S2.1 полустельки ЭФФЕКТ-4.jpg", "path": null, "size": 1.63, "width": 156, "height": 156, "sizeInBytes": 1632}}	QL_S2_1_polustelki_EFFEKT_4_cadec429dd	.jpg	image/jpeg	90.33	/uploads/QL_S2_1_polustelki_EFFEKT_4_cadec429dd.jpg	\N	local	\N	/	2025-10-25 15:35:31.471	2025-10-25 15:35:31.471	2025-10-25 15:35:31.471	1	1	\N
82	oruyswhs5msowsx3z2427588	QL.S2.1 полустельки ЭФФЕКТ-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S2_1_polustelki_EFFEKT_3_5fc50649a8.jpg", "hash": "large_QL_S2_1_polustelki_EFFEKT_3_5fc50649a8", "mime": "image/jpeg", "name": "large_QL.S2.1 полустельки ЭФФЕКТ-3.jpg", "path": null, "size": 34.16, "width": 1000, "height": 1000, "sizeInBytes": 34162}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S2_1_polustelki_EFFEKT_3_5fc50649a8.jpg", "hash": "small_QL_S2_1_polustelki_EFFEKT_3_5fc50649a8", "mime": "image/jpeg", "name": "small_QL.S2.1 полустельки ЭФФЕКТ-3.jpg", "path": null, "size": 11.34, "width": 500, "height": 500, "sizeInBytes": 11335}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S2_1_polustelki_EFFEKT_3_5fc50649a8.jpg", "hash": "medium_QL_S2_1_polustelki_EFFEKT_3_5fc50649a8", "mime": "image/jpeg", "name": "medium_QL.S2.1 полустельки ЭФФЕКТ-3.jpg", "path": null, "size": 21.4, "width": 750, "height": 750, "sizeInBytes": 21399}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S2_1_polustelki_EFFEKT_3_5fc50649a8.jpg", "hash": "thumbnail_QL_S2_1_polustelki_EFFEKT_3_5fc50649a8", "mime": "image/jpeg", "name": "thumbnail_QL.S2.1 полустельки ЭФФЕКТ-3.jpg", "path": null, "size": 2.3, "width": 156, "height": 156, "sizeInBytes": 2298}}	QL_S2_1_polustelki_EFFEKT_3_5fc50649a8	.jpg	image/jpeg	107.20	/uploads/QL_S2_1_polustelki_EFFEKT_3_5fc50649a8.jpg	\N	local	\N	/	2025-10-25 15:35:32.114	2025-10-25 15:35:32.114	2025-10-25 15:35:32.114	1	1	\N
83	imhmt85njwhff50gllom4aa1	QL.S2.1 полустельки ЭФФЕКТ-2.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S2_1_polustelki_EFFEKT_2_5c2e214003.jpg", "hash": "large_QL_S2_1_polustelki_EFFEKT_2_5c2e214003", "mime": "image/jpeg", "name": "large_QL.S2.1 полустельки ЭФФЕКТ-2.jpg", "path": null, "size": 38.01, "width": 1000, "height": 1000, "sizeInBytes": 38006}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S2_1_polustelki_EFFEKT_2_5c2e214003.jpg", "hash": "small_QL_S2_1_polustelki_EFFEKT_2_5c2e214003", "mime": "image/jpeg", "name": "small_QL.S2.1 полустельки ЭФФЕКТ-2.jpg", "path": null, "size": 12.23, "width": 500, "height": 500, "sizeInBytes": 12233}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S2_1_polustelki_EFFEKT_2_5c2e214003.jpg", "hash": "medium_QL_S2_1_polustelki_EFFEKT_2_5c2e214003", "mime": "image/jpeg", "name": "medium_QL.S2.1 полустельки ЭФФЕКТ-2.jpg", "path": null, "size": 24.08, "width": 750, "height": 750, "sizeInBytes": 24082}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S2_1_polustelki_EFFEKT_2_5c2e214003.jpg", "hash": "thumbnail_QL_S2_1_polustelki_EFFEKT_2_5c2e214003", "mime": "image/jpeg", "name": "thumbnail_QL.S2.1 полустельки ЭФФЕКТ-2.jpg", "path": null, "size": 2.03, "width": 156, "height": 156, "sizeInBytes": 2028}}	QL_S2_1_polustelki_EFFEKT_2_5c2e214003	.jpg	image/jpeg	117.55	/uploads/QL_S2_1_polustelki_EFFEKT_2_5c2e214003.jpg	\N	local	\N	/	2025-10-25 15:35:32.539	2025-10-25 15:35:32.539	2025-10-25 15:35:32.539	1	1	\N
84	dwygjq2swziztbv5jlug75cp	QL.S2.1 полустельки ЭФФЕКТ-6.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S2_1_polustelki_EFFEKT_6_235c9d3b39.jpg", "hash": "large_QL_S2_1_polustelki_EFFEKT_6_235c9d3b39", "mime": "image/jpeg", "name": "large_QL.S2.1 полустельки ЭФФЕКТ-6.jpg", "path": null, "size": 66.95, "width": 1000, "height": 1000, "sizeInBytes": 66952}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S2_1_polustelki_EFFEKT_6_235c9d3b39.jpg", "hash": "small_QL_S2_1_polustelki_EFFEKT_6_235c9d3b39", "mime": "image/jpeg", "name": "small_QL.S2.1 полустельки ЭФФЕКТ-6.jpg", "path": null, "size": 21.77, "width": 500, "height": 500, "sizeInBytes": 21769}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S2_1_polustelki_EFFEKT_6_235c9d3b39.jpg", "hash": "medium_QL_S2_1_polustelki_EFFEKT_6_235c9d3b39", "mime": "image/jpeg", "name": "medium_QL.S2.1 полустельки ЭФФЕКТ-6.jpg", "path": null, "size": 42.71, "width": 750, "height": 750, "sizeInBytes": 42708}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S2_1_polustelki_EFFEKT_6_235c9d3b39.jpg", "hash": "thumbnail_QL_S2_1_polustelki_EFFEKT_6_235c9d3b39", "mime": "image/jpeg", "name": "thumbnail_QL.S2.1 полустельки ЭФФЕКТ-6.jpg", "path": null, "size": 3.03, "width": 156, "height": 156, "sizeInBytes": 3027}}	QL_S2_1_polustelki_EFFEKT_6_235c9d3b39	.jpg	image/jpeg	182.64	/uploads/QL_S2_1_polustelki_EFFEKT_6_235c9d3b39.jpg	\N	local	\N	/	2025-10-25 15:35:32.986	2025-10-25 15:35:32.986	2025-10-25 15:35:32.987	1	1	\N
85	wjlymhimqopmra8089wkrsmy	QL.S2.1 полустельки ЭФФЕКТ-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1.jpg", "hash": "large_QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1", "mime": "image/jpeg", "name": "large_QL.S2.1 полустельки ЭФФЕКТ-1.jpg", "path": null, "size": 44.84, "width": 1000, "height": 1000, "sizeInBytes": 44835}, "small": {"ext": ".jpg", "url": "/uploads/small_QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1.jpg", "hash": "small_QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1", "mime": "image/jpeg", "name": "small_QL.S2.1 полустельки ЭФФЕКТ-1.jpg", "path": null, "size": 15.19, "width": 500, "height": 500, "sizeInBytes": 15191}, "medium": {"ext": ".jpg", "url": "/uploads/medium_QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1.jpg", "hash": "medium_QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1", "mime": "image/jpeg", "name": "medium_QL.S2.1 полустельки ЭФФЕКТ-1.jpg", "path": null, "size": 28.65, "width": 750, "height": 750, "sizeInBytes": 28652}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1.jpg", "hash": "thumbnail_QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1", "mime": "image/jpeg", "name": "thumbnail_QL.S2.1 полустельки ЭФФЕКТ-1.jpg", "path": null, "size": 2.45, "width": 156, "height": 156, "sizeInBytes": 2453}}	QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1	.jpg	image/jpeg	130.96	/uploads/QL_S2_1_polustelki_EFFEKT_1_2d8fc934a1.jpg	\N	local	\N	/	2025-10-25 15:35:33.048	2025-10-25 15:35:33.048	2025-10-25 15:35:33.048	1	1	\N
86	mqjgc1zb5imaqjubtn8l041u	PA.S1.1 стельки СПОРТ-4.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PA_S1_1_stelki_SPORT_4_133a655448.jpg", "hash": "large_PA_S1_1_stelki_SPORT_4_133a655448", "mime": "image/jpeg", "name": "large_PA.S1.1 стельки СПОРТ-4.jpg", "path": null, "size": 27.68, "width": 1000, "height": 1000, "sizeInBytes": 27679}, "small": {"ext": ".jpg", "url": "/uploads/small_PA_S1_1_stelki_SPORT_4_133a655448.jpg", "hash": "small_PA_S1_1_stelki_SPORT_4_133a655448", "mime": "image/jpeg", "name": "small_PA.S1.1 стельки СПОРТ-4.jpg", "path": null, "size": 8.67, "width": 500, "height": 500, "sizeInBytes": 8673}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PA_S1_1_stelki_SPORT_4_133a655448.jpg", "hash": "medium_PA_S1_1_stelki_SPORT_4_133a655448", "mime": "image/jpeg", "name": "medium_PA.S1.1 стельки СПОРТ-4.jpg", "path": null, "size": 17.27, "width": 750, "height": 750, "sizeInBytes": 17271}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PA_S1_1_stelki_SPORT_4_133a655448.jpg", "hash": "thumbnail_PA_S1_1_stelki_SPORT_4_133a655448", "mime": "image/jpeg", "name": "thumbnail_PA.S1.1 стельки СПОРТ-4.jpg", "path": null, "size": 1.64, "width": 156, "height": 156, "sizeInBytes": 1636}}	PA_S1_1_stelki_SPORT_4_133a655448	.jpg	image/jpeg	89.20	/uploads/PA_S1_1_stelki_SPORT_4_133a655448.jpg	\N	local	\N	/	2025-10-25 15:37:16.865	2025-10-25 15:37:16.865	2025-10-25 15:37:16.866	1	1	\N
87	zml2c7ls05unlnw17bp3q2jd	PA.S1.1 стельки СПОРТ-3.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PA_S1_1_stelki_SPORT_3_c3a0d01c48.jpg", "hash": "large_PA_S1_1_stelki_SPORT_3_c3a0d01c48", "mime": "image/jpeg", "name": "large_PA.S1.1 стельки СПОРТ-3.jpg", "path": null, "size": 36.69, "width": 1000, "height": 1000, "sizeInBytes": 36689}, "small": {"ext": ".jpg", "url": "/uploads/small_PA_S1_1_stelki_SPORT_3_c3a0d01c48.jpg", "hash": "small_PA_S1_1_stelki_SPORT_3_c3a0d01c48", "mime": "image/jpeg", "name": "small_PA.S1.1 стельки СПОРТ-3.jpg", "path": null, "size": 11.8, "width": 500, "height": 500, "sizeInBytes": 11795}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PA_S1_1_stelki_SPORT_3_c3a0d01c48.jpg", "hash": "medium_PA_S1_1_stelki_SPORT_3_c3a0d01c48", "mime": "image/jpeg", "name": "medium_PA.S1.1 стельки СПОРТ-3.jpg", "path": null, "size": 22.71, "width": 750, "height": 750, "sizeInBytes": 22709}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PA_S1_1_stelki_SPORT_3_c3a0d01c48.jpg", "hash": "thumbnail_PA_S1_1_stelki_SPORT_3_c3a0d01c48", "mime": "image/jpeg", "name": "thumbnail_PA.S1.1 стельки СПОРТ-3.jpg", "path": null, "size": 2.45, "width": 156, "height": 156, "sizeInBytes": 2450}}	PA_S1_1_stelki_SPORT_3_c3a0d01c48	.jpg	image/jpeg	122.23	/uploads/PA_S1_1_stelki_SPORT_3_c3a0d01c48.jpg	\N	local	\N	/	2025-10-25 15:37:17.531	2025-10-25 15:37:17.531	2025-10-25 15:37:17.532	1	1	\N
88	m4j30vn2lglvpurkpuqz8v4e	PA.S1.1 стельки СПОРТ-1.jpg	\N	\N	2000	2000	{"large": {"ext": ".jpg", "url": "/uploads/large_PA_S1_1_stelki_SPORT_1_2443d96640.jpg", "hash": "large_PA_S1_1_stelki_SPORT_1_2443d96640", "mime": "image/jpeg", "name": "large_PA.S1.1 стельки СПОРТ-1.jpg", "path": null, "size": 42.26, "width": 1000, "height": 1000, "sizeInBytes": 42261}, "small": {"ext": ".jpg", "url": "/uploads/small_PA_S1_1_stelki_SPORT_1_2443d96640.jpg", "hash": "small_PA_S1_1_stelki_SPORT_1_2443d96640", "mime": "image/jpeg", "name": "small_PA.S1.1 стельки СПОРТ-1.jpg", "path": null, "size": 13.56, "width": 500, "height": 500, "sizeInBytes": 13564}, "medium": {"ext": ".jpg", "url": "/uploads/medium_PA_S1_1_stelki_SPORT_1_2443d96640.jpg", "hash": "medium_PA_S1_1_stelki_SPORT_1_2443d96640", "mime": "image/jpeg", "name": "medium_PA.S1.1 стельки СПОРТ-1.jpg", "path": null, "size": 26.25, "width": 750, "height": 750, "sizeInBytes": 26249}, "thumbnail": {"ext": ".jpg", "url": "/uploads/thumbnail_PA_S1_1_stelki_SPORT_1_2443d96640.jpg", "hash": "thumbnail_PA_S1_1_stelki_SPORT_1_2443d96640", "mime": "image/jpeg", "name": "thumbnail_PA.S1.1 стельки СПОРТ-1.jpg", "path": null, "size": 2.71, "width": 156, "height": 156, "sizeInBytes": 2706}}	PA_S1_1_stelki_SPORT_1_2443d96640	.jpg	image/jpeg	134.23	/uploads/PA_S1_1_stelki_SPORT_1_2443d96640.jpg	\N	local	\N	/	2025-10-25 15:37:17.964	2025-10-25 15:38:51.845	2025-10-25 15:37:17.965	1	1	\N
92	bicgylx4n766xwb472vtxo7h	чулки антиэмболические 1 класс_ T1.AG.1.docx.pdf	\N	\N	\N	\N	\N	chulki_antiembolicheskie_1_klass_T1_AG_1_docx_8ff7a3784f	.pdf	application/pdf	218.35	/uploads/chulki_antiembolicheskie_1_klass_T1_AG_1_docx_8ff7a3784f.pdf	\N	local	\N	/	2025-10-27 15:41:44.887	2025-10-27 15:41:44.887	2025-10-27 15:41:44.887	1	1	\N
\.


--
-- Data for Name: files_folder_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.files_folder_lnk (id, file_id, folder_id, file_ord) FROM stdin;
1	1	1	1
2	2	1	2
\.


--
-- Data for Name: files_related_mph; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.files_related_mph (id, file_id, related_id, related_type, field, "order") FROM stdin;
181	38	88	api::product.product	images	1
182	39	88	api::product.product	images	2
183	40	88	api::product.product	images	3
4	2	6	api::category.category	picture	1
184	41	88	api::product.product	images	4
185	38	127	api::product.product	images	1
186	39	127	api::product.product	images	2
8	3	8	api::category.category	picture	1
187	40	127	api::product.product	images	3
188	41	127	api::product.product	images	4
261	40	14	api::category.category	imgUrl	1
262	40	46	api::category.category	imgUrl	1
265	52	16	api::category.category	imgUrl	1
266	52	48	api::category.category	imgUrl	1
291	59	136	api::product.product	images	1
292	57	136	api::product.product	images	2
293	60	136	api::product.product	images	3
294	61	136	api::product.product	images	4
295	62	136	api::product.product	images	5
296	58	136	api::product.product	images	6
297	59	139	api::product.product	images	1
298	57	139	api::product.product	images	2
299	60	139	api::product.product	images	3
300	61	139	api::product.product	images	4
301	62	139	api::product.product	images	5
302	58	139	api::product.product	images	6
315	63	12	api::category.category	imgUrl	1
316	63	49	api::category.category	imgUrl	1
319	71	142	api::product.product	images	1
320	69	142	api::product.product	images	2
321	70	142	api::product.product	images	3
322	72	142	api::product.product	images	4
323	73	142	api::product.product	images	5
324	71	143	api::product.product	images	1
325	69	143	api::product.product	images	2
326	70	143	api::product.product	images	3
327	72	143	api::product.product	images	4
328	73	143	api::product.product	images	5
341	77	26	api::category.category	imgUrl	1
342	77	51	api::category.category	imgUrl	1
366	89	148	api::product.product	images	4
367	88	150	api::product.product	images	1
368	86	150	api::product.product	images	2
369	87	150	api::product.product	images	3
370	89	150	api::product.product	images	4
371	29	24	api::category.category	imgUrl	1
372	29	52	api::category.category	imgUrl	1
373	3	18	api::category.category	imgUrl	1
374	3	53	api::category.category	imgUrl	1
375	19	22	api::category.category	imgUrl	1
376	19	54	api::category.category	imgUrl	1
377	36	36	api::category.category	imgUrl	1
378	36	55	api::category.category	imgUrl	1
379	47	30	api::category.category	imgUrl	1
251	17	36	api::product.product	images	1
252	18	36	api::product.product	images	2
253	19	36	api::product.product	images	3
254	20	36	api::product.product	images	4
255	21	36	api::product.product	images	5
256	17	135	api::product.product	images	1
257	18	135	api::product.product	images	2
258	19	135	api::product.product	images	3
259	20	135	api::product.product	images	4
260	21	135	api::product.product	images	5
380	47	56	api::category.category	imgUrl	1
381	51	34	api::category.category	imgUrl	1
382	51	57	api::category.category	imgUrl	1
383	39	32	api::category.category	imgUrl	1
384	39	58	api::category.category	imgUrl	1
399	3	1	api::product.product	images	1
400	8	1	api::product.product	images	2
401	7	1	api::product.product	images	3
402	6	1	api::product.product	images	4
403	5	1	api::product.product	images	5
404	11	1	api::product.product	images	6
405	3	153	api::product.product	images	1
406	8	153	api::product.product	images	2
407	7	153	api::product.product	images	3
408	6	153	api::product.product	images	4
409	5	153	api::product.product	images	5
410	11	153	api::product.product	images	6
411	54	41	api::category.category	imgUrl	1
412	54	59	api::category.category	imgUrl	1
413	55	38	api::category.category	imgUrl	1
414	55	60	api::category.category	imgUrl	1
143	55	118	api::product.product	images	1
144	54	118	api::product.product	images	2
145	52	118	api::product.product	images	3
146	55	121	api::product.product	images	1
147	54	121	api::product.product	images	2
148	52	121	api::product.product	images	3
189	48	108	api::product.product	images	1
190	49	108	api::product.product	images	2
191	50	108	api::product.product	images	3
192	51	108	api::product.product	images	4
193	48	128	api::product.product	images	1
194	49	128	api::product.product	images	2
155	33	68	api::product.product	images	1
156	35	68	api::product.product	images	2
157	34	68	api::product.product	images	3
158	36	68	api::product.product	images	4
159	37	68	api::product.product	images	5
160	33	123	api::product.product	images	1
161	35	123	api::product.product	images	2
162	34	123	api::product.product	images	3
163	36	123	api::product.product	images	4
164	37	123	api::product.product	images	5
165	31	64	api::product.product	images	1
166	32	64	api::product.product	images	2
167	31	124	api::product.product	images	1
168	32	124	api::product.product	images	2
169	42	96	api::product.product	images	1
170	44	96	api::product.product	images	2
171	43	96	api::product.product	images	3
172	42	125	api::product.product	images	1
173	44	125	api::product.product	images	2
174	43	125	api::product.product	images	3
175	45	102	api::product.product	images	1
176	47	102	api::product.product	images	2
177	46	102	api::product.product	images	3
178	45	126	api::product.product	images	1
179	47	126	api::product.product	images	2
180	46	126	api::product.product	images	3
195	50	128	api::product.product	images	3
196	51	128	api::product.product	images	4
207	23	48	api::product.product	images	1
208	26	48	api::product.product	images	2
209	25	48	api::product.product	images	3
210	24	48	api::product.product	images	4
211	22	48	api::product.product	images	5
212	23	130	api::product.product	images	1
213	26	130	api::product.product	images	2
214	25	130	api::product.product	images	3
215	24	130	api::product.product	images	4
216	22	130	api::product.product	images	5
225	27	56	api::product.product	images	1
226	30	56	api::product.product	images	2
227	29	56	api::product.product	images	3
228	28	56	api::product.product	images	4
229	27	132	api::product.product	images	1
230	30	132	api::product.product	images	2
231	29	132	api::product.product	images	3
232	28	132	api::product.product	images	4
241	12	26	api::product.product	images	1
242	13	26	api::product.product	images	2
243	14	26	api::product.product	images	3
244	15	26	api::product.product	images	4
245	16	26	api::product.product	images	5
246	12	134	api::product.product	images	1
247	13	134	api::product.product	images	2
248	14	134	api::product.product	images	3
249	15	134	api::product.product	images	4
250	16	134	api::product.product	images	5
263	28	10	api::category.category	imgUrl	1
264	28	47	api::category.category	imgUrl	1
303	63	140	api::product.product	images	1
304	64	140	api::product.product	images	2
305	65	140	api::product.product	images	3
306	66	140	api::product.product	images	4
307	67	140	api::product.product	images	5
308	68	140	api::product.product	images	6
309	63	141	api::product.product	images	1
310	64	141	api::product.product	images	2
311	65	141	api::product.product	images	3
312	66	141	api::product.product	images	4
313	67	141	api::product.product	images	5
314	68	141	api::product.product	images	6
317	60	28	api::category.category	imgUrl	1
318	60	50	api::category.category	imgUrl	1
329	74	144	api::product.product	images	1
330	75	144	api::product.product	images	2
331	76	144	api::product.product	images	3
332	77	144	api::product.product	images	4
333	78	144	api::product.product	images	5
334	79	144	api::product.product	images	6
335	74	145	api::product.product	images	1
336	75	145	api::product.product	images	2
337	76	145	api::product.product	images	3
338	77	145	api::product.product	images	4
339	78	145	api::product.product	images	5
340	79	145	api::product.product	images	6
343	85	146	api::product.product	images	1
344	80	146	api::product.product	images	2
345	81	146	api::product.product	images	3
346	82	146	api::product.product	images	4
347	83	146	api::product.product	images	5
348	84	146	api::product.product	images	6
349	85	147	api::product.product	images	1
350	80	147	api::product.product	images	2
351	81	147	api::product.product	images	3
352	82	147	api::product.product	images	4
353	83	147	api::product.product	images	5
354	84	147	api::product.product	images	6
363	88	148	api::product.product	images	1
364	86	148	api::product.product	images	2
365	87	148	api::product.product	images	3
428	92	4	api::client-document.client-document	file	1
429	92	5	api::client-document.client-document	file	1
430	92	6	api::client-document.client-document	file	1
431	92	7	api::client-document.client-document	file	1
432	92	1	api::client-document.client-document	file	1
433	92	2	api::client-document.client-document	file	1
\.


--
-- Data for Name: i18n_locale; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.i18n_locale (id, document_id, name, code, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	rseyj3rx9ettg7h0fsrbio5j	English (en)	en	2025-08-22 12:50:23.052	2025-08-22 12:50:23.052	2025-08-22 12:50:23.053	\N	\N	\N
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.products (id, document_id, title, slug, price, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, description) FROM stdin;
36	n0h5a5rcc81n5lqv7b6n0nj7	L1.AG.2 Чулки классика 1КК, черные	l1ag2_culki_klass_cern	\N	2025-10-24 20:22:32.761	2025-10-25 11:49:57.031	\N	1	1	\N	\N
56	kzf07344w41k38vsm5fdwlap	L1.AD.2 Гольфы микрофибра 1КК, черные	lad2_golfy_mikro_cern	\N	2025-10-24 20:50:35.188	2025-10-25 11:42:17.608	\N	1	1	\N	\N
1	k7d2ffm05p03ppx9ng9waffs	Чулки T1.AG.1 антиэмболические	chulki-t1-ag-1	10.00	2025-08-27 16:47:47.183	2025-10-25 16:22:53.077	\N	1	1	\N	Чулки ORTOMEDICA антиэмболические 1 класс, компрессии.\nРазмеры: XS, S, M, L, XL, XXL (предусмотреть закрытие каких-то крайних размеров) \nЦвет: белый молочный \nОписание \n● Антиэмболический трикотаж 1-го класса компрессии (компрессия в области \nлодыжек 18-20 мм.рт.ст.) необходим для профилактики венозных тромбозов и \nвозникновения тромбоэмболии  при любых операциях, при родах, \nдлительном постельном режиме, пребывании в стационаре. Именно поэтому \nего часто называют госпитальным. Его применение обеспечивает улучшение \nкровотока за счет сужения пространства вен, восстановление работы \nклапанов вен нижних конечностей (чтобы кровь двигалась только в одном \nнаправлении). Улучшение кровотока по венам по направлению к сердцу  \nосуществляется за счёт градуированного давления (градуированной \nкомпрессии), оказываемой на мягкие ткани ног и стенки вен. \n● Чулки ОРТОМЕДИКА соответствуют Национальным стандартам РФ по \nклиническим рекомендациям профилактики противоэмболических \nсиндромов ГОСТ Р 56377-2015  \n● Производство противоэмболических чулок ORTOMEDICA сертифицировано по \nISO 13485 \n● Специальная технология вязки обеспечивает высокую \nвоздухопроницаемость и комфорт для кожи. \n● Эластичность и специальная вязка создают нужную компрессию, и \nэффективно препятствует образованию тромбов \n● Эластичные качественные нити позволяют легко надевать изделие и \nкомфортно носить его в течение суток. Чулки хорошо удерживаются на ноге \nво время ходьбы, и не доставляют дискомфорта во время сна \n● Цветовая кодировка размеров в области стопы позволяет быстро подобрать \nнужный размер \n● Открытый мыс, или как его называют врач, смотровое окно на области стопы,  \nпозволяет контролировать состояние вен по цвету кожных покровов, \nуменьшает вероятность возникновения инфекции, облегчает уход за \nпальцами и другие гигиенические процедуры. \n● Изделия производятся из современных, безопасных, гипоаллергенных \nматериалов. Изделия не отбеливаются и не подвергаются окрашиванию.  \n● Возможность ручной обеспечивают многократное использование изделия \n● Гарантированное сохранение компрессионных свойств в течение 30 дней \nежедневного использования. \nПоказания к применению \nПротивоэмболического трикотажа 1-го класса компрессии \n● Любые оперативные вмешательства, даже небольшие. \n● Во время родов и в послеродовом периоде. \n● Пребывание в отделении интенсивной терапии и реанимации. \n● Длительный постельном режим \n● Состояния после инсульта, инфаркта, ожогов, травм  \nСостав 80% полиэстер, 20% эластан
153	k7d2ffm05p03ppx9ng9waffs	Чулки T1.AG.1 антиэмболические	chulki-t1-ag-1	10.00	2025-08-27 16:47:47.183	2025-10-25 16:22:53.077	2025-10-25 16:22:53.103	1	1	\N	Чулки ORTOMEDICA антиэмболические 1 класс, компрессии.\nРазмеры: XS, S, M, L, XL, XXL (предусмотреть закрытие каких-то крайних размеров) \nЦвет: белый молочный \nОписание \n● Антиэмболический трикотаж 1-го класса компрессии (компрессия в области \nлодыжек 18-20 мм.рт.ст.) необходим для профилактики венозных тромбозов и \nвозникновения тромбоэмболии  при любых операциях, при родах, \nдлительном постельном режиме, пребывании в стационаре. Именно поэтому \nего часто называют госпитальным. Его применение обеспечивает улучшение \nкровотока за счет сужения пространства вен, восстановление работы \nклапанов вен нижних конечностей (чтобы кровь двигалась только в одном \nнаправлении). Улучшение кровотока по венам по направлению к сердцу  \nосуществляется за счёт градуированного давления (градуированной \nкомпрессии), оказываемой на мягкие ткани ног и стенки вен. \n● Чулки ОРТОМЕДИКА соответствуют Национальным стандартам РФ по \nклиническим рекомендациям профилактики противоэмболических \nсиндромов ГОСТ Р 56377-2015  \n● Производство противоэмболических чулок ORTOMEDICA сертифицировано по \nISO 13485 \n● Специальная технология вязки обеспечивает высокую \nвоздухопроницаемость и комфорт для кожи. \n● Эластичность и специальная вязка создают нужную компрессию, и \nэффективно препятствует образованию тромбов \n● Эластичные качественные нити позволяют легко надевать изделие и \nкомфортно носить его в течение суток. Чулки хорошо удерживаются на ноге \nво время ходьбы, и не доставляют дискомфорта во время сна \n● Цветовая кодировка размеров в области стопы позволяет быстро подобрать \nнужный размер \n● Открытый мыс, или как его называют врач, смотровое окно на области стопы,  \nпозволяет контролировать состояние вен по цвету кожных покровов, \nуменьшает вероятность возникновения инфекции, облегчает уход за \nпальцами и другие гигиенические процедуры. \n● Изделия производятся из современных, безопасных, гипоаллергенных \nматериалов. Изделия не отбеливаются и не подвергаются окрашиванию.  \n● Возможность ручной обеспечивают многократное использование изделия \n● Гарантированное сохранение компрессионных свойств в течение 30 дней \nежедневного использования. \nПоказания к применению \nПротивоэмболического трикотажа 1-го класса компрессии \n● Любые оперативные вмешательства, даже небольшие. \n● Во время родов и в послеродовом периоде. \n● Пребывание в отделении интенсивной терапии и реанимации. \n● Длительный постельном режим \n● Состояния после инсульта, инфаркта, ожогов, травм  \nСостав 80% полиэстер, 20% эластан
26	qx4wug2j1usq1qrgcuihpiv7	L1.AG.1 Чулки классика 1КК, бежевые	l1ag1_culki_klass_bez	\N	2025-10-24 20:13:10.569	2025-10-25 11:46:30.958	\N	1	1	\N	\N
48	z7f637kkfoxbiu047qtyx65m	L1.AD.1 Гольфы микрофибра 1KK бежевые	l1ad1_golfy_mikro_bez	\N	2025-10-24 20:40:50.917	2025-10-25 11:39:31.495	\N	1	1	\N	\N
135	n0h5a5rcc81n5lqv7b6n0nj7	L1.AG.2 Чулки классика 1КК, черные	l1ag2_culki_klass_cern	\N	2025-10-24 20:22:32.761	2025-10-25 11:49:57.031	2025-10-25 11:49:57.064	1	1	\N	\N
139	soa1pew4344vfwxs7rbrvdek	QL.S1.1 полустельки МАЛЫШ	qls11_polustelki	\N	2025-10-25 15:16:19.886	2025-10-25 15:18:44.649	2025-10-25 15:18:44.67	1	1	\N	\N
142	htqh1mccee2uuk4eu4g6oqx3	PL.S2.1 стельки БАЛАНС	pls21_stelki_balans	\N	2025-10-25 15:29:02.205	2025-10-25 15:29:02.205	\N	1	1	\N	\N
143	htqh1mccee2uuk4eu4g6oqx3	PL.S2.1 стельки БАЛАНС	pls21_stelki_balans	\N	2025-10-25 15:29:02.205	2025-10-25 15:29:02.205	2025-10-25 15:29:02.244	1	1	\N	\N
146	paqy26ha2sc93sc4tc7rziko	QL.S2.1 полустельки ЭФФЕКТ	qls21_polustelki_effekt	\N	2025-10-25 15:35:45.34	2025-10-25 15:35:45.34	\N	1	1	\N	\N
147	paqy26ha2sc93sc4tc7rziko	QL.S2.1 полустельки ЭФФЕКТ	qls21_polustelki_effekt	\N	2025-10-25 15:35:45.34	2025-10-25 15:35:45.34	2025-10-25 15:35:45.368	1	1	\N	\N
64	xireoljndbj31wbt1srzx2pp	BL.06.1 Голеностоп черный 	bl061_golen_cern	\N	2025-10-24 21:04:39.183	2025-10-25 11:25:40.116	\N	1	1	\N	\N
150	g87auwqmqko9aoklwdqzu3ex	PA.S1.1 стельки СПОРТ	pas11_stelki_sport	\N	2025-10-25 15:37:34.05	2025-10-25 15:38:54.138	2025-10-25 15:38:54.166	1	1	\N	\N
96	nwv8tzy1lxvmkrxekwsafecz	BL.09.1 колено	bl091_koleno	\N	2025-10-24 21:38:31.794	2025-10-25 11:29:04.718	\N	1	1	\N	\N
102	zqnje6fepd0ud69u0c5l2opg	BL.09.3 колено с силиконом и ребрами	bl093_koleno_silic_rebr	\N	2025-10-24 21:42:51.418	2025-10-25 11:30:30.238	\N	1	1	\N	\N
68	wu1jds8bamnkeetmhqwlmjc0	BL.06.2 голеностоп эластичный	bl062_golen_elast	\N	2025-10-24 21:08:40.685	2025-10-25 11:22:39.425	\N	1	1	\N	\N
88	z8b5fjiq36b0znruczlpk5pq	BU.12.4 кисть эластичный	bu124_kist_elast	\N	2025-10-24 21:29:41.911	2025-10-25 11:31:56.299	\N	1	1	\N	\N
108	pea4vfhu0g4fjghjwqliko91	BU.15.1 локоть эластичный	bu151_lokot_elast	\N	2025-10-25 09:39:11.026	2025-10-25 11:34:06.795	\N	1	1	\N	\N
130	z7f637kkfoxbiu047qtyx65m	L1.AD.1 Гольфы микрофибра 1KK бежевые	l1ad1_golfy_mikro_bez	\N	2025-10-24 20:40:50.917	2025-10-25 11:39:31.495	2025-10-25 11:39:31.52	1	1	\N	\N
132	kzf07344w41k38vsm5fdwlap	L1.AD.2 Гольфы микрофибра 1КК, черные	lad2_golfy_mikro_cern	\N	2025-10-24 20:50:35.188	2025-10-25 11:42:17.608	2025-10-25 11:42:17.63	1	1	\N	\N
118	a4hwxkf4y53ouxg40hgaopah	BV.06.1 корсет черный	bv061_korset_cerny	\N	2025-10-25 09:49:13.299	2025-10-25 11:16:49.389	\N	1	1	\N	\N
121	a4hwxkf4y53ouxg40hgaopah	BV.06.1 корсет черный	bv061_korset_cerny	\N	2025-10-25 09:49:13.299	2025-10-25 11:16:49.389	2025-10-25 11:16:49.415	1	1	\N	\N
134	qx4wug2j1usq1qrgcuihpiv7	L1.AG.1 Чулки классика 1КК, бежевые	l1ag1_culki_klass_bez	\N	2025-10-24 20:13:10.569	2025-10-25 11:46:30.958	2025-10-25 11:46:30.992	1	1	\N	\N
123	wu1jds8bamnkeetmhqwlmjc0	BL.06.2 голеностоп эластичный	bl062_golen_elast	\N	2025-10-24 21:08:40.685	2025-10-25 11:22:39.425	2025-10-25 11:22:39.449	1	1	\N	\N
124	xireoljndbj31wbt1srzx2pp	BL.06.1 Голеностоп черный 	bl061_golen_cern	\N	2025-10-24 21:04:39.183	2025-10-25 11:25:40.116	2025-10-25 11:25:40.14	1	1	\N	\N
125	nwv8tzy1lxvmkrxekwsafecz	BL.09.1 колено	bl091_koleno	\N	2025-10-24 21:38:31.794	2025-10-25 11:29:04.718	2025-10-25 11:29:04.748	1	1	\N	\N
126	zqnje6fepd0ud69u0c5l2opg	BL.09.3 колено с силиконом и ребрами	bl093_koleno_silic_rebr	\N	2025-10-24 21:42:51.418	2025-10-25 11:30:30.238	2025-10-25 11:30:30.274	1	1	\N	\N
127	z8b5fjiq36b0znruczlpk5pq	BU.12.4 кисть эластичный	bu124_kist_elast	\N	2025-10-24 21:29:41.911	2025-10-25 11:31:56.299	2025-10-25 11:31:56.326	1	1	\N	\N
128	pea4vfhu0g4fjghjwqliko91	BU.15.1 локоть эластичный	bu151_lokot_elast	\N	2025-10-25 09:39:11.026	2025-10-25 11:34:06.795	2025-10-25 11:34:06.823	1	1	\N	\N
136	soa1pew4344vfwxs7rbrvdek	QL.S1.1 полустельки МАЛЫШ	qls11_polustelki	\N	2025-10-25 15:16:19.886	2025-10-25 15:18:44.649	\N	1	1	\N	\N
140	fxitvcuzf34imux8fwcqz22h	PT.S2.2_стельки АРКТИКА	pts22_stelki_arktika	\N	2025-10-25 15:22:33.37	2025-10-25 15:22:33.37	\N	1	1	\N	\N
141	fxitvcuzf34imux8fwcqz22h	PT.S2.2_стельки АРКТИКА	pts22_stelki_arktika	\N	2025-10-25 15:22:33.37	2025-10-25 15:22:33.37	2025-10-25 15:22:33.4	1	1	\N	\N
144	jjvq85ub81k86xminipm7o02	PT.S2.1 стельки БРИЗ	pts21_stelki_briz	\N	2025-10-25 15:31:02.309	2025-10-25 15:31:02.309	\N	1	1	\N	\N
145	jjvq85ub81k86xminipm7o02	PT.S2.1 стельки БРИЗ	pts21_stelki_briz	\N	2025-10-25 15:31:02.309	2025-10-25 15:31:02.309	2025-10-25 15:31:02.339	1	1	\N	\N
148	g87auwqmqko9aoklwdqzu3ex	PA.S1.1 стельки СПОРТ	pas11_stelki_sport	\N	2025-10-25 15:37:34.05	2025-10-25 15:38:54.138	\N	1	1	\N	\N
\.


--
-- Data for Name: products_category_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.products_category_lnk (id, product_id, category_id, product_ord) FROM stdin;
186	123	55	1
187	124	55	2
188	125	56	1
101	64	36	7
189	126	56	2
103	88	32	1
190	128	57	1
191	127	58	1
111	96	30	1
194	153	53	1
195	121	60	1
117	102	30	4
15	1	18	1
157	136	28	1
123	108	34	1
31	26	22	1
41	36	22	6
53	48	24	2
161	140	26	1
163	139	50	1
164	142	26	2
166	144	26	3
61	56	24	6
168	141	51	1
169	143	51	2
170	145	51	3
171	146	28	2
172	147	50	2
173	148	26	4
133	118	38	2
175	150	51	4
176	130	52	1
177	132	52	2
184	134	54	1
185	135	54	2
91	68	36	4
\.


--
-- Data for Name: strapi_ai_localization_jobs; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_ai_localization_jobs (id, content_type, related_document_id, source_locale, target_locales, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: strapi_api_token_permissions; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_api_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_api_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_api_token_permissions_token_lnk (id, api_token_permission_id, api_token_id, api_token_permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_api_tokens; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_api_tokens (id, document_id, name, description, type, access_key, encrypted_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	eo4bwq6949oid3qlkxxo45qu	Read Only	A default API token with read-only permissions, only used for accessing resources	read-only	3382c5fed765d514c8d5ce9dec783f4193e8a71eb9434682afcc611230b218a5e8efad2c75abe10eb82ffa30a886b55669a5cd660d9c883fa415d7e6547f3108	\N	\N	\N	\N	2025-08-22 12:50:24.274	2025-08-22 12:50:24.274	2025-08-22 12:50:24.274	\N	\N	\N
2	iu505963mczydfv7qnc9g4eg	Full Access	A default API token with full access permissions, used for accessing or modifying resources	full-access	274d18972aa0a94233a5b1921ff872e16d77ea2b88460f1f917e00f6f8e4757a91df1d51b72df13c5fc959f609dad16e6a2f91bf4d7996a9af464024b8334de8	\N	\N	\N	\N	2025-08-22 12:50:24.299	2025-08-22 12:50:24.299	2025-08-22 12:50:24.299	\N	\N	\N
\.


--
-- Data for Name: strapi_core_store_settings; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_core_store_settings (id, key, value, type, environment, tag) FROM stdin;
2	plugin_content_manager_configuration_content_types::plugin::upload.file	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"alternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"alternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"width","searchable":true,"sortable":true}},"height":{"edit":{"label":"height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"size","searchable":true,"sortable":true}},"url":{"edit":{"label":"url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"previewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"previewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider_metadata","searchable":false,"sortable":false}},"folder":{"edit":{"label":"folder","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"folder","searchable":true,"sortable":true}},"folderPath":{"edit":{"label":"folderPath","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"folderPath","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","alternativeText","caption"],"edit":[[{"name":"name","size":6},{"name":"alternativeText","size":6}],[{"name":"caption","size":6},{"name":"width","size":4}],[{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"hash","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"previewUrl","size":6}],[{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"folder","size":6},{"name":"folderPath","size":6}]]},"uid":"plugin::upload.file"}	object	\N	\N
3	plugin_content_manager_configuration_content_types::plugin::i18n.locale	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","createdAt"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}]]},"uid":"plugin::i18n.locale"}	object	\N	\N
4	plugin_content_manager_configuration_content_types::plugin::content-releases.release	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"releasedAt":{"edit":{"label":"releasedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"releasedAt","searchable":true,"sortable":true}},"scheduledAt":{"edit":{"label":"scheduledAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"scheduledAt","searchable":true,"sortable":true}},"timezone":{"edit":{"label":"timezone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"timezone","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"actions":{"edit":{"label":"actions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"contentType"},"list":{"label":"actions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","releasedAt","scheduledAt"],"edit":[[{"name":"name","size":6},{"name":"releasedAt","size":6}],[{"name":"scheduledAt","size":6},{"name":"timezone","size":6}],[{"name":"status","size":6},{"name":"actions","size":6}]]},"uid":"plugin::content-releases.release"}	object	\N	\N
5	plugin_content_manager_configuration_content_types::plugin::content-releases.release-action	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"contentType","defaultSortBy":"contentType","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"contentType":{"edit":{"label":"contentType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentType","searchable":true,"sortable":true}},"entryDocumentId":{"edit":{"label":"entryDocumentId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"entryDocumentId","searchable":true,"sortable":true}},"release":{"edit":{"label":"release","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"release","searchable":true,"sortable":true}},"isEntryValid":{"edit":{"label":"isEntryValid","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isEntryValid","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","type","contentType","entryDocumentId"],"edit":[[{"name":"type","size":6},{"name":"contentType","size":6}],[{"name":"entryDocumentId","size":6},{"name":"release","size":6}],[{"name":"isEntryValid","size":4}]]},"uid":"plugin::content-releases.release-action"}	object	\N	\N
6	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow-stage	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"color":{"edit":{"label":"color","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"color","searchable":true,"sortable":true}},"workflow":{"edit":{"label":"workflow","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"workflow","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","color","workflow"],"edit":[[{"name":"name","size":6},{"name":"color","size":6}],[{"name":"workflow","size":6},{"name":"permissions","size":6}]]},"uid":"plugin::review-workflows.workflow-stage"}	object	\N	\N
8	plugin_content_manager_configuration_content_types::plugin::users-permissions.role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"users","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"permissions","size":6}],[{"name":"users","size":6}]]},"uid":"plugin::users-permissions.role"}	object	\N	\N
9	plugin_content_manager_configuration_content_types::admin::permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"actionParameters":{"edit":{"label":"actionParameters","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"actionParameters","searchable":false,"sortable":false}},"subject":{"edit":{"label":"subject","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"subject","searchable":true,"sortable":true}},"properties":{"edit":{"label":"properties","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"properties","searchable":false,"sortable":false}},"conditions":{"edit":{"label":"conditions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"conditions","searchable":false,"sortable":false}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","subject","role"],"edit":[[{"name":"action","size":6}],[{"name":"actionParameters","size":12}],[{"name":"subject","size":6}],[{"name":"properties","size":12}],[{"name":"conditions","size":12}],[{"name":"role","size":6}]]},"uid":"admin::permission"}	object	\N	\N
7	plugin_content_manager_configuration_content_types::plugin::upload.folder	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"pathId":{"edit":{"label":"pathId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"pathId","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"children","searchable":false,"sortable":false}},"files":{"edit":{"label":"files","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"files","searchable":false,"sortable":false}},"path":{"edit":{"label":"path","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"path","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","pathId","parent"],"edit":[[{"name":"name","size":6},{"name":"pathId","size":4}],[{"name":"parent","size":6},{"name":"children","size":6}],[{"name":"files","size":6},{"name":"path","size":6}]]},"uid":"plugin::upload.folder"}	object	\N	\N
20	plugin_upload_view_configuration	{"pageSize":10,"sort":"createdAt:DESC"}	object	\N	\N
21	plugin_upload_metrics	{"weeklySchedule":"48 3 16 * * 3","lastWeeklyUpdate":1761753828032}	object	\N	\N
19	plugin_upload_settings	{"sizeOptimization":true,"responsiveDimensions":true,"autoOrientation":false,"aiMetadata":true}	object	\N	\N
1	strapi_content_types_schema	{"api::category.category":{"kind":"collectionType","collectionName":"categories","info":{"singularName":"category","pluralName":"categories","displayName":"Category"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string","required":true},"slug":{"type":"uid","targetField":"title","required":true},"parent":{"type":"relation","relation":"manyToOne","target":"api::category.category","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"api::category.category","mappedBy":"parent"},"products":{"type":"relation","relation":"oneToMany","target":"api::product.product","mappedBy":"category"},"imgUrl":{"type":"media","multiple":true,"allowedTypes":["images","files","videos","audios"]},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::category.category","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"categories"}}},"apiName":"category","globalId":"Category","uid":"api::category.category","modelType":"contentType","__schema__":{"collectionName":"categories","info":{"singularName":"category","pluralName":"categories","displayName":"Category"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string","required":true},"slug":{"type":"uid","targetField":"title","required":true},"parent":{"type":"relation","relation":"manyToOne","target":"api::category.category","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"api::category.category","mappedBy":"parent"},"products":{"type":"relation","relation":"oneToMany","target":"api::product.product","mappedBy":"category"},"imgUrl":{"type":"media","multiple":true,"allowedTypes":["images","files","videos","audios"]}},"kind":"collectionType"},"modelName":"category","actions":{},"lifecycles":{}},"api::client-document.client-document":{"collectionName":"client_documents","info":{"singularName":"client-document","pluralName":"client-documents","displayName":"Client Document","description":"Client-uploaded documents"},"options":{"draftAndPublish":true},"attributes":{"title":{"type":"string","required":true},"client_doc":{"type":"media","multiple":false,"allowedTypes":["files"]},"description":{"type":"text"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::client-document.client-document","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"client_documents"}}},"apiName":"client-document","globalId":"ClientDocument","uid":"api::client-document.client-document","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"client_documents","info":{"singularName":"client-document","pluralName":"client-documents","displayName":"Client Document","description":"Client-uploaded documents"},"options":{"draftAndPublish":true},"attributes":{"title":{"type":"string","required":true},"client_doc":{"type":"media","multiple":false,"allowedTypes":["files"]},"description":{"type":"text"}},"kind":"collectionType"},"modelName":"client-document","actions":{},"lifecycles":{}},"api::product.product":{"kind":"collectionType","collectionName":"products","info":{"singularName":"product","pluralName":"products","displayName":"Product"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string"},"slug":{"type":"uid","targetField":"title"},"price":{"type":"decimal"},"images":{"type":"media","multiple":true,"allowedTypes":["images","files","videos","audios"]},"category":{"type":"relation","relation":"manyToOne","target":"api::category.category","inversedBy":"products"},"description":{"type":"text"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::product.product","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"products"}}},"apiName":"product","globalId":"Product","uid":"api::product.product","modelType":"contentType","__schema__":{"collectionName":"products","info":{"singularName":"product","pluralName":"products","displayName":"Product"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"title":{"type":"string"},"slug":{"type":"uid","targetField":"title"},"price":{"type":"decimal"},"images":{"type":"media","multiple":true,"allowedTypes":["images","files","videos","audios"]},"category":{"type":"relation","relation":"manyToOne","target":"api::category.category","inversedBy":"products"},"description":{"type":"text"}},"kind":"collectionType"},"modelName":"product","actions":{},"lifecycles":{}},"plugin::upload.file":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"files"}}},"indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null}],"plugin":"upload","globalId":"UploadFile","uid":"plugin::upload.file","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"file"},"plugin::upload.folder":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"upload_folders"}}},"indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"}],"plugin":"upload","globalId":"UploadFolder","uid":"plugin::upload.folder","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true}},"kind":"collectionType"},"modelName":"folder"},"plugin::i18n.locale":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::i18n.locale","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"i18n_locale"}}},"plugin":"i18n","collectionName":"i18n_locale","globalId":"I18NLocale","uid":"plugin::i18n.locale","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"i18n_locale","info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false}},"kind":"collectionType"},"modelName":"locale"},"plugin::content-releases.release":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_releases"}}},"plugin":"content-releases","globalId":"ContentReleasesRelease","uid":"plugin::content-releases.release","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"}},"kind":"collectionType"},"modelName":"release"},"plugin::content-releases.release-action":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_release_actions"}}},"plugin":"content-releases","globalId":"ContentReleasesReleaseAction","uid":"plugin::content-releases.release-action","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"}},"kind":"collectionType"},"modelName":"release-action"},"plugin::review-workflows.workflow":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflow","uid":"plugin::review-workflows.workflow","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"}},"kind":"collectionType"},"modelName":"workflow"},"plugin::review-workflows.workflow-stage":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0","draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow-stage","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows_stages"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflowStage","uid":"plugin::review-workflows.workflow-stage","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false}},"kind":"collectionType"},"modelName":"workflow-stage"},"plugin::users-permissions.permission":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_permissions"}}},"plugin":"users-permissions","globalId":"UsersPermissionsPermission","uid":"plugin::users-permissions.permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false}},"kind":"collectionType"},"modelName":"permission","options":{"draftAndPublish":false}},"plugin::users-permissions.role":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_roles"}}},"plugin":"users-permissions","globalId":"UsersPermissionsRole","uid":"plugin::users-permissions.role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false}},"kind":"collectionType"},"modelName":"role","options":{"draftAndPublish":false}},"plugin::users-permissions.user":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"draftAndPublish":false},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"client_documents":{"type":"relation","relation":"oneToMany","target":"api::client-document.client-document","mappedBy":"owner"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"confirmationToken":{"hidden":true},"provider":{"hidden":true}}},"plugin":"users-permissions","globalId":"UsersPermissionsUser","kind":"collectionType","pluginOptions":{},"__filename__":"schema.json","uid":"plugin::users-permissions.user","modelType":"contentType","__schema__":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"draftAndPublish":false},"pluginOptions":{},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"client_documents":{"type":"relation","relation":"oneToMany","target":"api::client-document.client-document","mappedBy":"owner"}},"kind":"collectionType"},"modelName":"user"},"admin::permission":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_permissions"}}},"plugin":"admin","globalId":"AdminPermission","uid":"admin::permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"}},"kind":"collectionType"},"modelName":"permission"},"admin::user":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"registrationToken":{"hidden":true}}},"plugin":"admin","globalId":"AdminUser","uid":"admin::user","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false}},"kind":"collectionType"},"modelName":"user","options":{"draftAndPublish":false}},"admin::role":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_roles"}}},"plugin":"admin","globalId":"AdminRole","uid":"admin::role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"}},"kind":"collectionType"},"modelName":"role"},"admin::api-token":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_tokens"}}},"plugin":"admin","globalId":"AdminApiToken","uid":"admin::api-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"api-token"},"admin::api-token-permission":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_token_permissions"}}},"plugin":"admin","globalId":"AdminApiTokenPermission","uid":"admin::api-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"}},"kind":"collectionType"},"modelName":"api-token-permission"},"admin::transfer-token":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_tokens"}}},"plugin":"admin","globalId":"AdminTransferToken","uid":"admin::transfer-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"transfer-token"},"admin::transfer-token-permission":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_token_permissions"}}},"plugin":"admin","globalId":"AdminTransferTokenPermission","uid":"admin::transfer-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"}},"kind":"collectionType"},"modelName":"transfer-token-permission"},"admin::session":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::session","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_sessions"}}},"plugin":"admin","globalId":"AdminSession","uid":"admin::session","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"session"}}	object	\N	\N
11	plugin_content_manager_configuration_content_types::admin::role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"users","searchable":false,"sortable":false}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","description"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}],[{"name":"description","size":6},{"name":"users","size":6}],[{"name":"permissions","size":6}]]},"uid":"admin::role"}	object	\N	\N
12	plugin_content_manager_configuration_content_types::admin::user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"registrationToken":{"edit":{"label":"registrationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"registrationToken","searchable":true,"sortable":true}},"isActive":{"edit":{"label":"isActive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isActive","searchable":true,"sortable":true}},"roles":{"edit":{"label":"roles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"roles","searchable":false,"sortable":false}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"preferedLanguage":{"edit":{"label":"preferedLanguage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"preferedLanguage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","username"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"isActive","size":4}],[{"name":"roles","size":6},{"name":"blocked","size":4}],[{"name":"preferedLanguage","size":6}]]},"uid":"admin::user"}	object	\N	\N
13	plugin_content_manager_configuration_content_types::admin::api-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"encryptedKey":{"edit":{"label":"encryptedKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"encryptedKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"accessKey","size":6}],[{"name":"encryptedKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::api-token"}	object	\N	\N
14	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"stages":{"edit":{"label":"stages","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stages","searchable":false,"sortable":false}},"stageRequiredToPublish":{"edit":{"label":"stageRequiredToPublish","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stageRequiredToPublish","searchable":true,"sortable":true}},"contentTypes":{"edit":{"label":"contentTypes","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentTypes","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","stages","stageRequiredToPublish"],"edit":[[{"name":"name","size":6},{"name":"stages","size":6}],[{"name":"stageRequiredToPublish","size":6}],[{"name":"contentTypes","size":12}]]},"uid":"plugin::review-workflows.workflow"}	object	\N	\N
15	plugin_content_manager_configuration_content_types::admin::transfer-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::transfer-token-permission"}	object	\N	\N
16	plugin_content_manager_configuration_content_types::admin::transfer-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","accessKey"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"accessKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::transfer-token"}	object	\N	\N
17	plugin_content_manager_configuration_content_types::admin::api-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::api-token-permission"}	object	\N	\N
18	plugin_content_manager_configuration_content_types::plugin::users-permissions.permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","role","createdAt"],"edit":[[{"name":"action","size":6},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.permission"}	object	\N	\N
22	plugin_i18n_default_locale	"en"	string	\N	\N
24	plugin_users-permissions_email	{"reset_password":{"display":"Email.template.reset_password","icon":"sync","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\\n\\n<p>But don’t worry! You can use the following link to reset your password:</p>\\n<p><%= URL %>?code=<%= TOKEN %></p>\\n\\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\\n\\n<p>You have to confirm your email address. Please click on the link below.</p>\\n\\n<p><%= URL %>?confirmation=<%= CODE %></p>\\n\\n<p>Thanks.</p>"}}}	object	\N	\N
25	plugin_users-permissions_advanced	{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_reset_password":null,"email_confirmation_redirection":null,"default_role":"authenticated"}	object	\N	\N
31	plugin_content_manager_configuration_content_types::api::client-document.client-document	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"client_doc":{"edit":{"label":"client_doc","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"client_doc","searchable":false,"sortable":false}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","client_doc","description"],"edit":[[{"name":"title","size":6},{"name":"client_doc","size":6}],[{"name":"description","size":6}]]},"uid":"api::client-document.client-document"}	object	\N	\N
23	plugin_users-permissions_grant	{"email":{"icon":"envelope","enabled":true},"discord":{"icon":"discord","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/discord/callback","scope":["identify","email"]},"facebook":{"icon":"facebook-square","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/facebook/callback","scope":["email"]},"google":{"icon":"google","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/google/callback","scope":["email"]},"github":{"icon":"github","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/github/callback","scope":["user","user:email"]},"microsoft":{"icon":"windows","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/microsoft/callback","scope":["user.read"]},"twitter":{"icon":"twitter","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/twitter/callback"},"instagram":{"icon":"instagram","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/instagram/callback","scope":["user_profile"]},"vk":{"icon":"vk","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/vk/callback","scope":["email"]},"twitch":{"icon":"twitch","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/twitch/callback","scope":["user:read:email"]},"linkedin":{"icon":"linkedin","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/linkedin/callback","scope":["r_liteprofile","r_emailaddress"]},"cognito":{"icon":"aws","enabled":false,"key":"","secret":"","subdomain":"my.subdomain.com","callback":"api/auth/cognito/callback","scope":["email","openid","profile"]},"reddit":{"icon":"reddit","enabled":false,"key":"","secret":"","callback":"api/auth/reddit/callback","scope":["identity"]},"auth0":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"my-tenant.eu","callback":"api/auth/auth0/callback","scope":["openid","email","profile"]},"cas":{"icon":"book","enabled":false,"key":"","secret":"","callback":"api/auth/cas/callback","scope":["openid email"],"subdomain":"my.subdomain.com/cas"},"patreon":{"icon":"","enabled":false,"key":"","secret":"","callback":"api/auth/patreon/callback","scope":["identity","identity[email]"]},"keycloak":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"myKeycloakProvider.com/realms/myrealm","callback":"api/auth/keycloak/callback","scope":["openid","email","profile"]}}	object	\N	\N
27	plugin_content_manager_configuration_content_types::api::product.product	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"price":{"edit":{"label":"price","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"price","searchable":true,"sortable":true}},"images":{"edit":{"label":"images","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"images","searchable":false,"sortable":false}},"category":{"edit":{"label":"category","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"category","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","slug","price"],"edit":[[{"name":"title","size":6},{"name":"slug","size":6}],[{"name":"price","size":4}],[{"name":"category","size":6},{"name":"description","size":6}],[{"name":"images","size":6}]]},"uid":"api::product.product"}	object	\N	\N
10	plugin_content_manager_configuration_content_types::plugin::users-permissions.user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"confirmationToken":{"edit":{"label":"confirmationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"confirmationToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"client_documents":{"edit":{"label":"client_documents","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"client_documents","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"role","size":6}],[{"name":"client_documents","size":6}]]},"uid":"plugin::users-permissions.user"}	object	\N	\N
28	plugin_content_manager_configuration_content_types::api::category.category	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"children","searchable":false,"sortable":false}},"products":{"edit":{"label":"products","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"products","searchable":false,"sortable":false}},"imgUrl":{"edit":{"label":"imgUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"imgUrl","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","slug","parent"],"edit":[[{"name":"title","size":6},{"name":"slug","size":6}],[{"name":"parent","size":6},{"name":"children","size":6}],[{"name":"products","size":6},{"name":"imgUrl","size":6}]]},"uid":"api::category.category"}	object	\N	\N
32	strapi_unidirectional-join-table-repair-ran	true	boolean	\N	\N
26	core_admin_auth	{"providers":{"autoRegister":false,"defaultRole":null,"ssoLockedRoles":null}}	object	\N	\N
33	plugin_content_manager_configuration_content_types::admin::session	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"userId","defaultSortBy":"userId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"userId":{"edit":{"label":"userId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"userId","searchable":true,"sortable":true}},"sessionId":{"edit":{"label":"sessionId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"sessionId","searchable":true,"sortable":true}},"childId":{"edit":{"label":"childId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"childId","searchable":true,"sortable":true}},"deviceId":{"edit":{"label":"deviceId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"deviceId","searchable":true,"sortable":true}},"origin":{"edit":{"label":"origin","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"origin","searchable":true,"sortable":true}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"absoluteExpiresAt":{"edit":{"label":"absoluteExpiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"absoluteExpiresAt","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","userId","sessionId","childId"],"edit":[[{"name":"userId","size":6},{"name":"sessionId","size":6}],[{"name":"childId","size":6},{"name":"deviceId","size":6}],[{"name":"origin","size":6},{"name":"expiresAt","size":6}],[{"name":"absoluteExpiresAt","size":6},{"name":"status","size":6}],[{"name":"type","size":6}]]},"uid":"admin::session"}	object	\N	\N
\.


--
-- Data for Name: strapi_database_schema; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_database_schema (id, schema, "time", hash) FROM stdin;
15	{"tables":[{"name":"categories","indexes":[{"name":"categories_documents_idx","columns":["document_id","locale","published_at"]},{"name":"categories_created_by_id_fk","columns":["created_by_id"]},{"name":"categories_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"categories_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"categories_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"client_documents","indexes":[{"name":"client_documents_documents_idx","columns":["document_id","locale","published_at"]},{"name":"client_documents_created_by_id_fk","columns":["created_by_id"]},{"name":"client_documents_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"client_documents_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"client_documents_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"products","indexes":[{"name":"products_documents_idx","columns":["document_id","locale","published_at"]},{"name":"products_created_by_id_fk","columns":["created_by_id"]},{"name":"products_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"products_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"products_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"price","type":"decimal","args":[10,2],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"files","indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null},{"name":"files_documents_idx","columns":["document_id","locale","published_at"]},{"name":"files_created_by_id_fk","columns":["created_by_id"]},{"name":"files_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"files_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"files_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"alternative_text","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"caption","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"width","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"height","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"formats","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ext","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mime","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"size","type":"decimal","args":[10,2],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"preview_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider_metadata","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"folder_path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"upload_folders","indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"},{"name":"upload_folders_documents_idx","columns":["document_id","locale","published_at"]},{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"]},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"i18n_locale","indexes":[{"name":"i18n_locale_documents_idx","columns":["document_id","locale","published_at"]},{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"]},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_releases","indexes":[{"name":"strapi_releases_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"released_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"scheduled_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"timezone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_release_actions","indexes":[{"name":"strapi_release_actions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"entry_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_entry_valid","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows","indexes":[{"name":"strapi_workflows_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_types","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_workflows_stages","indexes":[{"name":"strapi_workflows_stages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"color","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_permissions","indexes":[{"name":"up_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_roles","indexes":[{"name":"up_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_users","indexes":[{"name":"up_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_users_created_by_id_fk","columns":["created_by_id"]},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmation_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions","indexes":[{"name":"admin_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action_parameters","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subject","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"properties","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"conditions","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_users","indexes":[{"name":"admin_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_users_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"registration_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_active","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"prefered_language","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_roles","indexes":[{"name":"admin_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_tokens","indexes":[{"name":"strapi_api_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"encrypted_key","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_token_permissions","indexes":[{"name":"strapi_api_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_tokens","indexes":[{"name":"strapi_transfer_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_token_permissions","indexes":[{"name":"strapi_transfer_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_sessions","indexes":[{"name":"strapi_sessions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"user_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"session_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"child_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"device_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"origin","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"absolute_expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_core_store_settings","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"environment","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"tag","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_webhooks","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"headers","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"events","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enabled","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_history_versions","indexes":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"]}],"foreignKeys":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"data","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"schema","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_ai_localization_jobs","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"source_locale","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"target_locales","type":"jsonb","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"categories_parent_lnk","indexes":[{"name":"categories_parent_lnk_fk","columns":["category_id"]},{"name":"categories_parent_lnk_ifk","columns":["inv_category_id"]},{"name":"categories_parent_lnk_uq","columns":["category_id","inv_category_id"],"type":"unique"},{"name":"categories_parent_lnk_oifk","columns":["category_ord"]}],"foreignKeys":[{"name":"categories_parent_lnk_fk","columns":["category_id"],"referencedColumns":["id"],"referencedTable":"categories","onDelete":"CASCADE"},{"name":"categories_parent_lnk_ifk","columns":["inv_category_id"],"referencedColumns":["id"],"referencedTable":"categories","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"category_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_category_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"category_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"products_category_lnk","indexes":[{"name":"products_category_lnk_fk","columns":["product_id"]},{"name":"products_category_lnk_ifk","columns":["category_id"]},{"name":"products_category_lnk_uq","columns":["product_id","category_id"],"type":"unique"},{"name":"products_category_lnk_oifk","columns":["product_ord"]}],"foreignKeys":[{"name":"products_category_lnk_fk","columns":["product_id"],"referencedColumns":["id"],"referencedTable":"products","onDelete":"CASCADE"},{"name":"products_category_lnk_ifk","columns":["category_id"],"referencedColumns":["id"],"referencedTable":"categories","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"product_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"category_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"product_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_related_mph","indexes":[{"name":"files_related_mph_fk","columns":["file_id"]},{"name":"files_related_mph_oidx","columns":["order"]},{"name":"files_related_mph_idix","columns":["related_id"]}],"foreignKeys":[{"name":"files_related_mph_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_folder_lnk","indexes":[{"name":"files_folder_lnk_fk","columns":["file_id"]},{"name":"files_folder_lnk_ifk","columns":["folder_id"]},{"name":"files_folder_lnk_uq","columns":["file_id","folder_id"],"type":"unique"},{"name":"files_folder_lnk_oifk","columns":["file_ord"]}],"foreignKeys":[{"name":"files_folder_lnk_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"},{"name":"files_folder_lnk_ifk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"file_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders_parent_lnk","indexes":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"]},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"]},{"name":"upload_folders_parent_lnk_uq","columns":["folder_id","inv_folder_id"],"type":"unique"},{"name":"upload_folders_parent_lnk_oifk","columns":["folder_ord"]}],"foreignKeys":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_release_actions_release_lnk","indexes":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"]},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"]},{"name":"strapi_release_actions_release_lnk_uq","columns":["release_action_id","release_id"],"type":"unique"},{"name":"strapi_release_actions_release_lnk_oifk","columns":["release_action_ord"]}],"foreignKeys":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"],"referencedColumns":["id"],"referencedTable":"strapi_release_actions","onDelete":"CASCADE"},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"],"referencedColumns":["id"],"referencedTable":"strapi_releases","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"release_action_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_action_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stage_required_to_publish_lnk","indexes":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_uq","columns":["workflow_id","workflow_stage_id"],"type":"unique"}],"foreignKeys":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_workflow_lnk","indexes":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"]},{"name":"strapi_workflows_stages_workflow_lnk_uq","columns":["workflow_stage_id","workflow_id"],"type":"unique"},{"name":"strapi_workflows_stages_workflow_lnk_oifk","columns":["workflow_stage_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_permissions_lnk","indexes":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"]},{"name":"strapi_workflows_stages_permissions_lnk_uq","columns":["workflow_stage_id","permission_id"],"type":"unique"},{"name":"strapi_workflows_stages_permissions_lnk_ofk","columns":["permission_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions_role_lnk","indexes":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"up_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"up_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"up_permissions","onDelete":"CASCADE"},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users_role_lnk","indexes":[{"name":"up_users_role_lnk_fk","columns":["user_id"]},{"name":"up_users_role_lnk_ifk","columns":["role_id"]},{"name":"up_users_role_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"up_users_role_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"up_users_role_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"},{"name":"up_users_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_permissions_role_lnk","indexes":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"admin_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"admin_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users_roles_lnk","indexes":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"]},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"]},{"name":"admin_users_roles_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"admin_users_roles_lnk_ofk","columns":["role_ord"]},{"name":"admin_users_roles_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions_token_lnk","indexes":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"]},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"]},{"name":"strapi_api_token_permissions_token_lnk_uq","columns":["api_token_permission_id","api_token_id"],"type":"unique"},{"name":"strapi_api_token_permissions_token_lnk_oifk","columns":["api_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_token_permissions","onDelete":"CASCADE"},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"api_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_transfer_token_permissions_token_lnk","indexes":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_uq","columns":["transfer_token_permission_id","transfer_token_id"],"type":"unique"},{"name":"strapi_transfer_token_permissions_token_lnk_oifk","columns":["transfer_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_token_permissions","onDelete":"CASCADE"},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"transfer_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]}]}	2025-11-01 07:42:42.219	da5eaa59ae1a3d3148e5320601dfd6e38bde0cdfbbf61431db9f7c85c643777e
\.


--
-- Data for Name: strapi_history_versions; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_history_versions (id, content_type, related_document_id, locale, status, data, schema, created_at, created_by_id) FROM stdin;
\.


--
-- Data for Name: strapi_migrations; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_migrations (id, name, "time") FROM stdin;
1	20251001_rename_client_document.js	2025-11-01 07:42:41.7
\.


--
-- Data for Name: strapi_migrations_internal; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_migrations_internal (id, name, "time") FROM stdin;
1	5.0.0-rename-identifiers-longer-than-max-length	2025-08-22 12:50:20.52
2	5.0.0-02-created-document-id	2025-08-22 12:50:20.609
3	5.0.0-03-created-locale	2025-08-22 12:50:20.696
4	5.0.0-04-created-published-at	2025-08-22 12:50:20.797
5	5.0.0-05-drop-slug-fields-index	2025-08-22 12:50:20.869
6	core::5.0.0-discard-drafts	2025-08-22 12:50:20.939
\.


--
-- Data for Name: strapi_release_actions; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_release_actions (id, document_id, type, content_type, entry_document_id, locale, is_entry_valid, created_at, updated_at, published_at, created_by_id, updated_by_id) FROM stdin;
\.


--
-- Data for Name: strapi_release_actions_release_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_release_actions_release_lnk (id, release_action_id, release_id, release_action_ord) FROM stdin;
\.


--
-- Data for Name: strapi_releases; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_releases (id, document_id, name, released_at, scheduled_at, timezone, status, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_sessions; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_sessions (id, document_id, user_id, session_id, child_id, device_id, origin, expires_at, absolute_expires_at, status, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	sgnocedcx9aeajcerse8ml3s	1	cfd167f5e4ce681a31e8d53559ac0ffb	\N	4af02b9d-e811-456d-9323-7984d3538ec2	admin	2025-10-31 17:56:36.688	2025-11-30 15:56:36.688	active	session	2025-10-31 15:56:36.688	2025-10-31 15:56:36.688	2025-10-31 15:56:36.69	\N	\N	\N
\.


--
-- Data for Name: strapi_transfer_token_permissions; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_transfer_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_transfer_token_permissions_token_lnk (id, transfer_token_permission_id, transfer_token_id, transfer_token_permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_transfer_tokens; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_transfer_tokens (id, document_id, name, description, access_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_webhooks; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_webhooks (id, name, url, headers, events, enabled) FROM stdin;
\.


--
-- Data for Name: strapi_workflows; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_workflows (id, document_id, name, content_types, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_workflows_stage_required_to_publish_lnk (id, workflow_id, workflow_stage_id) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_workflows_stages (id, document_id, name, color, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages_permissions_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_workflows_stages_permissions_lnk (id, workflow_stage_id, permission_id, permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages_workflow_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.strapi_workflows_stages_workflow_lnk (id, workflow_stage_id, workflow_id, workflow_stage_ord) FROM stdin;
\.


--
-- Data for Name: up_permissions; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.up_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	qheogm4jlhchawsfutswlnkc	plugin::users-permissions.user.me	2025-08-22 12:50:23.191	2025-08-22 12:50:23.191	2025-08-22 12:50:23.191	\N	\N	\N
2	tp1ce230bman7exf1vr0n94k	plugin::users-permissions.auth.changePassword	2025-08-22 12:50:23.191	2025-08-22 12:50:23.191	2025-08-22 12:50:23.192	\N	\N	\N
3	t1aaxsjuu663st3efvmsjngz	plugin::users-permissions.auth.callback	2025-08-22 12:50:23.231	2025-08-22 12:50:23.231	2025-08-22 12:50:23.231	\N	\N	\N
4	rf3ctt3se2tqrir2zfqotm0n	plugin::users-permissions.auth.connect	2025-08-22 12:50:23.231	2025-08-22 12:50:23.231	2025-08-22 12:50:23.232	\N	\N	\N
5	vh95zkvyx2e8y4ghfp70pawh	plugin::users-permissions.auth.forgotPassword	2025-08-22 12:50:23.231	2025-08-22 12:50:23.231	2025-08-22 12:50:23.232	\N	\N	\N
6	exp0m7n4b6fo0xrtucumpfsv	plugin::users-permissions.auth.resetPassword	2025-08-22 12:50:23.231	2025-08-22 12:50:23.231	2025-08-22 12:50:23.232	\N	\N	\N
7	hvlhj35m2ypw8u2d8d5kl38o	plugin::users-permissions.auth.register	2025-08-22 12:50:23.231	2025-08-22 12:50:23.231	2025-08-22 12:50:23.233	\N	\N	\N
8	r5g4ckdo3lw0zkkn2fymvzo4	plugin::users-permissions.auth.emailConfirmation	2025-08-22 12:50:23.231	2025-08-22 12:50:23.231	2025-08-22 12:50:23.233	\N	\N	\N
9	tea4htlj5udcums40ay6ekqv	plugin::users-permissions.auth.sendEmailConfirmation	2025-08-22 12:50:23.231	2025-08-22 12:50:23.231	2025-08-22 12:50:23.233	\N	\N	\N
10	l4mqhcddalo3jcpuprf5mj9y	plugin::content-type-builder.components.getComponents	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.427	\N	\N	\N
11	hk8hsjy792qa3f3k4p6lfmof	plugin::content-type-builder.components.getComponent	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.428	\N	\N	\N
12	oko8uogfqfs5llyut2ri0812	plugin::content-type-builder.content-types.getContentTypes	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.429	\N	\N	\N
13	xdj2km6czfic5zo435yg7s3b	plugin::content-type-builder.content-types.getContentType	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.43	\N	\N	\N
14	pdbi19rt7prhpwhphw5iqyq7	plugin::email.email.send	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.431	\N	\N	\N
15	tm9y68wrse177s89ykjwbyke	plugin::upload.content-api.findOne	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.432	\N	\N	\N
16	qoac1gd81gzlq1mz0zh7kl7y	plugin::upload.content-api.find	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.431	\N	\N	\N
17	vwe89jmq4obn0gqvcuael5md	plugin::upload.content-api.destroy	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.432	\N	\N	\N
18	fugl5lv73f31igvkv3cqvdfg	plugin::upload.content-api.upload	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.438	\N	\N	\N
19	p9angypx23y5454cxjatg7xr	plugin::i18n.locales.listLocales	2025-08-24 23:14:50.418	2025-08-24 23:14:50.418	2025-08-24 23:14:50.438	\N	\N	\N
20	a0hbkja6y09qy0fy3otvl5bv	plugin::users-permissions.auth.register	2025-08-25 09:20:48.085	2025-08-25 09:20:48.085	2025-08-25 09:20:48.087	\N	\N	\N
21	dh3wobrrqm8vnpve8q1u66xp	api::product.product.findOne	2025-08-27 16:35:56.828	2025-08-27 16:35:56.828	2025-08-27 16:35:56.829	\N	\N	\N
22	yn7sldjpbwgc98sgsv93kggt	api::product.product.find	2025-08-27 16:35:56.828	2025-08-27 16:35:56.828	2025-08-27 16:35:56.828	\N	\N	\N
23	wkzqry3fqafhsq5ev5v0jeot	api::category.category.find	2025-08-27 22:52:05.245	2025-08-27 22:52:05.245	2025-08-27 22:52:05.25	\N	\N	\N
24	xw7d2a9eza65nfhpx13xzc41	api::category.category.findOne	2025-08-27 22:52:05.245	2025-08-27 22:52:05.245	2025-08-27 22:52:05.251	\N	\N	\N
50	glfnkhuf2v5pprxc0gjpihbj	plugin::upload.content-api.find	2025-10-27 23:45:23.328	2025-10-27 23:45:23.328	2025-10-27 23:45:23.329	\N	\N	\N
51	e9pvpb7oo68khue62raubwyk	plugin::upload.content-api.findOne	2025-10-27 23:45:23.328	2025-10-27 23:45:23.328	2025-10-27 23:45:23.329	\N	\N	\N
52	gxefk88tamnpwbygm76k5iot	plugin::upload.content-api.upload	2025-10-27 23:45:23.328	2025-10-27 23:45:23.328	2025-10-27 23:45:23.329	\N	\N	\N
53	wjabdbwnp1zr0bh8lzpbykf3	plugin::users-permissions.user.me	2025-10-27 23:45:23.328	2025-10-27 23:45:23.328	2025-10-27 23:45:23.329	\N	\N	\N
54	ld5txuu1hqj052c6b6nrnr80	plugin::i18n.locales.listLocales	2025-10-27 23:52:47.942	2025-10-27 23:52:47.942	2025-10-27 23:52:47.943	\N	\N	\N
\.


--
-- Data for Name: up_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.up_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	1	1
2	2	1	1
3	3	2	1
4	5	2	1
5	6	2	1
6	8	2	2
7	7	2	2
8	9	2	2
9	4	2	1
10	12	1	2
11	10	1	2
12	11	1	3
13	15	1	3
14	14	1	3
15	16	1	3
16	13	1	3
17	18	1	3
18	17	1	3
19	19	1	3
20	20	1	4
21	22	2	3
22	21	2	3
23	23	2	4
24	24	2	4
48	52	4	2
51	53	4	3
52	50	4	3
53	51	4	3
54	54	4	4
\.


--
-- Data for Name: up_roles; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.up_roles (id, document_id, name, description, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
2	cs0ee4gap4hjzkvokgtknnx1	Public	Default role given to unauthenticated user.	public	2025-08-22 12:50:23.182	2025-08-27 22:52:09.149	2025-08-22 12:50:23.182	\N	\N	\N
4	w2axxwgvarzcchqzyjsyes9v	Client	B2B	client	2025-10-27 23:45:23.32	2025-10-27 23:52:47.937	2025-10-27 23:45:23.32	\N	\N	\N
1	k49601m2cxy1co30blry4tvv	Authenticated	Default role given to authenticated user.	authenticated	2025-08-22 12:50:23.177	2025-10-28 00:49:13.686	2025-08-22 12:50:23.177	\N	\N	\N
\.


--
-- Data for Name: up_users; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.up_users (id, document_id, username, email, provider, password, reset_password_token, confirmation_token, confirmed, blocked, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	s6gh4guudpagjhltv23q3rda	Erlendas	erlendas.meskys@stud.vilniustex.lt	local	$2a$10$3zEFLSNnn0SwvHhGWbfI4O9jFbfpTgKL8VZ2xj5a7xz45IXMBmy4S	\N	\N	t	f	2025-08-25 09:27:37.404	2025-08-25 09:27:37.404	2025-08-25 09:27:37.404	\N	\N	\N
2	nwk0ua55kx5b3cdm34fij4v8	Purinta	info@purinta.lt	local	$2a$10$4NFNLgFf.F1g2p1BgUREMuiEgqinahSHhxXATlTczCyhdwU81lgEm	\N	\N	t	f	2025-10-25 20:54:29.237	2025-10-28 00:00:49.531	2025-10-28 00:00:49.471	1	1	\N
\.


--
-- Data for Name: up_users_role_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.up_users_role_lnk (id, user_id, role_id, user_ord) FROM stdin;
1	1	1	1
4	2	4	1
\.


--
-- Data for Name: upload_folders; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.upload_folders (id, document_id, name, path_id, path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	e4jngfa6diu94jaqpy6b90tk	CulkiAntiEmbolic	1	/1	2025-08-28 11:36:13.899	2025-10-24 17:51:53.721	2025-08-28 11:36:13.9	1	1	\N
\.


--
-- Data for Name: upload_folders_parent_lnk; Type: TABLE DATA; Schema: public; Owner: ortho
--

COPY public.upload_folders_parent_lnk (id, folder_id, inv_folder_id, folder_ord) FROM stdin;
\.


--
-- Name: admin_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.admin_permissions_id_seq', 155, true);


--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.admin_permissions_role_lnk_id_seq', 155, true);


--
-- Name: admin_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.admin_roles_id_seq', 3, true);


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 2, true);


--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.admin_users_roles_lnk_id_seq', 4, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.categories_id_seq', 60, true);


--
-- Name: categories_parent_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.categories_parent_lnk_id_seq', 50, true);


--
-- Name: client_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.client_documents_id_seq', 2, true);


--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.files_folder_lnk_id_seq', 3, true);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.files_id_seq', 92, true);


--
-- Name: files_related_mph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.files_related_mph_id_seq', 433, true);


--
-- Name: i18n_locale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.i18n_locale_id_seq', 1, true);


--
-- Name: products_category_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.products_category_lnk_id_seq', 195, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.products_id_seq', 153, true);


--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_ai_localization_jobs_id_seq', 1, false);


--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_id_seq', 1, false);


--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_token_lnk_id_seq', 1, false);


--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_api_tokens_id_seq', 2, true);


--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_core_store_settings_id_seq', 33, true);


--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_database_schema_id_seq', 15, true);


--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_history_versions_id_seq', 1, false);


--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_migrations_id_seq', 1, true);


--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_migrations_internal_id_seq', 6, true);


--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_release_actions_id_seq', 1, false);


--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_release_actions_release_lnk_id_seq', 1, false);


--
-- Name: strapi_releases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_releases_id_seq', 1, false);


--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_sessions_id_seq', 1, true);


--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_id_seq', 1, false);


--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_token_lnk_id_seq', 1, false);


--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_transfer_tokens_id_seq', 1, false);


--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_webhooks_id_seq', 1, false);


--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_workflows_id_seq', 1, false);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_permissions_lnk_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_workflow_lnk_id_seq', 1, false);


--
-- Name: up_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.up_permissions_id_seq', 56, true);


--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.up_permissions_role_lnk_id_seq', 56, true);


--
-- Name: up_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.up_roles_id_seq', 4, true);


--
-- Name: up_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.up_users_id_seq', 2, true);


--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.up_users_role_lnk_id_seq', 4, true);


--
-- Name: upload_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.upload_folders_id_seq', 1, true);


--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ortho
--

SELECT pg_catalog.setval('public.upload_folders_parent_lnk_id_seq', 1, false);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: admin_roles admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: categories_parent_lnk categories_parent_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories_parent_lnk
    ADD CONSTRAINT categories_parent_lnk_pkey PRIMARY KEY (id);


--
-- Name: categories_parent_lnk categories_parent_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories_parent_lnk
    ADD CONSTRAINT categories_parent_lnk_uq UNIQUE (category_id, inv_category_id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: client_documents client_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.client_documents
    ADD CONSTRAINT client_documents_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_uq UNIQUE (file_id, folder_id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: files_related_mph files_related_mph_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_pkey PRIMARY KEY (id);


--
-- Name: i18n_locale i18n_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_pkey PRIMARY KEY (id);


--
-- Name: products_category_lnk products_category_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products_category_lnk
    ADD CONSTRAINT products_category_lnk_pkey PRIMARY KEY (id);


--
-- Name: products_category_lnk products_category_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products_category_lnk
    ADD CONSTRAINT products_category_lnk_uq UNIQUE (product_id, category_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: strapi_ai_localization_jobs strapi_ai_localization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs
    ADD CONSTRAINT strapi_ai_localization_jobs_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_uq UNIQUE (api_token_permission_id, api_token_id);


--
-- Name: strapi_api_tokens strapi_api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_core_store_settings strapi_core_store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_core_store_settings
    ADD CONSTRAINT strapi_core_store_settings_pkey PRIMARY KEY (id);


--
-- Name: strapi_database_schema strapi_database_schema_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_database_schema
    ADD CONSTRAINT strapi_database_schema_pkey PRIMARY KEY (id);


--
-- Name: strapi_history_versions strapi_history_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations_internal strapi_migrations_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_migrations_internal
    ADD CONSTRAINT strapi_migrations_internal_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations strapi_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_migrations
    ADD CONSTRAINT strapi_migrations_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions strapi_release_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_uq UNIQUE (release_action_id, release_id);


--
-- Name: strapi_releases strapi_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_pkey PRIMARY KEY (id);


--
-- Name: strapi_sessions strapi_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_uq UNIQUE (transfer_token_permission_id, transfer_token_id);


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_webhooks strapi_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_webhooks
    ADD CONSTRAINT strapi_webhooks_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows strapi_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_uq UNIQUE (workflow_id, workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_uq UNIQUE (workflow_stage_id, permission_id);


--
-- Name: strapi_workflows_stages strapi_workflows_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_uq UNIQUE (workflow_stage_id, workflow_id);


--
-- Name: up_permissions up_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: up_roles up_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_pkey PRIMARY KEY (id);


--
-- Name: up_users up_users_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_pkey PRIMARY KEY (id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_uq UNIQUE (folder_id, inv_folder_id);


--
-- Name: upload_folders upload_folders_path_id_index; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_id_index UNIQUE (path_id);


--
-- Name: upload_folders upload_folders_path_index; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_index UNIQUE (path);


--
-- Name: upload_folders upload_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_permissions_created_by_id_fk ON public.admin_permissions USING btree (created_by_id);


--
-- Name: admin_permissions_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_permissions_documents_idx ON public.admin_permissions USING btree (document_id, locale, published_at);


--
-- Name: admin_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_permissions_role_lnk_fk ON public.admin_permissions_role_lnk USING btree (permission_id);


--
-- Name: admin_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_permissions_role_lnk_ifk ON public.admin_permissions_role_lnk USING btree (role_id);


--
-- Name: admin_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_permissions_role_lnk_oifk ON public.admin_permissions_role_lnk USING btree (permission_ord);


--
-- Name: admin_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_permissions_updated_by_id_fk ON public.admin_permissions USING btree (updated_by_id);


--
-- Name: admin_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_roles_created_by_id_fk ON public.admin_roles USING btree (created_by_id);


--
-- Name: admin_roles_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_roles_documents_idx ON public.admin_roles USING btree (document_id, locale, published_at);


--
-- Name: admin_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_roles_updated_by_id_fk ON public.admin_roles USING btree (updated_by_id);


--
-- Name: admin_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_users_created_by_id_fk ON public.admin_users USING btree (created_by_id);


--
-- Name: admin_users_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_users_documents_idx ON public.admin_users USING btree (document_id, locale, published_at);


--
-- Name: admin_users_roles_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_users_roles_lnk_fk ON public.admin_users_roles_lnk USING btree (user_id);


--
-- Name: admin_users_roles_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_users_roles_lnk_ifk ON public.admin_users_roles_lnk USING btree (role_id);


--
-- Name: admin_users_roles_lnk_ofk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_users_roles_lnk_ofk ON public.admin_users_roles_lnk USING btree (role_ord);


--
-- Name: admin_users_roles_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_users_roles_lnk_oifk ON public.admin_users_roles_lnk USING btree (user_ord);


--
-- Name: admin_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX admin_users_updated_by_id_fk ON public.admin_users USING btree (updated_by_id);


--
-- Name: categories_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX categories_created_by_id_fk ON public.categories USING btree (created_by_id);


--
-- Name: categories_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX categories_documents_idx ON public.categories USING btree (document_id, locale, published_at);


--
-- Name: categories_parent_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX categories_parent_lnk_fk ON public.categories_parent_lnk USING btree (category_id);


--
-- Name: categories_parent_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX categories_parent_lnk_ifk ON public.categories_parent_lnk USING btree (inv_category_id);


--
-- Name: categories_parent_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX categories_parent_lnk_oifk ON public.categories_parent_lnk USING btree (category_ord);


--
-- Name: categories_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX categories_updated_by_id_fk ON public.categories USING btree (updated_by_id);


--
-- Name: client_documents_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX client_documents_created_by_id_fk ON public.client_documents USING btree (created_by_id);


--
-- Name: client_documents_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX client_documents_documents_idx ON public.client_documents USING btree (document_id, locale, published_at);


--
-- Name: client_documents_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX client_documents_updated_by_id_fk ON public.client_documents USING btree (updated_by_id);


--
-- Name: files_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_created_by_id_fk ON public.files USING btree (created_by_id);


--
-- Name: files_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_documents_idx ON public.files USING btree (document_id, locale, published_at);


--
-- Name: files_folder_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_folder_lnk_fk ON public.files_folder_lnk USING btree (file_id);


--
-- Name: files_folder_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_folder_lnk_ifk ON public.files_folder_lnk USING btree (folder_id);


--
-- Name: files_folder_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_folder_lnk_oifk ON public.files_folder_lnk USING btree (file_ord);


--
-- Name: files_related_mph_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_related_mph_fk ON public.files_related_mph USING btree (file_id);


--
-- Name: files_related_mph_idix; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_related_mph_idix ON public.files_related_mph USING btree (related_id);


--
-- Name: files_related_mph_oidx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_related_mph_oidx ON public.files_related_mph USING btree ("order");


--
-- Name: files_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX files_updated_by_id_fk ON public.files USING btree (updated_by_id);


--
-- Name: i18n_locale_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX i18n_locale_created_by_id_fk ON public.i18n_locale USING btree (created_by_id);


--
-- Name: i18n_locale_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX i18n_locale_documents_idx ON public.i18n_locale USING btree (document_id, locale, published_at);


--
-- Name: i18n_locale_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX i18n_locale_updated_by_id_fk ON public.i18n_locale USING btree (updated_by_id);


--
-- Name: products_category_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX products_category_lnk_fk ON public.products_category_lnk USING btree (product_id);


--
-- Name: products_category_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX products_category_lnk_ifk ON public.products_category_lnk USING btree (category_id);


--
-- Name: products_category_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX products_category_lnk_oifk ON public.products_category_lnk USING btree (product_ord);


--
-- Name: products_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX products_created_by_id_fk ON public.products USING btree (created_by_id);


--
-- Name: products_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX products_documents_idx ON public.products USING btree (document_id, locale, published_at);


--
-- Name: products_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX products_updated_by_id_fk ON public.products USING btree (updated_by_id);


--
-- Name: strapi_api_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_token_permissions_created_by_id_fk ON public.strapi_api_token_permissions USING btree (created_by_id);


--
-- Name: strapi_api_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_token_permissions_documents_idx ON public.strapi_api_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_token_permissions_token_lnk_fk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_id);


--
-- Name: strapi_api_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_token_permissions_token_lnk_ifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_id);


--
-- Name: strapi_api_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_token_permissions_token_lnk_oifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_ord);


--
-- Name: strapi_api_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_token_permissions_updated_by_id_fk ON public.strapi_api_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_api_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_tokens_created_by_id_fk ON public.strapi_api_tokens USING btree (created_by_id);


--
-- Name: strapi_api_tokens_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_tokens_documents_idx ON public.strapi_api_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_api_tokens_updated_by_id_fk ON public.strapi_api_tokens USING btree (updated_by_id);


--
-- Name: strapi_history_versions_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_history_versions_created_by_id_fk ON public.strapi_history_versions USING btree (created_by_id);


--
-- Name: strapi_release_actions_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_release_actions_created_by_id_fk ON public.strapi_release_actions USING btree (created_by_id);


--
-- Name: strapi_release_actions_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_release_actions_documents_idx ON public.strapi_release_actions USING btree (document_id, locale, published_at);


--
-- Name: strapi_release_actions_release_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_release_actions_release_lnk_fk ON public.strapi_release_actions_release_lnk USING btree (release_action_id);


--
-- Name: strapi_release_actions_release_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_release_actions_release_lnk_ifk ON public.strapi_release_actions_release_lnk USING btree (release_id);


--
-- Name: strapi_release_actions_release_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_release_actions_release_lnk_oifk ON public.strapi_release_actions_release_lnk USING btree (release_action_ord);


--
-- Name: strapi_release_actions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_release_actions_updated_by_id_fk ON public.strapi_release_actions USING btree (updated_by_id);


--
-- Name: strapi_releases_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_releases_created_by_id_fk ON public.strapi_releases USING btree (created_by_id);


--
-- Name: strapi_releases_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_releases_documents_idx ON public.strapi_releases USING btree (document_id, locale, published_at);


--
-- Name: strapi_releases_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_releases_updated_by_id_fk ON public.strapi_releases USING btree (updated_by_id);


--
-- Name: strapi_sessions_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_sessions_created_by_id_fk ON public.strapi_sessions USING btree (created_by_id);


--
-- Name: strapi_sessions_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_sessions_documents_idx ON public.strapi_sessions USING btree (document_id, locale, published_at);


--
-- Name: strapi_sessions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_sessions_updated_by_id_fk ON public.strapi_sessions USING btree (updated_by_id);


--
-- Name: strapi_transfer_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_token_permissions_created_by_id_fk ON public.strapi_transfer_token_permissions USING btree (created_by_id);


--
-- Name: strapi_transfer_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_token_permissions_documents_idx ON public.strapi_transfer_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_fk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_ifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_oifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_ord);


--
-- Name: strapi_transfer_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_token_permissions_updated_by_id_fk ON public.strapi_transfer_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_transfer_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_tokens_created_by_id_fk ON public.strapi_transfer_tokens USING btree (created_by_id);


--
-- Name: strapi_transfer_tokens_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_tokens_documents_idx ON public.strapi_transfer_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_transfer_tokens_updated_by_id_fk ON public.strapi_transfer_tokens USING btree (updated_by_id);


--
-- Name: strapi_workflows_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_created_by_id_fk ON public.strapi_workflows USING btree (created_by_id);


--
-- Name: strapi_workflows_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_documents_idx ON public.strapi_workflows USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_fk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_ifk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_created_by_id_fk ON public.strapi_workflows_stages USING btree (created_by_id);


--
-- Name: strapi_workflows_stages_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_documents_idx ON public.strapi_workflows_stages USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stages_permissions_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_fk ON public.strapi_workflows_stages_permissions_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ifk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ofk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ofk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_ord);


--
-- Name: strapi_workflows_stages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_updated_by_id_fk ON public.strapi_workflows_stages USING btree (updated_by_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_fk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_ifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_oifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_ord);


--
-- Name: strapi_workflows_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX strapi_workflows_updated_by_id_fk ON public.strapi_workflows USING btree (updated_by_id);


--
-- Name: up_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_permissions_created_by_id_fk ON public.up_permissions USING btree (created_by_id);


--
-- Name: up_permissions_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_permissions_documents_idx ON public.up_permissions USING btree (document_id, locale, published_at);


--
-- Name: up_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_permissions_role_lnk_fk ON public.up_permissions_role_lnk USING btree (permission_id);


--
-- Name: up_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_permissions_role_lnk_ifk ON public.up_permissions_role_lnk USING btree (role_id);


--
-- Name: up_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_permissions_role_lnk_oifk ON public.up_permissions_role_lnk USING btree (permission_ord);


--
-- Name: up_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_permissions_updated_by_id_fk ON public.up_permissions USING btree (updated_by_id);


--
-- Name: up_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_roles_created_by_id_fk ON public.up_roles USING btree (created_by_id);


--
-- Name: up_roles_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_roles_documents_idx ON public.up_roles USING btree (document_id, locale, published_at);


--
-- Name: up_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_roles_updated_by_id_fk ON public.up_roles USING btree (updated_by_id);


--
-- Name: up_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_users_created_by_id_fk ON public.up_users USING btree (created_by_id);


--
-- Name: up_users_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_users_documents_idx ON public.up_users USING btree (document_id, locale, published_at);


--
-- Name: up_users_role_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_users_role_lnk_fk ON public.up_users_role_lnk USING btree (user_id);


--
-- Name: up_users_role_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_users_role_lnk_ifk ON public.up_users_role_lnk USING btree (role_id);


--
-- Name: up_users_role_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_users_role_lnk_oifk ON public.up_users_role_lnk USING btree (user_ord);


--
-- Name: up_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX up_users_updated_by_id_fk ON public.up_users USING btree (updated_by_id);


--
-- Name: upload_files_created_at_index; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_files_created_at_index ON public.files USING btree (created_at);


--
-- Name: upload_files_ext_index; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_files_ext_index ON public.files USING btree (ext);


--
-- Name: upload_files_folder_path_index; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_files_folder_path_index ON public.files USING btree (folder_path);


--
-- Name: upload_files_name_index; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_files_name_index ON public.files USING btree (name);


--
-- Name: upload_files_size_index; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_files_size_index ON public.files USING btree (size);


--
-- Name: upload_files_updated_at_index; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_files_updated_at_index ON public.files USING btree (updated_at);


--
-- Name: upload_folders_created_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_folders_created_by_id_fk ON public.upload_folders USING btree (created_by_id);


--
-- Name: upload_folders_documents_idx; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_folders_documents_idx ON public.upload_folders USING btree (document_id, locale, published_at);


--
-- Name: upload_folders_parent_lnk_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_folders_parent_lnk_fk ON public.upload_folders_parent_lnk USING btree (folder_id);


--
-- Name: upload_folders_parent_lnk_ifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_folders_parent_lnk_ifk ON public.upload_folders_parent_lnk USING btree (inv_folder_id);


--
-- Name: upload_folders_parent_lnk_oifk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_folders_parent_lnk_oifk ON public.upload_folders_parent_lnk USING btree (folder_ord);


--
-- Name: upload_folders_updated_by_id_fk; Type: INDEX; Schema: public; Owner: ortho
--

CREATE INDEX upload_folders_updated_by_id_fk ON public.upload_folders USING btree (updated_by_id);


--
-- Name: admin_permissions admin_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_permissions admin_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users admin_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_fk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_users admin_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: categories categories_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: categories_parent_lnk categories_parent_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories_parent_lnk
    ADD CONSTRAINT categories_parent_lnk_fk FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: categories_parent_lnk categories_parent_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories_parent_lnk
    ADD CONSTRAINT categories_parent_lnk_ifk FOREIGN KEY (inv_category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: categories categories_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: client_documents client_documents_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.client_documents
    ADD CONSTRAINT client_documents_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: client_documents client_documents_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.client_documents
    ADD CONSTRAINT client_documents_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files files_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files_folder_lnk files_folder_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files_folder_lnk files_folder_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_ifk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: files_related_mph files_related_mph_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files files_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: products_category_lnk products_category_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products_category_lnk
    ADD CONSTRAINT products_category_lnk_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products_category_lnk products_category_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products_category_lnk
    ADD CONSTRAINT products_category_lnk_ifk FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: products products_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: products products_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_fk FOREIGN KEY (api_token_permission_id) REFERENCES public.strapi_api_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_ifk FOREIGN KEY (api_token_id) REFERENCES public.strapi_api_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_history_versions strapi_history_versions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions strapi_release_actions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_fk FOREIGN KEY (release_action_id) REFERENCES public.strapi_release_actions(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_ifk FOREIGN KEY (release_id) REFERENCES public.strapi_releases(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions strapi_release_actions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_fk FOREIGN KEY (transfer_token_permission_id) REFERENCES public.strapi_transfer_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_ifk FOREIGN KEY (transfer_token_id) REFERENCES public.strapi_transfer_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows strapi_workflows_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_fk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_ifk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_ifk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_ifk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows strapi_workflows_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions up_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.up_permissions(id) ON DELETE CASCADE;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_permissions up_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users up_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users_role_lnk up_users_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_fk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: up_users_role_lnk up_users_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_users up_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders upload_folders_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_fk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_ifk FOREIGN KEY (inv_folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders upload_folders_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ortho
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 8hoGAc4Q9rThTZVawv1PNCaZAEPp6A2j3D12YugIjgZ6BItBPYB9etgS9RUYmDU

